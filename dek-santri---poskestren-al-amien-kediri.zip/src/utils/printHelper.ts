/**
 * Universal Printing & PDF Generator Helper for DEK SANTRI
 * Pondok Pesantren Al-Amien Kediri
 */

export interface PrintDocumentOptions {
  title: string;
  bodyHtml: string;
  orientation?: 'portrait' | 'landscape';
}

/**
 * Trigger browser print dialog cleanly formatted for paper and 'Save as PDF'
 */
export function printHtmlContent({ title, bodyHtml, orientation = 'portrait' }: PrintDocumentOptions) {
  // Check if hidden print iframe already exists
  const existingIframe = document.getElementById('dek-santri-print-frame');
  if (existingIframe) {
    existingIframe.remove();
  }

  const iframe = document.createElement('iframe');
  iframe.id = 'dek-santri-print-frame';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  document.body.appendChild(iframe);

  const doc = iframe.contentWindow?.document || iframe.contentDocument;
  if (!doc) {
    window.print();
    return;
  }

  const fullHtml = `
    <!DOCTYPE html>
    <html lang="id">
    <head>
      <meta charset="UTF-8">
      <title>${title}</title>
      <style>
        @page {
          size: A4 ${orientation};
          margin: 12mm 15mm 15mm 15mm;
        }
        * {
          box-sizing: border-box;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
        }
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
          color: #1c1917;
          background: #ffffff;
          margin: 0;
          padding: 0;
          font-size: 11pt;
          line-height: 1.5;
        }
        .header-kop {
          text-align: center;
          border-bottom: 2.5px solid #064e3b;
          padding-bottom: 8px;
          margin-bottom: 16px;
        }
        .kop-yayasan {
          font-family: "Times New Roman", Times, serif;
          font-weight: bold;
          font-size: 12pt;
          color: #022c22;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 2px;
        }
        .kop-poskestren {
          font-family: "Times New Roman", Times, serif;
          font-weight: bold;
          font-size: 15pt;
          color: #064e3b;
          letter-spacing: 1px;
          margin: 2px 0 4px 0;
        }
        .kop-alamat {
          font-size: 8.5pt;
          color: #44403c;
          line-height: 1.3;
        }
        .doc-header {
          text-align: center;
          margin: 14px 0 16px 0;
        }
        .doc-title {
          font-size: 12pt;
          font-weight: bold;
          text-transform: uppercase;
          text-decoration: underline;
          margin: 0;
          color: #0c0a09;
        }
        .doc-nomor {
          margin-top: 3px;
          font-size: 9.5pt;
          font-family: "Courier New", Courier, monospace;
          color: #292524;
        }
        .content-box {
          border: 1px solid #d6d3d1;
          background-color: #fafaf9;
          border-radius: 6px;
          padding: 10px 14px;
          margin: 12px 0;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin: 10px 0;
          font-size: 9pt;
        }
        th, td {
          border: 1px solid #d6d3d1;
          padding: 6px 8px;
          text-align: left;
        }
        th {
          background-color: #f5f5f4;
          font-weight: 600;
          color: #292524;
        }
        .grid-row {
          display: flex;
          margin-bottom: 5px;
        }
        .grid-label {
          width: 180px;
          color: #57534e;
          font-size: 10pt;
        }
        .grid-value {
          flex: 1;
          font-weight: 500;
          font-size: 10pt;
          color: #0c0a09;
        }
        .signature-wrap {
          margin-top: 30px;
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          page-break-inside: avoid;
          font-size: 9.5pt;
        }
        .signature-box {
          text-align: center;
          width: 220px;
        }
        .signature-space {
          height: 60px;
        }
        .font-bold { font-weight: bold; }
        .font-mono { font-family: "Courier New", Courier, monospace; }
        .underline { text-decoration: underline; }
        .badge {
          display: inline-block;
          padding: 2px 6px;
          border-radius: 3px;
          font-size: 8pt;
          font-weight: bold;
          background-color: #f5f5f4;
          border: 1px solid #e7e5e4;
        }
      </style>
    </head>
    <body>
      ${bodyHtml}
    </body>
    </html>
  `;

  doc.open();
  doc.write(fullHtml);
  doc.close();

  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (e) {
      console.error('Error invoking iframe print:', e);
      window.print();
    }
  }, 350);
}

/**
 * Downloads the document as a clean, styled standalone HTML / PDF printable file
 */
export function downloadDocumentFile(filename: string, title: string, bodyHtml: string) {
  const fullHtml = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>
    @page { size: A4; margin: 15mm; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #1c1917; padding: 25px; max-width: 850px; margin: 0 auto; line-height: 1.5; }
    .header-kop { text-align: center; border-bottom: 2.5px solid #064e3b; padding-bottom: 8px; margin-bottom: 16px; }
    .kop-yayasan { font-weight: bold; font-size: 13pt; text-transform: uppercase; }
    .kop-poskestren { font-weight: bold; font-size: 16pt; color: #064e3b; margin: 3px 0; }
    .kop-alamat { font-size: 9pt; color: #44403c; }
    .doc-header { text-align: center; margin: 16px 0; }
    .doc-title { font-size: 13pt; font-weight: bold; text-transform: uppercase; text-decoration: underline; }
    .doc-nomor { font-size: 10pt; font-family: monospace; }
    .content-box { border: 1px solid #d6d3d1; background-color: #fafaf9; border-radius: 6px; padding: 12px; margin: 12px 0; }
    table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 9.5pt; }
    th, td { border: 1px solid #d6d3d1; padding: 7px 9px; text-align: left; }
    th { background-color: #f5f5f4; font-weight: 600; }
    .grid-row { display: flex; margin-bottom: 5px; }
    .grid-label { width: 190px; color: #57534e; }
    .grid-value { flex: 1; font-weight: 500; }
    .signature-wrap { margin-top: 35px; display: flex; justify-content: space-between; align-items: flex-end; }
    .signature-box { text-align: center; width: 230px; }
    .signature-space { height: 65px; }
    .font-bold { font-weight: bold; }
    .underline { text-decoration: underline; }
    @media print { .no-print { display: none !important; } }
  </style>
</head>
<body>
  <div class="no-print" style="margin-bottom: 20px; padding: 10px; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px; text-align: center;">
    <button onclick="window.print()" style="background: #059669; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: bold; cursor: pointer;">
      🖨️ Cetak Dokumen / Simpan sebagai PDF (Ctrl+P)
    </button>
  </div>
  ${bodyHtml}
</body>
</html>`;

  const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.html') ? filename : `${filename}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Age & Underage helper for Pesantren Health Records
 * Santri under 18 years old are considered minors requiring informed consent
 * from Ketua Kelompok / Asrama & Kader Jaga.
 */
export function calculateAge(birthDateStr?: string): number {
  if (!birthDateStr) return 0;
  const today = new Date();
  const birthDate = new Date(birthDateStr);
  if (isNaN(birthDate.getTime())) return 0;
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return Math.max(0, age);
}

export function isUnderage(birthDateStr?: string): boolean {
  return calculateAge(birthDateStr) < 18;
}
