import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Topbar } from './components/Topbar';
import { Dashboard } from './components/Dashboard';
import { SantriList } from './components/SantriList';
import { SantriDetailModal } from './components/SantriDetailModal';
import { RekamMedisFormModal } from './components/RekamMedisFormModal';
import { RekamMedisList } from './components/RekamMedisList';
import { ApotekView } from './components/ApotekView';
import { SuratIzinView } from './components/SuratIzinView';
import { LaporanView } from './components/LaporanView';
import { LaravelDatabaseView } from './components/LaravelDatabaseView';

import { 
  initialSantriList, 
  initialObatList, 
  initialRekamMedisList, 
  initialSuratIzinList, 
  initialSuratRujukanList,
  initialInformedConsentList,
  petugasList as initialPetugasList 
} from './data/mockData';
import { Santri, Obat, RekamMedis, SuratIzinSakit, SuratRujukan, SuratInformedConsent, PetugasPoskestren, NavTab } from './types';
import { HeartHandshake, CheckCircle2 } from 'lucide-react';

export default function App() {
  // Navigation State with Left Sidebar
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);

  // Core Data States with localStorage fallback
  const [santriList, setSantriList] = useState<Santri[]>(() => {
    const saved = localStorage.getItem('dek_santri_list');
    return saved ? JSON.parse(saved) : initialSantriList;
  });

  const [obatList, setObatList] = useState<Obat[]>(() => {
    const saved = localStorage.getItem('dek_obat_list');
    return saved ? JSON.parse(saved) : initialObatList;
  });

  const [rekamMedisList, setRekamMedisList] = useState<RekamMedis[]>(() => {
    const saved = localStorage.getItem('dek_rekam_medis_list');
    return saved ? JSON.parse(saved) : initialRekamMedisList;
  });

  const [suratIzinList, setSuratIzinList] = useState<SuratIzinSakit[]>(() => {
    const saved = localStorage.getItem('dek_surat_izin_list');
    return saved ? JSON.parse(saved) : initialSuratIzinList;
  });

  const [suratRujukanList, setSuratRujukanList] = useState<SuratRujukan[]>(() => {
    const saved = localStorage.getItem('dek_surat_rujukan_list');
    return saved ? JSON.parse(saved) : initialSuratRujukanList;
  });

  const [informedConsentList, setInformedConsentList] = useState<SuratInformedConsent[]>(() => {
    const saved = localStorage.getItem('dek_informed_consent_list');
    return saved ? JSON.parse(saved) : initialInformedConsentList;
  });

  const [petugasList] = useState<PetugasPoskestren[]>(initialPetugasList);

  // Modals
  const [selectedSantriForDetail, setSelectedSantriForDetail] = useState<Santri | null>(null);
  const [isCheckupModalOpen, setIsCheckupModalOpen] = useState(false);
  const [santriForCheckup, setSantriForCheckup] = useState<Santri | null>(null);

  // Toast alert
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('dek_santri_list', JSON.stringify(santriList));
  }, [santriList]);

  useEffect(() => {
    localStorage.setItem('dek_obat_list', JSON.stringify(obatList));
  }, [obatList]);

  useEffect(() => {
    localStorage.setItem('dek_rekam_medis_list', JSON.stringify(rekamMedisList));
  }, [rekamMedisList]);

  useEffect(() => {
    localStorage.setItem('dek_surat_izin_list', JSON.stringify(suratIzinList));
  }, [suratIzinList]);

  useEffect(() => {
    localStorage.setItem('dek_surat_rujukan_list', JSON.stringify(suratRujukanList));
  }, [suratRujukanList]);

  useEffect(() => {
    localStorage.setItem('dek_informed_consent_list', JSON.stringify(informedConsentList));
  }, [informedConsentList]);

  // Handlers
  const handleSaveSantri = (savedSantri: Santri) => {
    setSantriList(prev => {
      const exists = prev.some(s => s.id === savedSantri.id);
      if (exists) {
        return prev.map(s => s.id === savedSantri.id ? savedSantri : s);
      }
      return [savedSantri, ...prev];
    });
    showToast(`Data santri ${savedSantri.nama_lengkap} berhasil disimpan.`);
  };

  const handleDeleteSantri = (id: string) => {
    setSantriList(prev => prev.filter(s => s.id !== id));
    showToast('Data santri berhasil dihapus.');
  };

  const handleOpenCheckupForSantri = (s: Santri) => {
    setSantriForCheckup(s);
    setIsCheckupModalOpen(true);
  };

  const handleOpenNewCheckupGeneral = () => {
    setSantriForCheckup(null);
    setIsCheckupModalOpen(true);
  };

  const handleSaveInformedConsent = (newConsent: SuratInformedConsent) => {
    setInformedConsentList(prev => [newConsent, ...prev]);
    showToast(`Lembar Informed Consent No: ${newConsent.nomor_surat} (${newConsent.santri_nama}) berhasil diterbitkan.`);
  };

  const handleDeleteInformedConsent = (id: string) => {
    setInformedConsentList(prev => prev.filter(c => c.id !== id));
    showToast('Surat Informed Consent berhasil dihapus.');
  };

  const handleSaveRekamMedis = (
    newRM: RekamMedis,
    usedMeds: { obatId: string; jumlah: number }[],
    suratIzin?: SuratIzinSakit,
    suratRujukan?: SuratRujukan,
    suratConsent?: SuratInformedConsent
  ) => {
    // 1. Add RM
    setRekamMedisList(prev => [newRM, ...prev]);

    // 2. Update Santri status
    setSantriList(prev => prev.map(s => {
      if (s.id === newRM.santri_id) {
        let newStatus = s.status_kesehatan;
        if (newRM.status_penanganan === 'Rawat Jalan') newStatus = 'Aktif';
        else if (newRM.status_penanganan === 'Observasi Poskestren') newStatus = 'Observasi_Poskestren';
        else if (newRM.status_penanganan === 'Istirahat di Asrama') newStatus = 'Izin_Asrama';
        else if (newRM.status_penanganan === 'Izin Pulang ke Rumah') newStatus = 'Izin_Pulang';
        else if (newRM.status_penanganan === 'Rujukan Faskes') newStatus = 'Rujukan_RS';

        return { ...s, status_kesehatan: newStatus, updated_at: new Date().toISOString().replace('T', ' ').slice(0, 16) };
      }
      return s;
    }));

    // 3. Deduct medicine stock
    if (usedMeds.length > 0) {
      setObatList(prev => prev.map(o => {
        const used = usedMeds.find(u => u.obatId === o.id);
        if (used) {
          const newStock = Math.max(0, o.stok - used.jumlah);
          return { ...o, stok: newStock };
        }
        return o;
      }));
    }

    // 4. Add letters if present
    if (suratIzin) {
      setSuratIzinList(prev => [suratIzin, ...prev]);
    }
    if (suratRujukan) {
      setSuratRujukanList(prev => [suratRujukan, ...prev]);
    }
    if (suratConsent) {
      setInformedConsentList(prev => [suratConsent, ...prev]);
    }

    showToast(`Pemeriksaan RM ${newRM.nomor_rm} berhasil dicatat & berkas poskestren diperbarui!`);
  };

  const handleSaveObat = (newObat: Obat) => {
    setObatList(prev => [newObat, ...prev]);
    showToast(`Master obat ${newObat.nama_obat} berhasil didaftarkan.`);
  };

  const handleRestockObat = (obatId: string, additionalQty: number) => {
    setObatList(prev => prev.map(o => {
      if (o.id === obatId) {
        return { ...o, stok: o.stok + additionalQty };
      }
      return o;
    }));
    showToast(`Stok obat berhasil ditambah (+${additionalQty}).`);
  };

  const santriSakitCount = santriList.filter(s => s.status_kesehatan !== 'Aktif').length;

  return (
    <div className="min-h-screen bg-stone-100/70 text-stone-900 flex font-sans antialiased">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-emerald-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-emerald-700 flex items-center gap-2.5 text-xs font-semibold animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Left Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewPeriksa={handleOpenNewCheckupGeneral}
        petugasList={petugasList}
        santriSakitCount={santriSakitCount}
        totalSantri={santriList.length}
        totalRM={rekamMedisList.length}
        isMobileOpen={isMobileSidebarOpen}
        setIsMobileOpen={setIsMobileSidebarOpen}
      />

      {/* Main Workspace (Offset by Left Sidebar on Desktop) */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-72">
        {/* Topbar */}
        <Topbar
          activeTab={activeTab}
          onOpenMobileSidebar={() => setIsMobileSidebarOpen(true)}
          onOpenNewPeriksa={handleOpenNewCheckupGeneral}
          santriSakitCount={santriSakitCount}
        />

        {/* Content Body */}
        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              santriList={santriList}
              rekamMedisList={rekamMedisList}
              obatList={obatList}
              petugasList={petugasList}
              onSelectSantri={(s) => setSelectedSantriForDetail(s)}
              onOpenNewPeriksa={handleOpenNewCheckupGeneral}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'santri' && (
            <SantriList
              santriList={santriList}
              onSelectSantri={(s) => setSelectedSantriForDetail(s)}
              onPeriksaSantri={handleOpenCheckupForSantri}
              onSaveSantri={handleSaveSantri}
              onDeleteSantri={handleDeleteSantri}
            />
          )}

          {activeTab === 'rekam-medis' && (
            <RekamMedisList
              rekamMedisList={rekamMedisList}
              santriList={santriList}
              onOpenNewPeriksa={handleOpenNewCheckupGeneral}
              onSelectSantri={(s) => setSelectedSantriForDetail(s)}
            />
          )}

          {activeTab === 'apotek' && (
            <ApotekView
              obatList={obatList}
              onSaveObat={handleSaveObat}
              onRestock={handleRestockObat}
            />
          )}

          {activeTab === 'surat' && (
            <SuratIzinView
              suratIzinList={suratIzinList}
              suratRujukanList={suratRujukanList}
              informedConsentList={informedConsentList}
              santriList={santriList}
              petugasList={petugasList}
              onSaveInformedConsent={handleSaveInformedConsent}
              onDeleteInformedConsent={handleDeleteInformedConsent}
            />
          )}

          {activeTab === 'laporan' && (
            <LaporanView
              santriList={santriList}
              rekamMedisList={rekamMedisList}
              obatList={obatList}
            />
          )}

          {activeTab === 'laravel' && (
            <LaravelDatabaseView
              santriList={santriList}
              rekamMedisList={rekamMedisList}
              obatList={obatList}
            />
          )}
        </main>

        {/* Footer */}
        <footer className="bg-white border-t border-stone-200 py-5 px-6 text-stone-500 text-xs mt-auto">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <HeartHandshake className="w-4 h-4 text-emerald-700" />
              <span className="font-semibold text-stone-800">
                DEK SANTRI • Poskestren Pondok Pesantren Al-Amien Kediri
              </span>
            </div>
            <div className="text-center sm:text-right text-[11px] text-stone-400">
              Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kediri • Sistem Rekam Medis Santri Terpadu
            </div>
          </div>
        </footer>
      </div>

      {/* Santri Medical Detail Modal */}
      {selectedSantriForDetail && (
        <SantriDetailModal
          santri={selectedSantriForDetail}
          rekamMedisList={rekamMedisList}
          onClose={() => setSelectedSantriForDetail(null)}
          onNewCheckup={(s) => handleOpenCheckupForSantri(s)}
        />
      )}

      {/* Examination Checkup Modal */}
      {isCheckupModalOpen && (
        <RekamMedisFormModal
          isOpen={isCheckupModalOpen}
          onClose={() => setIsCheckupModalOpen(false)}
          santriList={santriList}
          obatList={obatList}
          petugasList={petugasList}
          initialSelectedSantri={santriForCheckup}
          onSaveRekamMedis={handleSaveRekamMedis}
        />
      )}
    </div>
  );
}
