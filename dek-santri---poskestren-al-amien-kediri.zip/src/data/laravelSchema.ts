export interface LaravelFile {
  filename: string;
  category: 'migration' | 'model' | 'controller' | 'seeder' | 'sql';
  title: string;
  description: string;
  code: string;
}

export const laravelFiles: LaravelFile[] = [
  {
    filename: '2026_01_01_000001_create_santris_table.php',
    category: 'migration',
    title: 'Migration: Table Santris',
    description: 'Tabel master data santri Ponpes Al Amien Kediri (NIS, kamar, asrama, kontak wali, riwayat alergi)',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Database: DEK SANTRI - Poskestren Al Amien Kediri
     */
    public function up(): void
    {
        Schema::create('santris', function (Blueprint $table) {
            $table->id();
            $table->string('nis', 30)->unique()->comment('Nomor Induk Santri');
            $table->string('nama_lengkap', 150);
            $table->enum('jenis_kelamin', ['L', 'P'])->comment('L=Banin / Putra, P=Banat / Putri');
            $table->string('jenjang_pendidikan', 50)->comment('MTs / MA / KMI / Tahfidz');
            $table->string('kelas', 30);
            $table->string('asrama_komplek', 100);
            $table->string('kamar', 50);
            $table->string('tempat_lahir', 80)->nullable();
            $table->date('tanggal_lahir')->nullable();
            $table->enum('golongan_darah', ['A', 'B', 'AB', 'O', '-'])->default('-');
            $table->string('nama_wali', 120);
            $table->string('telepon_wali', 30);
            $table->text('alamat_asal')->nullable();
            $table->text('riwayat_alergi')->nullable()->comment('Alergi obat atau makanan');
            $table->text('riwayat_penyakit_kronis')->nullable()->comment('Asma, TBC, Jantung, dll');
            $table->enum('status_kesehatan', [
                'Aktif', 
                'Observasi_Poskestren', 
                'Izin_Asrama', 
                'Izin_Pulang', 
                'Rujukan_RS'
            ])->default('Aktif');
            $table->string('foto_url')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['nis', 'nama_lengkap']);
            $table->index('asrama_komplek');
            $table->index('status_kesehatan');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('santris');
    }
};`
  },
  {
    filename: '2026_01_01_000002_create_obats_table.php',
    category: 'migration',
    title: 'Migration: Table Obats (Apotek Poskestren)',
    description: 'Tabel inventaris dan stok obat Poskestren Al Amien Kediri',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('obats', function (Blueprint $table) {
            $table->id();
            $table->string('kode_obat', 30)->unique();
            $table->string('nama_obat', 150);
            $table->enum('kategori', [
                'Antibiotik',
                'Analgesik & Antipiretik',
                'Antihistamin / Alergi',
                'Obat Kulit / Skabies',
                'Saluran Pencernaan / Maag',
                'Saluran Pernapasan / Batuk',
                'Vitamin & Suplemen',
                'Cairan & Antiseptik'
            ]);
            $table->enum('bentuk_sediaan', [
                'Tablet', 'Kapsul', 'Sirup', 'Salep / Krim', 'Tetes', 'Injeksi', 'Puyer'
            ])->default('Tablet');
            $table->string('satuan', 20)->comment('strip / botol / tube / ampul / pcs');
            $table->integer('stok')->default(0);
            $table->integer('stok_minimum')->default(10);
            $table->date('kadaluarsa');
            $table->text('aturan_pakai_default')->nullable();
            $table->text('keterangan')->nullable();
            $table->timestamps();

            $table->index('kategori');
            $table->index('stok');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('obats');
    }
};`
  },
  {
    filename: '2026_01_01_000003_create_rekam_medis_table.php',
    category: 'migration',
    title: 'Migration: Table Rekam Medis (EHR Santri)',
    description: 'Tabel riwayat periksa santri, keluhan, tanda vital (TTV), diagnosa ICD-10, tindakan klinis',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('rekam_medis', function (Blueprint $table) {
            $table->id();
            $table->string('nomor_rm', 40)->unique();
            $table->foreignId('santri_id')->constrained('santris')->onDelete('cascade');
            $table->dateTime('tanggal_periksa');
            $table->string('petugas_pemeriksa', 120)->comment('Dokter / Ners Poskestren');
            $table->text('keluhan_utama');
            $table->text('riwayat_sekarang')->nullable();
            
            // Vital Signs (TTV)
            $table->string('tekanan_darah', 20)->nullable()->comment('Contoh: 110/70');
            $table->decimal('suhu_tubuh', 4, 1)->comment('Celsius');
            $table->integer('nadi')->nullable()->comment('x/menit');
            $table->integer('laju_napas')->nullable()->comment('x/menit');
            $table->decimal('berat_badan', 5, 2)->nullable()->comment('kg');
            $table->decimal('tinggi_badan', 5, 2)->nullable()->comment('cm');
            
            // Diagnosa & Tindakan
            $table->string('diagnosa_primer', 200);
            $table->string('kode_icd10', 20)->nullable();
            $table->string('diagnosa_sekunder', 200)->nullable();
            $table->text('tindakan_medis')->nullable();
            
            // Status Tindak Lanjut
            $table->enum('status_penanganan', [
                'Rawat Jalan',
                'Observasi Poskestren',
                'Istirahat di Asrama',
                'Izin Pulang ke Rumah',
                'Rujukan Faskes'
            ])->default('Rawat Jalan');
            
            $table->integer('lama_istirahat_hari')->nullable()->default(0);
            $table->text('catatan_petugas')->nullable();
            $table->timestamps();

            $table->index(['santri_id', 'tanggal_periksa']);
            $table->index('diagnosa_primer');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rekam_medis');
    }
};`
  },
  {
    filename: '2026_01_01_000004_create_resep_obats_table.php',
    category: 'migration',
    title: 'Migration: Table Resep Obat (Pivot Detail)',
    description: 'Relasi detail obat yang diresepkan dan mengurangi stok apotek poskestren',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('resep_obats', function (Blueprint $table) {
            $table->id();
            $table->foreignId('rekam_medis_id')->constrained('rekam_medis')->onDelete('cascade');
            $table->foreignId('obat_id')->constrained('obats')->onDelete('restrict');
            $table->integer('jumlah')->default(1);
            $table->string('satuan', 20);
            $table->string('aturan_pakai', 150)->comment('e.g. 3 x 1 tablet sesudah makan');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('resep_obats');
    }
};`
  },
  {
    filename: '2026_01_01_000005_create_surat_izin_dan_rujukan_table.php',
    category: 'migration',
    title: 'Migration: Table Surat Izin & Rujukan RS',
    description: 'Penerbitan surat resmi Poskestren Al-Amien Kediri untuk pengasuhan & RSUD rujukan',
    code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Tabel Surat Keterangan Sakit / Izin Istirahat
        Schema::create('surat_izin_sakits', function (Blueprint $table) {
            $table->id();
            $table->string('nomor_surat', 60)->unique();
            $table->foreignId('rekam_medis_id')->constrained('rekam_medis')->onDelete('cascade');
            $table->foreignId('santri_id')->constrained('santris')->onDelete('cascade');
            $table->date('tanggal_mulai');
            $table->date('tanggal_selesai');
            $table->integer('lama_hari')->default(1);
            $table->enum('rekomendasi', [
                'Istirahat di Ruang Observasi Poskestren',
                'Istirahat di Kamar Asrama',
                'Izin Pemulangan Sementara ke Orang Tua'
            ]);
            $table->string('dokter_pemeriksa', 120);
            $table->string('sip_nip', 80)->nullable();
            $table->date('tanggal_dibuat');
            $table->timestamps();
        });

        // Tabel Surat Pengantar Rujukan ke Faskes / RSUD
        Schema::create('surat_rujukans', function (Blueprint $table) {
            $table->id();
            $table->string('nomor_surat', 60)->unique();
            $table->foreignId('rekam_medis_id')->constrained('rekam_medis')->onDelete('cascade');
            $table->foreignId('santri_id')->constrained('santris')->onDelete('cascade');
            $table->string('tujuan_faskes', 150)->comment('e.g. RSUD Gambiran Kediri / RS Bhayangkara');
            $table->text('alasan_rujukan');
            $table->string('diagnosa_sementara', 200);
            $table->text('tanda_vital');
            $table->text('terapi_awal_diberikan')->nullable();
            $table->string('dokter_perujuk', 120);
            $table->date('tanggal_surat');
            $table->timestamps();
        });

        // Tabel Surat Informed Consent (Khusus Santri Di Bawah Umur < 18 Tahun)
        Schema::create('surat_informed_consents', function (Blueprint $table) {
            $table->id();
            $table->string('nomor_surat', 60)->unique();
            $table->foreignId('rekam_medis_id')->nullable()->constrained('rekam_medis')->onDelete('set null');
            $table->foreignId('santri_id')->constrained('santris')->onDelete('cascade');
            $table->unsignedTinyInteger('santri_umur')->comment('Usia santri saat tindakan');
            $table->string('diagnosa', 200);
            $table->text('tindakan_medis')->comment('Tindakan klinis yang disetujui');
            $table->text('indikasi_tindakan')->nullable();
            $table->text('resiko_penjelasan')->nullable();
            $table->enum('status_persetujuan', ['Setuju', 'Menolak'])->default('Setuju');
            $table->string('nama_ketua_kelompok', 120)->comment('Pemberi Persetujuan / Wali Pengganti');
            $table->string('peran_ketua_kelompok', 100)->default('Ketua Kelompok Santri / Ketua Kamar Asrama');
            $table->string('no_hp_ketua_kelompok', 30)->nullable();
            $table->string('nama_kader_bertugas', 120)->comment('Kader Santri Husada / Petugas Medis Jaga');
            $table->string('dokter_penanggung_jawab', 120)->default('dr. H. Riza Fahmi, Sp.PD');
            $table->string('sip_dokter', 80)->nullable();
            $table->date('tanggal_dibuat');
            $table->text('catatan_tambahan')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('surat_informed_consents');
        Schema::dropIfExists('surat_rujukans');
        Schema::dropIfExists('surat_izin_sakits');
    }
};`
  },
  {
    filename: 'app/Models/SuratInformedConsent.php',
    category: 'model',
    title: 'Eloquent Model: SuratInformedConsent.php',
    description: 'Model Eloquent Persetujuan Tindakan Medis untuk Santri di bawah umur dengan tanda tangan Ketua Kelompok & Kader',
    code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
use Illuminate\\Database\\Eloquent\\Relations\\BelongsTo;

class SuratInformedConsent extends Model
{
    use HasFactory;

    protected $table = 'surat_informed_consents';

    protected $fillable = [
        'nomor_surat',
        'rekam_medis_id',
        'santri_id',
        'santri_umur',
        'diagnosa',
        'tindakan_medis',
        'indikasi_tindakan',
        'resiko_penjelasan',
        'status_persetujuan',
        'nama_ketua_kelompok',
        'peran_ketua_kelompok',
        'no_hp_ketua_kelompok',
        'nama_kader_bertugas',
        'dokter_penanggung_jawab',
        'sip_dokter',
        'tanggal_dibuat',
        'catatan_tambahan',
    ];

    protected $casts = [
        'santri_umur' => 'integer',
        'tanggal_dibuat' => 'date',
    ];

    public function santri(): BelongsTo
    {
        return $this->belongsTo(Santri::class);
    }

    public function rekamMedis(): BelongsTo
    {
        return $this->belongsTo(RekamMedis::class);
    }
}
`
  },
  {
    filename: 'app/Models/Santri.php',
    category: 'model',
    title: 'Eloquent Model: Santri.php',
    description: 'Model Eloquent Santri dengan relasi hasMany ke RekamMedis & Surat',
    code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
use Illuminate\\Database\\Eloquent\\SoftDeletes;
use Illuminate\\Database\\Eloquent\\Relations\\HasMany;

class Santri extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'santris';

    protected $fillable = [
        'nis',
        'nama_lengkap',
        'jenis_kelamin',
        'jenjang_pendidikan',
        'kelas',
        'asrama_komplek',
        'kamar',
        'tempat_lahir',
        'tanggal_lahir',
        'golongan_darah',
        'nama_wali',
        'telepon_wali',
        'alamat_asal',
        'riwayat_alergi',
        'riwayat_penyakit_kronis',
        'status_kesehatan',
        'foto_url'
    ];

    protected $casts = [
        'tanggal_lahir' => 'date',
    ];

    /**
     * Relasi ke seluruh riwayat rekam medis santri di Poskestren Al Amien
     */
    public function rekamMedis(): HasMany
    {
        return $this->hasMany(RekamMedis::class)->orderBy('tanggal_periksa', 'desc');
    }

    /**
     * Relasi ke surat izin sakit santri
     */
    public function suratIzinSakit(): HasMany
    {
        return $this->hasMany(SuratIzinSakit::class);
    }

    /**
     * Relasi ke surat rujukan rumah sakit
     */
    public function suratRujukan(): HasMany
    {
        return $this->hasMany(SuratRujukan::class);
    }

    /**
     * Scope query untuk memfilter asrama atau santri sakit
     */
    public function scopeSedangSakit($query)
    {
        return $query->whereIn('status_kesehatan', ['Observasi_Poskestren', 'Izin_Asrama', 'Rujukan_RS']);
    }
}`
  },
  {
    filename: 'app/Models/RekamMedis.php',
    category: 'model',
    title: 'Eloquent Model: RekamMedis.php',
    description: 'Model Eloquent Rekam Medis dengan relasi belongsTo Santri & hasMany ResepObat',
    code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
use Illuminate\\Database\\Eloquent\\Relations\\BelongsTo;
use Illuminate\\Database\\Eloquent\\Relations\\HasMany;
use Illuminate\\Database\\Eloquent\\Relations\\HasOne;

class RekamMedis extends Model
{
    use HasFactory;

    protected $table = 'rekam_medis';

    protected $fillable = [
        'nomor_rm',
        'santri_id',
        'tanggal_periksa',
        'petugas_pemeriksa',
        'keluhan_utama',
        'riwayat_sekarang',
        'tekanan_darah',
        'suhu_tubuh',
        'nadi',
        'laju_napas',
        'berat_badan',
        'tinggi_badan',
        'diagnosa_primer',
        'kode_icd10',
        'diagnosa_sekunder',
        'tindakan_medis',
        'status_penanganan',
        'lama_istirahat_hari',
        'catatan_petugas'
    ];

    protected $casts = [
        'tanggal_periksa' => 'datetime',
        'suhu_tubuh' => 'float',
        'berat_badan' => 'float',
        'tinggi_badan' => 'float',
    ];

    public function santri(): BelongsTo
    {
        return $this->belongsTo(Santri::class);
    }

    public function resepObat(): HasMany
    {
        return $this->hasMany(ResepObat::class);
    }

    public function suratIzinSakit(): HasOne
    {
        return $this->hasOne(SuratIzinSakit::class);
    }

    public function suratRujukan(): HasOne
    {
        return $this->hasOne(SuratRujukan::class);
    }
}`
  },
  {
    filename: 'app/Models/Obat.php',
    category: 'model',
    title: 'Eloquent Model: Obat.php',
    description: 'Model Eloquent Obat Poskestren dengan helper cek stok minimum',
    code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Model;
use Illuminate\\Database\\Eloquent\\Relations\\HasMany;

class Obat extends Model
{
    use HasFactory;

    protected $table = 'obats';

    protected $fillable = [
        'kode_obat',
        'nama_obat',
        'kategori',
        'bentuk_sediaan',
        'satuan',
        'stok',
        'stok_minimum',
        'kadaluarsa',
        'aturan_pakai_default',
        'keterangan'
    ];

    protected $casts = [
        'kadaluarsa' => 'date',
        'stok' => 'integer',
        'stok_minimum' => 'integer',
    ];

    public function resepDetail(): HasMany
    {
        return $this->hasMany(ResepObat::class);
    }

    /**
     * Cek apakah stok obat di bawah batas kritis
     */
    public function getIsMenipisAttribute(): bool
    {
        return $this->stok <= $this->stok_minimum;
    }
}`
  },
  {
    filename: 'app/Http/Controllers/RekamMedisController.php',
    category: 'controller',
    title: 'Laravel API Controller: RekamMedisController.php',
    description: 'Controller untuk melayani API pemeriksaan santri dengan transaksi DB & potong stok obat otomatis',
    code: `<?php

namespace App\\Http\\Controllers;

use App\\Models\\RekamMedis;
use App\\Models\\Santri;
use App\\Models\\Obat;
use App\\Models\\ResepObat;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\DB;

class RekamMedisController extends Controller
{
    /**
     * Simpan rekam medis baru santri Poskestren Al Amien Kediri
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'santri_id' => 'required|exists:santris,id',
            'keluhan_utama' => 'required|string',
            'suhu_tubuh' => 'required|numeric|between:34,43',
            'tekanan_darah' => 'nullable|string',
            'diagnosa_primer' => 'required|string',
            'kode_icd10' => 'nullable|string',
            'status_penanganan' => 'required|in:Rawat Jalan,Observasi Poskestren,Istirahat di Asrama,Izin Pulang ke Rumah,Rujukan Rumah Sakit',
            'resep' => 'nullable|array',
            'resep.*.obat_id' => 'required|exists:obats,id',
            'resep.*.jumlah' => 'required|integer|min:1',
            'resep.*.aturan_pakai' => 'required|string',
        ]);

        return DB::transaction(function () use ($validated, $request) {
            // 1. Generate nomor RM unik
            $nomorRM = 'RM-' . date('Ym') . '-' . str_pad(RekamMedis::whereMonth('created_at', date('m'))->count() + 1, 3, '0', STR_PAD_LEFT);

            // 2. Buat rekam medis
            $rm = RekamMedis::create([
                'nomor_rm' => $nomorRM,
                'santri_id' => $validated['santri_id'],
                'tanggal_periksa' => now(),
                'petugas_pemeriksa' => auth()->user()->name ?? 'dr. Poskestren Al Amien',
                'keluhan_utama' => $validated['keluhan_utama'],
                'riwayat_sekarang' => $request->input('riwayat_sekarang'),
                'tekanan_darah' => $validated['tekanan_darah'],
                'suhu_tubuh' => $validated['suhu_tubuh'],
                'nadi' => $request->input('nadi'),
                'laju_napas' => $request->input('laju_napas'),
                'berat_badan' => $request->input('berat_badan'),
                'tinggi_badan' => $request->input('tinggi_badan'),
                'diagnosa_primer' => $validated['diagnosa_primer'],
                'kode_icd10' => $validated['kode_icd10'],
                'tindakan_medis' => $request->input('tindakan_medis'),
                'status_penanganan' => $validated['status_penanganan'],
                'lama_istirahat_hari' => $request->input('lama_istirahat_hari', 0),
                'catatan_petugas' => $request->input('catatan_petugas'),
            ]);

            // 3. Update status kesehatan santri
            $santri = Santri::findOrFail($validated['santri_id']);
            $statusMap = [
                'Rawat Jalan' => 'Aktif',
                'Observasi Poskestren' => 'Observasi_Poskestren',
                'Istirahat di Asrama' => 'Izin_Asrama',
                'Izin Pulang ke Rumah' => 'Izin_Pulang',
                'Rujukan Faskes' => 'Rujukan_RS',
            ];
            $santri->update(['status_kesehatan' => $statusMap[$validated['status_penanganan']]]);

            // 4. Potong stok obat & simpan resep
            if (!empty($validated['resep'])) {
                foreach ($validated['resep'] as $item) {
                    $obat = Obat::findOrFail($item['obat_id']);
                    $obat->decrement('stok', $item['jumlah']);

                    ResepObat::create([
                        'rekam_medis_id' => $rm->id,
                        'obat_id' => $obat->id,
                        'jumlah' => $item['jumlah'],
                        'satuan' => $obat->satuan,
                        'aturan_pakai' => $item['aturan_pakai'],
                    ]);
                }
            }

            return response()->json([
                'success' => true,
                'message' => 'Pemeriksaan santri berhasil dicatat',
                'data' => $rm->load(['santri', 'resepObat.obat'])
            ], 201);
        });
    }
}`
  },
  {
    filename: 'database/seeders/DatabaseSeeder.php',
    category: 'seeder',
    title: 'Laravel Database Seeder: DatabaseSeeder.php',
    description: 'Seeder data awal santri, inventaris obat poskestren, dan contoh rekam medis',
    code: `<?php

namespace Database\\Seeders;

use Illuminate\\Database\\Seeder;
use App\\Models\\Santri;
use App\\Models\\Obat;
use App\\Models\\RekamMedis;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Seeder Master Obat Poskestren Al Amien
        $obats = [
            [
                'kode_obat' => 'OBT-SKB-01',
                'nama_obat' => 'Permethrin Cream 5% 30g (Scabicid)',
                'kategori' => 'Obat Kulit / Skabies',
                'bentuk_sediaan' => 'Salep / Krim',
                'satuan' => 'tube',
                'stok' => 15,
                'stok_minimum' => 10,
                'kadaluarsa' => '2027-08-30',
                'aturan_pakai_default' => 'Oleskan merata malam hari, bilas 8-10 jam'
            ],
            [
                'kode_obat' => 'OBT-ANP-01',
                'nama_obat' => 'Paracetamol 500 mg',
                'kategori' => 'Analgesik & Antipiretik',
                'bentuk_sediaan' => 'Tablet',
                'satuan' => 'strip',
                'stok' => 65,
                'stok_minimum' => 20,
                'kadaluarsa' => '2027-12-15',
                'aturan_pakai_default' => '3 x 1 tablet sehari sesudah makan'
            ],
            [
                'kode_obat' => 'OBT-MGG-01',
                'nama_obat' => 'Antasida Doen Chewable',
                'kategori' => 'Saluran Pencernaan / Maag',
                'bentuk_sediaan' => 'Tablet',
                'satuan' => 'strip',
                'stok' => 42,
                'stok_minimum' => 15,
                'kadaluarsa' => '2027-05-10',
                'aturan_pakai_default' => '3 x 1 tablet dikunyah 1 jam sebelum makan'
            ]
        ];

        foreach ($obats as $obt) {
            Obat::create($obt);
        }

        // Seeder Santri Awal
        Santri::create([
            'nis' => '2024.01.0042',
            'nama_lengkap' => 'Muhammad Fadhil Al-Hafidz',
            'jenis_kelamin' => 'L',
            'jenjang_pendidikan' => 'MA Al Amien',
            'kelas' => 'XI IPA 1',
            'asrama_komplek' => 'Asrama Sunan Giri (Putra)',
            'kamar' => 'Kamar B-03',
            'tempat_lahir' => 'Kediri',
            'tanggal_lahir' => '2008-04-14',
            'golongan_darah' => 'O',
            'nama_wali' => 'H. Suwarno, M.Pd',
            'telepon_wali' => '081234567890',
            'alamat_asal' => 'Kec. Pare, Kab. Kediri',
            'riwayat_alergi' => 'Alergi Dingin, Udang',
            'riwayat_penyakit_kronis' => 'Asma Bronkiale',
            'status_kesehatan' => 'Observasi_Poskestren',
        ]);
    }
}`
  },
  {
    filename: 'dek_santri_poskestren_mysql.sql',
    category: 'sql',
    title: 'MySQL DDL / SQL Schema Dump',
    description: 'Skrip SQL murni (DDL & DML) untuk langsung di-import via phpMyAdmin atau MySQL Workbench',
    code: `-- =======================================================
-- DEK SANTRI: Digitalisasi Pengelolaan Data & Riwayat Kesehatan Santri
-- Poskestren Pondok Pesantren Al-Amien Kediri, Jawa Timur
-- Database Engine: MySQL 8.0+ / MariaDB 10.4+ (Laravel Compatible)
-- =======================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS resep_obats;
DROP TABLE IF EXISTS surat_rujukans;
DROP TABLE IF EXISTS surat_izin_sakits;
DROP TABLE IF EXISTS rekam_medis;
DROP TABLE IF EXISTS obats;
DROP TABLE IF EXISTS santris;
DROP TABLE IF EXISTS petugas_poskestrens;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Tabel Santri
CREATE TABLE santris (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nis VARCHAR(30) NOT NULL UNIQUE,
  nama_lengkap VARCHAR(150) NOT NULL,
  jenis_kelamin ENUM('L', 'P') NOT NULL,
  jenjang_pendidikan VARCHAR(50) NOT NULL,
  kelas VARCHAR(30) NOT NULL,
  asrama_komplek VARCHAR(100) NOT NULL,
  kamar VARCHAR(50) NOT NULL,
  tempat_lahir VARCHAR(80) NULL,
  tanggal_lahir DATE NULL,
  golongan_darah ENUM('A', 'B', 'AB', 'O', '-') DEFAULT '-',
  nama_wali VARCHAR(120) NOT NULL,
  telepon_wali VARCHAR(30) NOT NULL,
  alamat_asal TEXT NULL,
  riwayat_alergi TEXT NULL,
  riwayat_penyakit_kronis TEXT NULL,
  status_kesehatan ENUM('Aktif', 'Observasi_Poskestren', 'Izin_Asrama', 'Izin_Pulang', 'Rujukan_RS') DEFAULT 'Aktif',
  foto_url VARCHAR(255) NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP NULL,
  INDEX idx_santri_asrama (asrama_komplek),
  INDEX idx_santri_status (status_kesehatan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Tabel Master Obat Poskestren
CREATE TABLE obats (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kode_obat VARCHAR(30) NOT NULL UNIQUE,
  nama_obat VARCHAR(150) NOT NULL,
  kategori ENUM('Antibiotik', 'Analgesik & Antipiretik', 'Antihistamin / Alergi', 'Obat Kulit / Skabies', 'Saluran Pencernaan / Maag', 'Saluran Pernapasan / Batuk', 'Vitamin & Suplemen', 'Cairan & Antiseptik') NOT NULL,
  bentuk_sediaan ENUM('Tablet', 'Kapsul', 'Sirup', 'Salep / Krim', 'Tetes', 'Injeksi', 'Puyer') DEFAULT 'Tablet',
  satuan VARCHAR(20) NOT NULL,
  stok INT NOT NULL DEFAULT 0,
  stok_minimum INT NOT NULL DEFAULT 10,
  kadaluarsa DATE NOT NULL,
  aturan_pakai_default TEXT NULL,
  keterangan TEXT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Tabel Rekam Medis (EHR)
CREATE TABLE rekam_medis (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nomor_rm VARCHAR(40) NOT NULL UNIQUE,
  santri_id BIGINT UNSIGNED NOT NULL,
  tanggal_periksa DATETIME NOT NULL,
  petugas_pemeriksa VARCHAR(120) NOT NULL,
  keluhan_utama TEXT NOT NULL,
  riwayat_sekarang TEXT NULL,
  tekanan_darah VARCHAR(20) NULL,
  suhu_tubuh DECIMAL(4, 1) NOT NULL,
  nadi INT NULL,
  laju_napas INT NULL,
  berat_badan DECIMAL(5, 2) NULL,
  tinggi_badan DECIMAL(5, 2) NULL,
  diagnosa_primer VARCHAR(200) NOT NULL,
  kode_icd10 VARCHAR(20) NULL,
  diagnosa_sekunder VARCHAR(200) NULL,
  tindakan_medis TEXT NULL,
  status_penanganan ENUM('Rawat Jalan', 'Observasi Poskestren', 'Istirahat di Asrama', 'Izin Pulang ke Rumah', 'Rujukan Rumah Sakit') DEFAULT 'Rawat Jalan',
  lama_istirahat_hari INT DEFAULT 0,
  catatan_petugas TEXT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (santri_id) REFERENCES santris(id) ON DELETE CASCADE,
  INDEX idx_rm_tanggal (tanggal_periksa)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Tabel Detail Resep Obat
CREATE TABLE resep_obats (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  rekam_medis_id BIGINT UNSIGNED NOT NULL,
  obat_id BIGINT UNSIGNED NOT NULL,
  jumlah INT NOT NULL DEFAULT 1,
  satuan VARCHAR(20) NOT NULL,
  aturan_pakai VARCHAR(150) NOT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (rekam_medis_id) REFERENCES rekam_medis(id) ON DELETE CASCADE,
  FOREIGN KEY (obat_id) REFERENCES obats(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Tabel Surat Keterangan Sakit
CREATE TABLE surat_izin_sakits (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nomor_surat VARCHAR(60) NOT NULL UNIQUE,
  rekam_medis_id BIGINT UNSIGNED NOT NULL,
  santri_id BIGINT UNSIGNED NOT NULL,
  tanggal_mulai DATE NOT NULL,
  tanggal_selesai DATE NOT NULL,
  lama_hari INT NOT NULL DEFAULT 1,
  rekomendasi ENUM('Istirahat di Ruang Observasi Poskestren', 'Istirahat di Kamar Asrama', 'Izin Pemulangan Sementara ke Orang Tua') NOT NULL,
  dokter_pemeriksa VARCHAR(120) NOT NULL,
  sip_nip VARCHAR(80) NULL,
  tanggal_dibuat DATE NOT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (rekam_medis_id) REFERENCES rekam_medis(id) ON DELETE CASCADE,
  FOREIGN KEY (santri_id) REFERENCES santris(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Tabel Surat Pengantar Rujukan RS
CREATE TABLE surat_rujukans (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nomor_surat VARCHAR(60) NOT NULL UNIQUE,
  rekam_medis_id BIGINT UNSIGNED NOT NULL,
  santri_id BIGINT UNSIGNED NOT NULL,
  tujuan_faskes VARCHAR(150) NOT NULL,
  alasan_rujukan TEXT NOT NULL,
  diagnosa_sementara VARCHAR(200) NOT NULL,
  tanda_vital TEXT NOT NULL,
  terapi_awal_diberikan TEXT NULL,
  dokter_perujuk VARCHAR(120) NOT NULL,
  tanggal_surat DATE NOT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (rekam_medis_id) REFERENCES rekam_medis(id) ON DELETE CASCADE,
  FOREIGN KEY (santri_id) REFERENCES santris(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
  }
];
