export type Gender = 'L' | 'P'; // L = Banin (Putra), P = Banat (Putri)

export type StatusSantri = 'Aktif' | 'Observasi_Poskestren' | 'Izin_Asrama' | 'Izin_Pulang' | 'Rujukan_RS';

export interface Santri {
  id: string; // matches Laravel ID or UUID
  nis: string; // Nomor Induk Santri (unique)
  nama_lengkap: string;
  jenis_kelamin: Gender;
  jenjang_pendidikan: 'MTs Al Amien' | 'MA Al Amien' | 'KMI / Kepengasuhan' | 'Tahfidz';
  kelas: string;
  asrama_komplek: string; // e.g. Asrama Al-Farabi, Asrama Khodijah, dll
  kamar: string;
  tempat_lahir: string;
  tanggal_lahir: string;
  golongan_darah: 'A' | 'B' | 'AB' | 'O' | '-';
  nama_wali: string;
  telepon_wali: string;
  alamat_asal: string;
  riwayat_alergi: string; // e.g. "Alergi Penisilin, Seafood"
  riwayat_penyakit_kronis: string; // e.g. "Asma Bronkiale"
  status_kesehatan: StatusSantri;
  foto_url?: string;
  created_at: string;
  updated_at: string;
}

export interface Obat {
  id: string;
  kode_obat: string;
  nama_obat: string;
  kategori: 'Antibiotik' | 'Analgesik & Antipiretik' | 'Antihistamin / Alergi' | 'Obat Kulit / Skabies' | 'Saluran Pencernaan / Maag' | 'Saluran Pernapasan / Batuk' | 'Vitamin & Suplemen' | 'Cairan & Antiseptik';
  bentuk_sediaan: 'Tablet' | 'Kaplet' | 'Kapsul' | 'Sirup' | 'Salep / Krim' | 'Tetes' | 'Injeksi' | 'Puyer' | 'Cairan';
  satuan: 'strip' | 'botol' | 'tube' | 'ampul' | 'pcs';
  stok: number;
  stok_minimum: number;
  kadaluarsa: string;
  aturan_pakai_default: string;
  keterangan?: string;
}

export interface ResepDetail {
  obat_id: string;
  nama_obat: string;
  jumlah: number;
  satuan: string;
  aturan_pakai: string; // e.g. "3x1 hari sesudah makan"
}

export type StatusPenanganan = 'Rawat Jalan' | 'Observasi Poskestren' | 'Istirahat di Asrama' | 'Izin Pulang ke Rumah' | 'Rujukan Rumah Sakit' | 'Rujukan Faskes';

export interface RekamMedis {
  id: string;
  nomor_rm: string; // e.g. RM-202609-001
  santri_id: string;
  santri_nis: string;
  santri_nama: string;
  santri_asrama: string;
  tanggal_periksa: string; // YYYY-MM-DD HH:mm
  petugas_pemeriksa: string; // dr. Ahmad / Ns. Fatimah
  keluhan_utama: string; // Anamnesa
  riwayat_sekarang: string;
  // Vital Signs
  tekanan_darah: string; // mmHg e.g. 110/70
  suhu_tubuh: number; // Celsius e.g. 38.2
  nadi: number; // bpm e.g. 84
  laju_napas: number; // x/menit e.g. 20
  berat_badan?: number; // kg
  tinggi_badan?: number; // cm
  // Diagnosis
  diagnosa_primer: string; // e.g. Scabies (Kudis), ISPA, Gastritis Akut
  kode_icd10?: string; // e.g. B86, J06.9, K29.7
  diagnosa_sekunder?: string;
  tindakan_medis: string; // Perawatan luka, kompres hangat, nebulizer
  resep_obat: ResepDetail[];
  status_penanganan: StatusPenanganan;
  lama_istirahat_hari?: number;
  catatan_petugas?: string;
  created_at: string;
}

export interface SuratIzinSakit {
  id: string;
  nomor_surat: string; // e.g. 102/POSKESTREN-AA/SK/IX/2026
  rekam_medis_id: string;
  santri_id: string;
  santri_nama: string;
  santri_nis: string;
  asrama_kamar: string;
  kelas_jenjang: string;
  diagnosa: string;
  tanggal_mulai: string;
  tanggal_selesai: string;
  lama_hari: number;
  rekomendasi: 'Istirahat di Ruang Observasi Poskestren' | 'Istirahat di Kamar Asrama' | 'Izin Pemulangan Sementara ke Orang Tua';
  dokter_pemeriksa: string;
  sip_nip: string;
  tanggal_dibuat: string;
}

export interface SuratRujukan {
  id: string;
  nomor_surat: string; // e.g. 045/POSKESTREN-AA/RUJUK/IX/2026
  rekam_medis_id: string;
  santri_id: string;
  santri_nama: string;
  santri_nis: string;
  tanggal_lahir: string;
  tujuan_faskes: string; // e.g. RSUD Gambiran Kota Kediri / RS Bhayangkara Kediri / Puskesmas Pesantren
  alasan_rujukan: string;
  diagnosa_sementara: string;
  tanda_vital: string;
  terapi_awal_diberikan: string;
  dokter_perujuk: string;
  tanggal_surat: string;
}

export interface PetugasPoskestren {
  id: string;
  nama: string;
  peran: 'Dokter Penanggung Jawab' | 'Perawat / Ners' | 'Apoteker / Farmasi' | 'Kader Santri Husada';
  sip_str?: string;
  telepon: string;
  status_jaga: 'Bertugas Hari Ini' | 'Off' | 'On Call';
}

export interface SuratInformedConsent {
  id: string;
  nomor_surat: string; // e.g. 012/POSKESTREN-AA/IC/IX/2026
  rekam_medis_id?: string;
  santri_id: string;
  santri_nama: string;
  santri_nis: string;
  santri_umur: number;
  santri_tanggal_lahir: string;
  santri_jk: Gender;
  asrama_kamar: string;
  kelas_jenjang: string;
  diagnosa: string;
  tindakan_medis: string; // Prosedur medis/observasi/terapi yang disetujui
  indikasi_tindakan?: string;
  resiko_penjelasan?: string;
  status_persetujuan: 'Setuju' | 'Menolak';
  // Tanda Tangan & Identitas Pihak (Ketua Kelompok & Kader yang Bertugas)
  nama_ketua_kelompok: string;
  peran_ketua_kelompok: string; // e.g. "Ketua Kelompok Kamar / Pendamping Santri"
  no_hp_ketua_kelompok?: string;
  nama_kader_bertugas: string; // e.g. "Ustadz Wildan (Kader Santri Husada)"
  dokter_penanggung_jawab: string;
  sip_dokter?: string;
  tanggal_dibuat: string;
  catatan_tambahan?: string;
}

export type NavTab = 'dashboard' | 'santri' | 'rekam-medis' | 'apotek' | 'surat' | 'laporan' | 'laravel';

export type PeriodeLaporan = 'harian' | 'bulanan' | 'trimester' | 'semester';
