import React from 'react';
import { 
  Menu, 
  CalendarDays, 
  PlusCircle, 
  ShieldAlert, 
  Activity, 
  Users, 
  FileText, 
  Pill, 
  Award, 
  BarChart3, 
  Database,
  Building
} from 'lucide-react';
import { NavTab } from '../types';

interface TopbarProps {
  activeTab: NavTab;
  onOpenMobileSidebar: () => void;
  onOpenNewPeriksa: () => void;
  santriSakitCount: number;
}

export const Topbar: React.FC<TopbarProps> = ({
  activeTab,
  onOpenMobileSidebar,
  onOpenNewPeriksa,
  santriSakitCount,
}) => {
  const getTabInfo = () => {
    switch (activeTab) {
      case 'dashboard':
        return {
          title: 'Dashboard & Pantauan Poskestren',
          subtitle: 'Surveilans epidemiologi dan kondisi kesehatan santri Pondok Pesantren Al-Amien Kediri',
          icon: Activity,
        };
      case 'santri':
        return {
          title: 'Master Data Santri (Banin & Banat)',
          subtitle: 'Basis data kesehatan, alergi, asrama, dan buku rekam kesehatan santri',
          icon: Users,
        };
      case 'rekam-medis':
        return {
          title: 'Buku Registrasi Rekam Medis (EHR)',
          subtitle: 'Pencatatan pemeriksaan klinis, TTV, diagnosa ICD-10, dan terapi obat',
          icon: FileText,
        };
      case 'apotek':
        return {
          title: 'Instalasi Farmasi & Apotek Poskestren',
          subtitle: 'Pengelolaan inventaris obat-obatan, peringatan stok menipis, dan restock farmasi',
          icon: Pill,
        };
      case 'surat':
        return {
          title: 'Penerbitan Surat Izin Sakit & Rujukan RS',
          subtitle: 'Format resmi kop surat Poskestren Al-Amien Kediri untuk pengasuhan & rumah sakit',
          icon: Award,
        };
      case 'laporan':
        return {
          title: 'Laporan Kesehatan Santri Terpadu',
          subtitle: 'Rekapitulasi Harian, Bulanan, Trimester (3 Bulanan), dan 6 Bulanan (Semesteran)',
          icon: BarChart3,
        };
      case 'laravel':
        return {
          title: 'Arsitektur Database Laravel & MySQL',
          subtitle: 'Migrations, Eloquent Models, Controller transaksi apotek, dan SQL DDL live export',
          icon: Database,
        };
    }
  };

  const currentInfo = getTabInfo();
  const Icon = currentInfo.icon;

  const todayStr = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-stone-200 px-4 sm:px-6 py-3.5 flex items-center justify-between shadow-xs">
      {/* Left: Mobile Toggle & Page Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileSidebar}
          className="lg:hidden p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
          aria-label="Buka Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-800 shrink-0 hidden sm:flex">
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-stone-900 leading-tight">
                {currentInfo.title}
              </h2>
            </div>
            <p className="text-xs text-stone-500 hidden md:block">
              {currentInfo.subtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Right: Date, Alert Badge, and Action Button */}
      <div className="flex items-center gap-3">
        {/* Date display */}
        <div className="hidden xl:flex items-center gap-1.5 text-xs text-stone-600 bg-stone-50 px-3 py-1.5 rounded-xl border border-stone-200">
          <CalendarDays className="w-3.5 h-3.5 text-emerald-700" />
          <span className="font-medium">{todayStr}</span>
        </div>

        {/* Santri Sakit Badge */}
        {santriSakitCount > 0 && (
          <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            <span>{santriSakitCount} Santri Sakit</span>
          </div>
        )}

        {/* Quick Checkup Button */}
        <button
          onClick={onOpenNewPeriksa}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-all cursor-pointer whitespace-nowrap"
        >
          <PlusCircle className="w-4 h-4" />
          <span className="hidden sm:inline">Pemeriksaan Baru</span>
          <span className="sm:hidden">Periksa</span>
        </button>
      </div>
    </header>
  );
};
