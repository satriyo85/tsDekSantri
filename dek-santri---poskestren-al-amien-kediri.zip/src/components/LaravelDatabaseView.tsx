import React, { useState } from 'react';
import { 
  Database, 
  Code2, 
  Copy, 
  Check, 
  Download, 
  FolderTree, 
  FileCode, 
  Terminal, 
  Layers, 
  Network, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { laravelFiles, LaravelFile } from '../data/laravelSchema';
import { Santri, RekamMedis, Obat } from '../types';

interface LaravelDatabaseViewProps {
  santriList: Santri[];
  rekamMedisList: RekamMedis[];
  obatList: Obat[];
}

export const LaravelDatabaseView: React.FC<LaravelDatabaseViewProps> = ({
  santriList,
  rekamMedisList,
  obatList,
}) => {
  const [selectedFile, setSelectedFile] = useState<LaravelFile>(laravelFiles[0]);
  const [copied, setCopied] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'files' | 'erd' | 'export'>('files');

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename.split('/').pop() || 'laravel_file.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Generate dynamic live SQL dump of current app state
  const generateCurrentLiveSQL = () => {
    let sql = `-- =======================================================\n`;
    sql += `-- LIVE DATA EXPORT: DEK SANTRI POSKESTREN AL-AMIEN KEDIRI\n`;
    sql += `-- Generated: ${new Date().toISOString()}\n`;
    sql += `-- =======================================================\n\n`;

    // Santri Inserts
    sql += `-- INSERT DATA SANTRIS (${santriList.length} Baris)\n`;
    santriList.forEach(s => {
      sql += `INSERT INTO santris (id, nis, nama_lengkap, jenis_kelamin, jenjang_pendidikan, kelas, asrama_komplek, kamar, tempat_lahir, tanggal_lahir, golongan_darah, nama_wali, telepon_wali, alamat_asal, riwayat_alergi, riwayat_penyakit_kronis, status_kesehatan, created_at, updated_at) VALUES ('${s.id}', '${s.nis}', '${s.nama_lengkap.replace(/'/g, "''")}', '${s.jenis_kelamin}', '${s.jenjang_pendidikan}', '${s.kelas}', '${s.asrama_komplek}', '${s.kamar}', '${s.tempat_lahir}', '${s.tanggal_lahir}', '${s.golongan_darah}', '${s.nama_wali.replace(/'/g, "''")}', '${s.telepon_wali}', '${s.alamat_asal.replace(/'/g, "''")}', '${(s.riwayat_alergi || '').replace(/'/g, "''")}', '${(s.riwayat_penyakit_kronis || '').replace(/'/g, "''")}', '${s.status_kesehatan}', NOW(), NOW());\n`;
    });

    // Obat Inserts
    sql += `\n-- INSERT DATA OBATS (${obatList.length} Baris)\n`;
    obatList.forEach(o => {
      sql += `INSERT INTO obats (id, kode_obat, nama_obat, kategori, bentuk_sediaan, satuan, stok, stok_minimum, kadaluarsa, aturan_pakai_default, keterangan, created_at, updated_at) VALUES ('${o.id}', '${o.kode_obat}', '${o.nama_obat.replace(/'/g, "''")}', '${o.kategori}', '${o.bentuk_sediaan}', '${o.satuan}', ${o.stok}, ${o.stok_minimum}, '${o.kadaluarsa}', '${(o.aturan_pakai_default || '').replace(/'/g, "''")}', '${(o.keterangan || '').replace(/'/g, "''")}', NOW(), NOW());\n`;
    });

    // Rekam Medis Inserts
    sql += `\n-- INSERT DATA REKAM MEDIS (${rekamMedisList.length} Baris)\n`;
    rekamMedisList.forEach(rm => {
      sql += `INSERT INTO rekam_medis (id, nomor_rm, santri_id, tanggal_periksa, petugas_pemeriksa, keluhan_utama, tekanan_darah, suhu_tubuh, nadi, laju_napas, diagnosa_primer, kode_icd10, tindakan_medis, status_penanganan, created_at, updated_at) VALUES ('${rm.id}', '${rm.nomor_rm}', '${rm.santri_id}', '${rm.tanggal_periksa}', '${rm.petugas_pemeriksa}', '${rm.keluhan_utama.replace(/'/g, "''")}', '${rm.tekanan_darah || ''}', ${rm.suhu_tubuh}, ${rm.nadi || 'NULL'}, ${rm.laju_napas || 'NULL'}, '${rm.diagnosa_primer.replace(/'/g, "''")}', '${rm.kode_icd10 || ''}', '${(rm.tindakan_medis || '').replace(/'/g, "''")}', '${rm.status_penanganan}', NOW(), NOW());\n`;
    });

    return sql;
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-stone-900 to-emerald-950 text-white p-6 rounded-2xl border border-stone-800 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-semibold border border-amber-500/30">
              <Database className="w-3.5 h-3.5" />
              Laravel Eloquent &amp; Migrations Hub
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
              Arsitektur Database Laravel "DEK SANTRI" Poskestren
            </h2>
            <p className="text-stone-300 text-xs leading-relaxed max-w-2xl">
              Seluruh struktur database relasional (Migrations, Eloquent Models, Controller transaksi apotek, dan skrip SQL MySQL) siap pakai untuk diintegrasikan ke framework Laravel 11/12 Anda.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-stone-800/80 p-1.5 rounded-xl border border-stone-700 text-xs">
            <button
              onClick={() => setActiveSubTab('files')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeSubTab === 'files' ? 'bg-amber-500 text-stone-950 shadow-sm' : 'text-stone-300 hover:text-white'
              }`}
            >
              File Laravel ({laravelFiles.length})
            </button>
            <button
              onClick={() => setActiveSubTab('erd')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeSubTab === 'erd' ? 'bg-amber-500 text-stone-950 shadow-sm' : 'text-stone-300 hover:text-white'
              }`}
            >
              Diagram ERD Relasi
            </button>
            <button
              onClick={() => setActiveSubTab('export')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeSubTab === 'export' ? 'bg-amber-500 text-stone-950 shadow-sm' : 'text-stone-300 hover:text-white'
              }`}
            >
              Ekspor Live SQL
            </button>
          </div>
        </div>
      </div>

      {/* Subtab 1: File Browser & Code Viewer */}
      {activeSubTab === 'files' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* File Tree List */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-stone-200 shadow-xs p-4 space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-stone-100">
              <FolderTree className="w-4 h-4 text-emerald-700" />
              <h3 className="font-bold text-stone-900 text-xs uppercase tracking-wider">
                Struktur File Laravel
              </h3>
            </div>

            <div className="space-y-1">
              {laravelFiles.map((file, idx) => {
                const isSelected = selectedFile.filename === file.filename;
                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left p-2.5 rounded-xl text-xs transition-all flex items-start gap-2.5 ${
                      isSelected
                        ? 'bg-amber-50 text-amber-950 font-bold border border-amber-300 shadow-xs'
                        : 'hover:bg-stone-50 text-stone-700 border border-transparent'
                    }`}
                  >
                    <FileCode className={`w-4 h-4 shrink-0 mt-0.5 ${isSelected ? 'text-amber-600' : 'text-stone-400'}`} />
                    <div className="overflow-hidden">
                      <div className="truncate">{file.title}</div>
                      <div className="text-[10px] text-stone-400 font-mono truncate">{file.filename}</div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Quick Artisan Tip */}
            <div className="mt-4 p-3 rounded-xl bg-stone-900 text-stone-200 text-xs font-mono space-y-1.5 border border-stone-800">
              <div className="text-[10px] text-stone-400 flex items-center gap-1">
                <Terminal className="w-3.5 h-3.5 text-amber-400" />
                <span>Perintah Eksekusi di Terminal Laravel:</span>
              </div>
              <div className="text-amber-300 text-[11px] font-semibold">php artisan migrate</div>
              <div className="text-stone-400 text-[11px]">php artisan db:seed</div>
            </div>
          </div>

          {/* Code Viewer */}
          <div className="lg:col-span-8 bg-stone-950 text-stone-100 rounded-2xl shadow-lg border border-stone-800 overflow-hidden">
            {/* Viewer Toolbar */}
            <div className="bg-stone-900/90 border-b border-stone-800 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Code2 className="w-4 h-4 text-amber-400" />
                <span className="font-mono text-xs text-amber-200 font-bold">{selectedFile.filename}</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-stone-800 text-stone-300 border border-stone-700 uppercase font-semibold">
                  {selectedFile.category}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold border border-stone-700 transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-stone-300" />}
                  <span>{copied ? 'Tersalin!' : 'Salin Kode'}</span>
                </button>

                <button
                  onClick={() => handleDownload(selectedFile.filename, selectedFile.code)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-stone-950 text-xs font-bold transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File</span>
                </button>
              </div>
            </div>

            {/* Description bar */}
            <div className="px-4 py-2 bg-stone-900 text-stone-400 text-[11px] border-b border-stone-800/80">
              {selectedFile.description}
            </div>

            {/* Code Body */}
            <div className="p-4 max-h-[600px] overflow-auto font-mono text-xs text-stone-200 leading-relaxed no-scrollbar select-all">
              <pre>
                <code>{selectedFile.code}</code>
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 2: ERD Relational Diagram */}
      {activeSubTab === 'erd' && (
        <div className="bg-white rounded-2xl p-6 border border-stone-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <div>
              <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                <Network className="w-5 h-5 text-emerald-700" />
                <span>Entity Relationship Diagram (ERD) Poskestren Al Amien</span>
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Struktur relasi antar tabel database Laravel: Santri, Rekam Medis, Apotek Obat, dan Surat Resmi
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Table 1: santris */}
            <div className="rounded-xl border border-emerald-300 bg-emerald-50/40 overflow-hidden shadow-xs">
              <div className="bg-emerald-800 text-white px-3 py-2 text-xs font-bold flex items-center justify-between">
                <span>TABLE: santris</span>
                <span className="text-[10px] bg-emerald-700 px-1.5 rounded">PK: id</span>
              </div>
              <div className="p-3 text-xs space-y-1 font-mono text-stone-700 divide-y divide-emerald-100">
                <div className="text-emerald-900 font-bold">id (BIGINT PK)</div>
                <div>nis (VARCHAR UNIQUE)</div>
                <div>nama_lengkap (VARCHAR)</div>
                <div>jenis_kelamin (ENUM: L, P)</div>
                <div>asrama_komplek (VARCHAR)</div>
                <div>kamar (VARCHAR)</div>
                <div>golongan_darah (ENUM)</div>
                <div>riwayat_alergi (TEXT)</div>
                <div>status_kesehatan (ENUM)</div>
                <div>created_at / updated_at</div>
              </div>
            </div>

            {/* Table 2: rekam_medis */}
            <div className="rounded-xl border border-teal-300 bg-teal-50/40 overflow-hidden shadow-xs">
              <div className="bg-teal-800 text-white px-3 py-2 text-xs font-bold flex items-center justify-between">
                <span>TABLE: rekam_medis</span>
                <span className="text-[10px] bg-teal-700 px-1.5 rounded">FK: santri_id</span>
              </div>
              <div className="p-3 text-xs space-y-1 font-mono text-stone-700 divide-y divide-teal-100">
                <div className="text-teal-900 font-bold">id (BIGINT PK)</div>
                <div>nomor_rm (VARCHAR UNIQUE)</div>
                <div className="text-emerald-800 font-semibold">&rarr; santri_id (FK: santris.id)</div>
                <div>tanggal_periksa (DATETIME)</div>
                <div>keluhan_utama (TEXT)</div>
                <div>tekanan_darah (VARCHAR)</div>
                <div>suhu_tubuh (DECIMAL)</div>
                <div>diagnosa_primer (VARCHAR)</div>
                <div>kode_icd10 (VARCHAR)</div>
                <div>status_penanganan (ENUM)</div>
              </div>
            </div>

            {/* Table 3: obats */}
            <div className="rounded-xl border border-amber-300 bg-amber-50/40 overflow-hidden shadow-xs">
              <div className="bg-amber-800 text-white px-3 py-2 text-xs font-bold flex items-center justify-between">
                <span>TABLE: obats (Apotek)</span>
                <span className="text-[10px] bg-amber-700 px-1.5 rounded">PK: id</span>
              </div>
              <div className="p-3 text-xs space-y-1 font-mono text-stone-700 divide-y divide-amber-100">
                <div className="text-amber-900 font-bold">id (BIGINT PK)</div>
                <div>kode_obat (VARCHAR UNIQUE)</div>
                <div>nama_obat (VARCHAR)</div>
                <div>kategori (ENUM)</div>
                <div>stok (INT)</div>
                <div>stok_minimum (INT)</div>
                <div>kadaluarsa (DATE)</div>
                <div>aturan_pakai_default (TEXT)</div>
              </div>
            </div>

            {/* Table 4: resep_obats (Pivot) */}
            <div className="rounded-xl border border-stone-300 bg-stone-50 overflow-hidden shadow-xs">
              <div className="bg-stone-800 text-white px-3 py-2 text-xs font-bold flex items-center justify-between">
                <span>TABLE: resep_obats (Pivot)</span>
                <span className="text-[10px] bg-stone-700 px-1.5 rounded">2x FK</span>
              </div>
              <div className="p-3 text-xs space-y-1 font-mono text-stone-700 divide-y divide-stone-200">
                <div className="text-stone-900 font-bold">id (BIGINT PK)</div>
                <div className="text-teal-800 font-semibold">&rarr; rekam_medis_id (FK)</div>
                <div className="text-amber-800 font-semibold">&rarr; obat_id (FK: obats.id)</div>
                <div>jumlah (INT)</div>
                <div>aturan_pakai (VARCHAR)</div>
              </div>
            </div>

            {/* Table 5: surat_izin_sakits */}
            <div className="rounded-xl border border-stone-300 bg-stone-50 overflow-hidden shadow-xs">
              <div className="bg-stone-800 text-white px-3 py-2 text-xs font-bold flex items-center justify-between">
                <span>TABLE: surat_izin_sakits</span>
                <span className="text-[10px] bg-stone-700 px-1.5 rounded">FK: rm_id</span>
              </div>
              <div className="p-3 text-xs space-y-1 font-mono text-stone-700 divide-y divide-stone-200">
                <div className="text-stone-900 font-bold">id (BIGINT PK)</div>
                <div>nomor_surat (VARCHAR UNIQUE)</div>
                <div className="text-teal-800 font-semibold">&rarr; rekam_medis_id (FK)</div>
                <div className="text-emerald-800 font-semibold">&rarr; santri_id (FK)</div>
                <div>lama_hari (INT)</div>
                <div>rekomendasi (ENUM)</div>
                <div>dokter_pemeriksa (VARCHAR)</div>
              </div>
            </div>

            {/* Table 6: surat_rujukans */}
            <div className="rounded-xl border border-rose-300 bg-rose-50/40 overflow-hidden shadow-xs">
              <div className="bg-rose-900 text-white px-3 py-2 text-xs font-bold flex items-center justify-between">
                <span>TABLE: surat_rujukans (RSUD)</span>
                <span className="text-[10px] bg-rose-800 px-1.5 rounded">FK: rm_id</span>
              </div>
              <div className="p-3 text-xs space-y-1 font-mono text-stone-700 divide-y divide-rose-100">
                <div className="text-rose-900 font-bold">id (BIGINT PK)</div>
                <div>nomor_surat (VARCHAR UNIQUE)</div>
                <div className="text-teal-800 font-semibold">&rarr; rekam_medis_id (FK)</div>
                <div className="text-emerald-800 font-semibold">&rarr; santri_id (FK)</div>
                <div>tujuan_faskes (VARCHAR)</div>
                <div>diagnosa_sementara (VARCHAR)</div>
                <div>alasan_rujukan (TEXT)</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 3: Live SQL Dump Export */}
      {activeSubTab === 'export' && (
        <div className="bg-white rounded-2xl p-6 border border-stone-200 shadow-xs space-y-4 text-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-100">
            <div>
              <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-500" />
                <span>Ekspor Data Live ke MySQL / Laravel Database</span>
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Mengonversi data santri, apotek, dan rekam medis yang aktif di aplikasi menjadi pernyataan SQL INSERT
              </p>
            </div>

            <button
              onClick={() => handleDownload('dek_santri_live_data.sql', generateCurrentLiveSQL())}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl flex items-center gap-2 shadow-sm cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Unduh .SQL Dump ({santriList.length} Santri, {rekamMedisList.length} RM)</span>
            </button>
          </div>

          <div className="bg-stone-950 p-4 rounded-xl font-mono text-stone-200 max-h-96 overflow-auto text-[11px] leading-relaxed no-scrollbar select-all">
            <pre>
              <code>{generateCurrentLiveSQL()}</code>
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
