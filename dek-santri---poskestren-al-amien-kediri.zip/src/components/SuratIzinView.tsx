import React, { useState } from 'react';
import { 
  Award, 
  Printer, 
  FileText, 
  Search,
  Download,
  ShieldCheck,
  AlertTriangle,
  UserCheck,
  Plus,
  X,
  CheckCircle2,
  Calendar,
  Building2,
  HelpCircle,
  FileCheck
} from 'lucide-react';
import { SuratIzinSakit, SuratRujukan, SuratInformedConsent, Santri, PetugasPoskestren } from '../types';
import { printHtmlContent, downloadDocumentFile, calculateAge, isUnderage } from '../utils/printHelper';

interface SuratIzinViewProps {
  suratIzinList: SuratIzinSakit[];
  suratRujukanList: SuratRujukan[];
  informedConsentList?: SuratInformedConsent[];
  santriList?: Santri[];
  petugasList?: PetugasPoskestren[];
  onSaveInformedConsent?: (consent: SuratInformedConsent) => void;
  onDeleteInformedConsent?: (id: string) => void;
}

export const SuratIzinView: React.FC<SuratIzinViewProps> = ({
  suratIzinList,
  suratRujukanList,
  informedConsentList = [],
  santriList = [],
  petugasList = [],
  onSaveInformedConsent,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'izin' | 'rujukan' | 'consent'>('consent');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Selected for viewing / printing modal
  const [selectedSuratIzin, setSelectedSuratIzin] = useState<SuratIzinSakit | null>(null);
  const [selectedRujukan, setSelectedRujukan] = useState<SuratRujukan | null>(null);
  const [selectedConsent, setSelectedConsent] = useState<SuratInformedConsent | null>(null);

  // New Informed Consent Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formSantriId, setFormSantriId] = useState<string>(santriList[0]?.id || '');
  const [formDiagnosa, setFormDiagnosa] = useState('');
  const [formTindakan, setFormTindakan] = useState('');
  const [formIndikasi, setFormIndikasi] = useState('');
  const [formResiko, setFormResiko] = useState('');
  const [formStatus, setFormStatus] = useState<'Setuju' | 'Menolak'>('Setuju');
  const [formNamaKetua, setFormNamaKetua] = useState('');
  const [formPeranKetua, setFormPeranKetua] = useState('Ketua Kelompok Santri / Ketua Kamar Asrama');
  const [formNoHpKetua, setFormNoHpKetua] = useState('');
  const [formNamaKader, setFormNamaKader] = useState(
    petugasList.find(p => p.peran === 'Kader Santri Husada')?.nama || 'Ustadz Wildan (Kader Santri Husada)'
  );
  const [formDokter, setFormDokter] = useState(
    petugasList.find(p => p.peran === 'Dokter Penanggung Jawab')?.nama || 'dr. H. Riza Fahmi, Sp.PD'
  );
  const [formCatatan, setFormCatatan] = useState('');

  const currentSelectedSantri = santriList.find(s => s.id === formSantriId);
  const currentSantriAge = currentSelectedSantri ? calculateAge(currentSelectedSantri.tanggal_lahir) : 0;
  const currentSantriIsMinor = currentSelectedSantri ? isUnderage(currentSelectedSantri.tanggal_lahir) : true;

  // Auto-fill form values when santri changes
  const handleSelectSantriForConsent = (santriId: string) => {
    setFormSantriId(santriId);
    const s = santriList.find(item => item.id === santriId);
    if (s) {
      setFormNamaKetua(`Ketua Kamar ${s.kamar}`);
      setFormCatatan(`Santri ${s.nama_lengkap} (Usia ${calculateAge(s.tanggal_lahir)} Thn). Wali santri di ${s.alamat_asal} telah dihubungi via telepon.`);
    }
  };

  // Filtered lists
  const filteredIzin = suratIzinList.filter(s =>
    s.nomor_surat.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.santri_nama.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.santri_nis.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.asrama_kamar.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredRujukan = suratRujukanList.filter(r =>
    r.nomor_surat.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.santri_nama.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.santri_nis.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.tujuan_faskes.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredConsent = informedConsentList.filter(c =>
    c.nomor_surat.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.santri_nama.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.santri_nis.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.nama_ketua_kelompok.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.nama_kader_bertugas.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.asrama_kamar.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Quick chips for actions
  const quickActions = [
    'Observasi Rawat Inap Poskestren & Pemberian Infus Cairan RL',
    'Terapi Inhalasi Nebulisasi Asma & Evaluasi Saturasi Oksigen',
    'Perawatan Luka Terbuka, Debridement, & Penjahitan (Hecting)',
    'Insisi & Drainase Abses / Furunkulosis Ringan',
    'Pemberian Injeksi Antipiretik & Analgesik Intramuskular',
    'Pemberian Terapi Antibiotik Oral Dosis Terjadwal',
    'Stabilisasi Awal & Rujukan Darurat ke IGD Rumah Sakit'
  ];

  // HTML Generators
  const generateSuratIzinHtml = (s: SuratIzinSakit) => `
    <div class="header-kop">
      <div class="kop-yayasan">YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI</div>
      <div class="kop-poskestren">POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN</div>
      <div class="kop-alamat">Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129<br>Telp/WhatsApp: (0354) 682110 • Email: poskestren@alamienkediri.ponpes.id</div>
    </div>
    <div class="doc-header">
      <div class="doc-title">SURAT KETERANGAN SAKIT (IZIN ISTIRAHAT)</div>
      <div class="doc-nomor">Nomor: ${s.nomor_surat}</div>
    </div>
    <p>Yang bertanda tangan di bawah ini, Tenaga Medis Poskestren Pondok Pesantren Al-Amien Kediri, menerangkan bahwa santri:</p>
    <div class="content-box">
      <div class="grid-row"><span class="grid-label">Nama Lengkap</span><span class="grid-value">: <strong>${s.santri_nama}</strong></span></div>
      <div class="grid-row"><span class="grid-label">Nomor Induk Santri (NIS)</span><span class="grid-value">: ${s.santri_nis}</span></div>
      <div class="grid-row"><span class="grid-label">Jenjang &amp; Kelas</span><span class="grid-value">: ${s.kelas_jenjang}</span></div>
      <div class="grid-row"><span class="grid-label">Asrama &amp; Kamar</span><span class="grid-value">: ${s.asrama_kamar}</span></div>
      <div class="grid-row"><span class="grid-label">Diagnosa Medis</span><span class="grid-value">: <strong>${s.diagnosa}</strong></span></div>
    </div>
    <p>Berdasarkan hasil pemeriksaan klinis di Poskestren Al-Amien Kediri, yang bersangkutan dalam keadaan sakit dan memerlukan istirahat selama <strong>${s.lama_hari} hari</strong>, terhitung mulai tanggal <strong>${s.tanggal_mulai}</strong> sampai dengan tanggal <strong>${s.tanggal_selesai}</strong>.</p>
    <p>Rekomendasi Penanganan: <strong>${s.rekomendasi}</strong>. Santri dibebaskan sementara dari kegiatan belajar mengajar di kelas, halaqah mengaji, dan kerja bakti pondok.</p>
    <p>Demikian surat keterangan ini dibuat dengan sebenarnya untuk dapat dipergunakan sebagaimana mestinya oleh Bagian Pengasuhan Santri dan Asatidz Madrasah.</p>
    <div class="signature-wrap">
      <div style="font-size: 8.5pt; color: #57534e;">
        *Tembusan:<br>
        1. Bagian Keamanan &amp; Pengasuhan Pondok<br>
        2. Wali Kelas / Madrasah Al-Amien<br>
        3. Arsip Poskestren
      </div>
      <div class="signature-box">
        <div>Kediri, ${s.tanggal_dibuat}<br><span class="font-bold">Dokter / Tenaga Medis Poskestren</span></div>
        <div class="signature-space"></div>
        <div class="font-bold underline">${s.dokter_pemeriksa}</div>
        <div style="font-size: 8.5pt; color: #57534e;">${s.sip_nip}</div>
      </div>
    </div>
  `;

  const generateSuratRujukanHtml = (r: SuratRujukan) => `
    <div class="header-kop">
      <div class="kop-yayasan">YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI</div>
      <div class="kop-poskestren">POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN</div>
      <div class="kop-alamat">Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129<br>Telp/WhatsApp: (0354) 682110 • Unit Layanan Kesehatan Primer Terpadu</div>
    </div>
    <div class="doc-header">
      <div class="doc-title" style="color: #9f1239;">SURAT PENGANTAR RUJUKAN PASIEN</div>
      <div class="doc-nomor">Nomor: ${r.nomor_surat}</div>
    </div>
    <div style="margin-bottom: 12px;">
      <div>Kepada Yth.</div>
      <div class="font-bold" style="font-size: 11pt;">Dokter Jaga / Poliklinik ${r.tujuan_faskes}</div>
      <div>di Tempat</div>
    </div>
    <p>Dengan hormat, bersama ini kami menghadapkan pasien santri Pondok Pesantren Al-Amien Kediri:</p>
    <div class="content-box">
      <div class="grid-row"><span class="grid-label">Nama Santri</span><span class="grid-value">: <strong>${r.santri_nama}</strong></span></div>
      <div class="grid-row"><span class="grid-label">Nomor Induk (NIS)</span><span class="grid-value">: ${r.santri_nis}</span></div>
      <div class="grid-row"><span class="grid-label">Tanggal Lahir</span><span class="grid-value">: ${r.tanggal_lahir}</span></div>
      <div class="grid-row"><span class="grid-label">Tanda-Tanda Vital</span><span class="grid-value">: <strong>${r.tanda_vital}</strong></span></div>
      <div class="grid-row"><span class="grid-label">Diagnosa Sementara</span><span class="grid-value">: <strong>${r.diagnosa_sementara}</strong></span></div>
      <div class="grid-row"><span class="grid-label">Alasan Rujukan</span><span class="grid-value">: ${r.alasan_rujukan}</span></div>
      <div class="grid-row"><span class="grid-label">Terapi Awal Diberikan</span><span class="grid-value">: ${r.terapi_awal_diberikan}</span></div>
    </div>
    <p>Mohon penanganan klinis, pemeriksaan penunjang (laboratorium/radiologi), serta tatalaksana lebih lanjut. Pasien didampingi oleh Kader Santri Husada / Pengasuhan Pondok Pesantren Al Amien.</p>
    <p>Atas perhatian dan kerja sama sejawat, kami ucapkan terima kasih.</p>
    <div class="signature-wrap" style="justify-content: flex-end;">
      <div class="signature-box">
        <div>Kediri, ${r.tanggal_surat}<br><span class="font-bold">Dokter Perujuk Poskestren Al-Amien</span></div>
        <div class="signature-space"></div>
        <div class="font-bold underline">${r.dokter_perujuk}</div>
        <div style="font-size: 8.5pt; color: #57534e;">Poskestren Ponpes Al-Amien Kediri</div>
      </div>
    </div>
  `;

  const generateConsentHtml = (c: SuratInformedConsent) => `
    <div class="header-kop">
      <div class="kop-yayasan">YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI</div>
      <div class="kop-poskestren">POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN</div>
      <div class="kop-alamat">Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129<br>Telp/WhatsApp: (0354) 682110 • Unit Layanan Kesehatan Primer &amp; Pengasuhan Terpadu</div>
    </div>

    <div class="doc-header">
      <div class="doc-title" style="color: #065f46;">SURAT PERSETUJUAN TINDAKAN MEDIS (INFORMED CONSENT)</div>
      <div style="font-size: 10pt; font-weight: 600; color: #b45309; margin-top: 2px;">
        KHUSUS SANTRI DI BAWAH UMUR (&lt; 18 TAHUN) DENGAN PENDAMPINGAN ASRAMA
      </div>
      <div class="doc-nomor">Nomor Dokumen: ${c.nomor_surat}</div>
    </div>

    <p style="font-size: 9pt; text-align: justify; line-height: 1.45; background-color: #f5f5f4; padding: 7px 10px; border-radius: 4px; border-left: 3px solid #059669;">
      <strong>Dasar Hukum &amp; Ketentuan Pesantren:</strong> Berdasarkan Standar Pelayanan Medis Poskestren dan Peraturan Pengasuhan Santri Ponpes Al-Amien Kediri, bagi santri yang belum dewasa (&lt; 18 tahun) serta berada jauh dari domisili orang tua/wali kandung, pemberian persetujuan tindakan medis/observasi diwakilkan kepada <strong>Ketua Kelompok Santri / Ketua Kamar Asrama</strong> dengan pendampingan dan verifikasi oleh <strong>Kader Santri Husada / Petugas Medis Poskestren</strong> yang bertugas.
    </p>

    <div style="font-weight: bold; font-size: 9.5pt; color: #064e3b; margin-top: 10px; border-bottom: 1px solid #d6d3d1; padding-bottom: 2px;">
      I. IDENTITAS SANTRI (PASIEN DI BAWAH UMUR)
    </div>
    <div class="content-box" style="margin-top: 6px;">
      <div class="grid-row"><span class="grid-label">Nama Santri Pasien</span><span class="grid-value">: <strong>${c.santri_nama}</strong> (${c.santri_jk === 'L' ? 'Santri Putra / Banin' : 'Santri Putri / Banat'})</span></div>
      <div class="grid-row"><span class="grid-label">Nomor Induk Santri (NIS)</span><span class="grid-value">: ${c.santri_nis}</span></div>
      <div class="grid-row"><span class="grid-label">Usia &amp; Tanggal Lahir</span><span class="grid-value">: <strong>${c.santri_umur} Tahun</strong> (Lahir: ${c.santri_tanggal_lahir}) — <span style="color: #b45309; font-weight: bold;">${c.santri_umur < 18 ? 'STATUS DI BAWAH UMUR / MINOR' : 'DEWASA'}</span></span></div>
      <div class="grid-row"><span class="grid-label">Kelas &amp; Jenjang</span><span class="grid-value">: ${c.kelas_jenjang}</span></div>
      <div class="grid-row"><span class="grid-label">Asrama &amp; Kamar</span><span class="grid-value">: ${c.asrama_kamar}</span></div>
    </div>

    <div style="font-weight: bold; font-size: 9.5pt; color: #064e3b; margin-top: 10px; border-bottom: 1px solid #d6d3d1; padding-bottom: 2px;">
      II. PENJELASAN TINDAKAN KLINIS OLEH TENAGA MEDIS / KADER
    </div>
    <div class="content-box" style="margin-top: 6px;">
      <div class="grid-row"><span class="grid-label">Diagnosa Medis</span><span class="grid-value">: <strong>${c.diagnosa}</strong></span></div>
      <div class="grid-row"><span class="grid-label">Tindakan / Prosedur</span><span class="grid-value">: <strong>${c.tindakan_medis}</strong></span></div>
      <div class="grid-row"><span class="grid-label">Indikasi Medis</span><span class="grid-value">: ${c.indikasi_tindakan || 'Tatalaksana klinis untuk pemulihan kondisi santri'}</span></div>
      <div class="grid-row"><span class="grid-label">Penjelasan Risiko</span><span class="grid-value">: ${c.resiko_penjelasan || 'Telah diterangkan secara komprehensif kepada santri dan perwakilan kelompok'}</span></div>
      ${c.catatan_tambahan ? `<div class="grid-row"><span class="grid-label">Catatan Khusus</span><span class="grid-value">: ${c.catatan_tambahan}</span></div>` : ''}
    </div>

    <div style="font-weight: bold; font-size: 9.5pt; color: #064e3b; margin-top: 10px; border-bottom: 1px solid #d6d3d1; padding-bottom: 2px;">
      III. PERNYATAAN PERSETUJUAN RESMI WALI PENGGANTI DI PESANTREN
    </div>
    <p style="font-size: 9pt; text-align: justify; line-height: 1.45; margin: 8px 0;">
      Yang bertanda tangan di bawah ini, selaku <strong>Ketua Kelompok Santri / Ketua Kamar Asrama</strong> yang mewakili keluarga/wali santri selama di Pondok Pesantren Al-Amien Kediri, menyatakan bahwa saya telah menerima penjelasan lengkap, memahami tujuan, risiko, serta alternatif tindakan medis tersebut, dan menyatakan:
    </p>

    <div style="text-align: center; margin: 10px 0; padding: 8px; border: 2px solid ${c.status_persetujuan === 'Setuju' ? '#059669' : '#e11d48'}; background: ${c.status_persetujuan === 'Setuju' ? '#ecfdf5' : '#fff1f2'}; border-radius: 6px;">
      <span style="font-size: 11pt; font-weight: bold; color: ${c.status_persetujuan === 'Setuju' ? '#065f46' : '#9f1239'};">
        ${c.status_persetujuan === 'Setuju' ? '✓ MEMBERIKAN PERSETUJUAN (SETUJU) ATAS TINDAKAN MEDIS TERSEBUT' : '✗ MENOLAK DILAKUKAN TINDAKAN MEDIS TERSEBUT'}
      </span>
    </div>

    <!-- Tanda Tangan 2 Pihak Utama sesuai Brief User (Ketua Kelompok & Kader yang Bertugas) -->
    <div style="margin-top: 24px;">
      <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; text-align: center; font-size: 9pt;">
        <!-- Pihak 1: Ketua Kelompok -->
        <div style="border: 1px solid #d6d3d1; padding: 10px; border-radius: 6px; background-color: #fafaf9;">
          <div>Pemberi Persetujuan (Wali Pengganti):<br><strong>KETUA KELOMPOK / ASRAMA</strong></div>
          <div style="height: 55px;"></div>
          <div style="font-weight: bold; text-decoration: underline;">${c.nama_ketua_kelompok}</div>
          <div style="font-size: 8pt; color: #57534e;">${c.peran_ketua_kelompok}</div>
        </div>

        <!-- Pihak 2: Kader yang Bertugas -->
        <div style="border: 1px solid #d6d3d1; padding: 10px; border-radius: 6px; background-color: #fafaf9;">
          <div>Penerima Persetujuan / Petugas Jaga:<br><strong>KADER SANTRI HUSADA BERTUGAS</strong></div>
          <div style="height: 55px;"></div>
          <div style="font-weight: bold; text-decoration: underline;">${c.nama_kader_bertugas}</div>
          <div style="font-size: 8pt; color: #57534e;">Unit Poskestren Al-Amien Kediri</div>
        </div>
      </div>

      <!-- Mengetahui Dokter & Santri -->
      <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; text-align: center; font-size: 9pt; margin-top: 12px;">
        <div style="padding: 6px;">
          <div>Santri Pasien Bersangkutan:</div>
          <div style="height: 45px;"></div>
          <div style="font-weight: bold; text-decoration: underline;">${c.santri_nama}</div>
          <div style="font-size: 8pt; color: #57534e;">NIS: ${c.santri_nis}</div>
        </div>

        <div style="padding: 6px;">
          <div>Kediri, ${c.tanggal_dibuat}<br>Mengetahui: <strong>Dokter Penanggung Jawab</strong></div>
          <div style="height: 45px;"></div>
          <div style="font-weight: bold; text-decoration: underline;">${c.dokter_penanggung_jawab}</div>
          <div style="font-size: 8pt; color: #57534e;">${c.sip_dokter || 'SIP. Poskestren Al-Amien'}</div>
        </div>
      </div>
    </div>
  `;

  const handlePrintIzin = (s: SuratIzinSakit) => {
    printHtmlContent({
      title: `Surat Izin Sakit - ${s.santri_nama} (${s.santri_nis})`,
      bodyHtml: generateSuratIzinHtml(s),
    });
  };

  const handleDownloadIzin = (s: SuratIzinSakit) => {
    const safeNum = s.nomor_surat.replace(/[^a-zA-Z0-9]/g, '_');
    downloadDocumentFile(
      `Surat_Izin_${s.santri_nis}_${safeNum}`,
      `Surat Keterangan Sakit - ${s.santri_nama}`,
      generateSuratIzinHtml(s)
    );
  };

  const handlePrintRujukan = (r: SuratRujukan) => {
    printHtmlContent({
      title: `Surat Rujukan - ${r.santri_nama} (${r.tujuan_faskes})`,
      bodyHtml: generateSuratRujukanHtml(r),
    });
  };

  const handleDownloadRujukan = (r: SuratRujukan) => {
    const safeNum = r.nomor_surat.replace(/[^a-zA-Z0-9]/g, '_');
    downloadDocumentFile(
      `Surat_Rujukan_${r.santri_nis}_${safeNum}`,
      `Surat Pengantar Rujukan - ${r.santri_nama}`,
      generateSuratRujukanHtml(r)
    );
  };

  const handlePrintConsent = (c: SuratInformedConsent) => {
    printHtmlContent({
      title: `Informed Consent Santri - ${c.santri_nama} (${c.nomor_surat})`,
      bodyHtml: generateConsentHtml(c),
    });
  };

  const handleDownloadConsent = (c: SuratInformedConsent) => {
    const safeNum = c.nomor_surat.replace(/[^a-zA-Z0-9]/g, '_');
    downloadDocumentFile(
      `Informed_Consent_${c.santri_nis}_${safeNum}`,
      `Informed Consent - ${c.santri_nama}`,
      generateConsentHtml(c)
    );
  };

  // Submit new consent modal
  const handleSaveConsentModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentSelectedSantri) {
      alert('Silakan pilih santri terlebih dahulu.');
      return;
    }
    if (!formDiagnosa || !formTindakan || !formNamaKetua || !formNamaKader) {
      alert('Mohon lengkapi diagnosa, tindakan medis, nama ketua kelompok, dan kader yang bertugas.');
      return;
    }

    const todayStr = new Date().toISOString().slice(0, 10);
    const romanMonths = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
    const currentRomanMonth = romanMonths[new Date().getMonth()];
    const nomor = `${String(Math.floor(10 + Math.random() * 90))}/POSKESTREN-AA/IC/${currentRomanMonth}/${new Date().getFullYear()}`;

    const newConsent: SuratInformedConsent = {
      id: `ic-${Date.now()}`,
      nomor_surat: nomor,
      santri_id: currentSelectedSantri.id,
      santri_nama: currentSelectedSantri.nama_lengkap,
      santri_nis: currentSelectedSantri.nis,
      santri_umur: currentSantriAge,
      santri_tanggal_lahir: currentSelectedSantri.tanggal_lahir,
      santri_jk: currentSelectedSantri.jenis_kelamin,
      asrama_kamar: `${currentSelectedSantri.asrama_komplek} / ${currentSelectedSantri.kamar}`,
      kelas_jenjang: `${currentSelectedSantri.jenjang_pendidikan} - ${currentSelectedSantri.kelas}`,
      diagnosa: formDiagnosa,
      tindakan_medis: formTindakan,
      indikasi_tindakan: formIndikasi || 'Tatalaksana klinis untuk percepatan penyembuhan santri',
      resiko_penjelasan: formResiko || 'Telah disampaikan penjelasan kemungkinan reaksi obat / efek sementara tindakan medis',
      status_persetujuan: formStatus,
      nama_ketua_kelompok: formNamaKetua,
      peran_ketua_kelompok: formPeranKetua,
      no_hp_ketua_kelompok: formNoHpKetua,
      nama_kader_bertugas: formNamaKader,
      dokter_penanggung_jawab: formDokter,
      sip_dokter: 'SIP. 503/441/SIP-D/411.302/2022',
      tanggal_dibuat: todayStr,
      catatan_tambahan: formCatatan,
    };

    if (onSaveInformedConsent) {
      onSaveInformedConsent(newConsent);
    }

    setIsCreateModalOpen(false);
    // Reset form
    setFormDiagnosa('');
    setFormTindakan('');
    setFormIndikasi('');
    setFormResiko('');
    setSelectedConsent(newConsent); // Directly preview the created document
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-700" />
            <h2 className="text-lg sm:text-xl font-bold text-stone-900">
              Dokumen &amp; Surat Resmi Poskestren Al-Amien Kediri
            </h2>
          </div>
          <p className="text-xs text-stone-500 mt-0.5">
            Surat Keterangan Sakit, Rujukan RS, dan Lembar Persetujuan Tindakan Medis (Informed Consent Santri Di Bawah Umur)
          </p>
        </div>

        {/* Sub-tab switcher */}
        <div className="flex flex-wrap items-center bg-stone-100 p-1 rounded-xl gap-1">
          <button
            onClick={() => setActiveSubTab('consent')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'consent'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Informed Consent Santri ({informedConsentList.length})</span>
          </button>
          <button
            onClick={() => setActiveSubTab('izin')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeSubTab === 'izin'
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Surat Izin Sakit ({suratIzinList.length})
          </button>
          <button
            onClick={() => setActiveSubTab('rujukan')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              activeSubTab === 'rujukan'
                ? 'bg-white text-rose-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Surat Rujukan RS ({suratRujukanList.length})
          </button>
        </div>
      </div>

      {/* Action / Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="w-full sm:w-80 relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari nomor surat, santri, ketua kelompok, kader..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 bg-stone-50/50"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {activeSubTab === 'consent' && (
            <button
              onClick={() => {
                if (santriList.length > 0) {
                  handleSelectSantriForConsent(santriList[0].id);
                }
                setIsCreateModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 active:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Buat Surat Informed Consent Baru</span>
            </button>
          )}
          <span className="text-xs text-stone-500 hidden md:inline">
            Standar Dokumen Resmi Pondok Pesantren Al-Amien Kediri
          </span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SUB-TAB: INFORMED CONSENT SANTRI DI BAWAH UMUR (FEATURE UTAMA)           */}
      {/* ========================================================================= */}
      {activeSubTab === 'consent' && (
        <div className="space-y-4">
          {/* Informative Pesantren Banner */}
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-900">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="font-bold text-amber-950 text-sm">
                Ketentuan Informed Consent Santri Di Bawah Umur (&lt; 18 Tahun)
              </div>
              <p className="text-amber-800 leading-relaxed">
                Di lingkungan Pondok Pesantren Al-Amien Kediri, santri yang berusia <strong>di bawah 18 tahun (belum dewasa secara hukum)</strong> dan memerlukan tindakan medis (rawat inap observasi, injeksi, infus, nebulisasi, hecting luka, atau rujukan) wajib dilengkapi <strong>Lembar Informed Consent</strong> yang ditandatangani oleh <strong>Ketua Kelompok / Ketua Kamar Asrama</strong> (sebagai wali pengganti di pesantren) dan <strong>Kader Santri Husada</strong> yang bertugas.
              </p>
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredConsent.map((consent) => (
              <div 
                key={consent.id} 
                className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs space-y-3 hover:border-emerald-300 transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-emerald-900 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      No: {consent.nomor_surat}
                    </span>
                    <h4 className="font-bold text-stone-900 text-sm mt-1">{consent.santri_nama}</h4>
                    <div className="text-[11px] text-stone-500">
                      NIS: {consent.santri_nis} • {consent.kelas_jenjang}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                      consent.santri_umur < 18 
                        ? 'bg-amber-50 text-amber-800 border-amber-300' 
                        : 'bg-stone-50 text-stone-700 border-stone-300'
                    }`}>
                      {consent.santri_umur} Thn {consent.santri_umur < 18 ? '• Di Bawah Umur' : '• Dewasa'}
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-md font-semibold ${
                      consent.status_persetujuan === 'Setuju' 
                        ? 'bg-emerald-100 text-emerald-800' 
                        : 'bg-rose-100 text-rose-800'
                    }`}>
                      {consent.status_persetujuan === 'Setuju' ? '✓ Disetujui' : '✗ Ditolak'}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-stone-50 rounded-xl space-y-1.5 text-xs text-stone-700">
                  <div>
                    <span className="text-stone-500 font-medium">Diagnosa: </span>
                    <strong className="text-stone-900">{consent.diagnosa}</strong>
                  </div>
                  <div>
                    <span className="text-stone-500 font-medium">Tindakan Medis: </span>
                    <span className="font-semibold text-emerald-900">{consent.tindakan_medis}</span>
                  </div>
                  <div className="pt-2 mt-2 border-t border-stone-200 grid grid-cols-2 gap-2 text-[11px]">
                    <div>
                      <span className="text-stone-500 block font-medium">TTD Pihak I (Ketua Kelompok):</span>
                      <strong className="text-stone-900">{consent.nama_ketua_kelompok}</strong>
                      <div className="text-[10px] text-stone-400">{consent.peran_ketua_kelompok}</div>
                    </div>
                    <div>
                      <span className="text-stone-500 block font-medium">TTD Pihak II (Kader Bertugas):</span>
                      <strong className="text-stone-900">{consent.nama_kader_bertugas}</strong>
                      <div className="text-[10px] text-stone-400">Poskestren Al-Amien</div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-100">
                  <span className="text-[11px] text-stone-400">
                    Tgl: {consent.tanggal_dibuat}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setSelectedConsent(consent)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                      title="Lihat Pratinjau Dokumen Informed Consent"
                    >
                      <FileText className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Lihat</span>
                    </button>
                    <button
                      onClick={() => handlePrintConsent(consent)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
                      title="Cetak langsung ke printer atau Simpan PDF"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Cetak / PDF</span>
                    </button>
                    <button
                      onClick={() => handleDownloadConsent(consent)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                      title="Unduh Berkas HTML/PDF"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Unduh</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredConsent.length === 0 && (
            <div className="bg-white rounded-2xl p-12 text-center border border-stone-200">
              <ShieldCheck className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <div className="font-bold text-stone-700">Belum ada surat Informed Consent yang cocok</div>
              <p className="text-xs text-stone-400 mt-1 max-w-md mx-auto">
                Silakan buat surat informed consent baru untuk santri di bawah umur yang membutuhkan tindakan observasi atau terapi medis.
              </p>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB: SURAT IZIN SAKIT                                                */}
      {/* ========================================================================= */}
      {activeSubTab === 'izin' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredIzin.map((surat) => (
            <div key={surat.id} className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs space-y-3 hover:border-emerald-300 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    No: {surat.nomor_surat}
                  </span>
                  <h4 className="font-bold text-stone-900 text-sm mt-1">{surat.santri_nama}</h4>
                  <div className="text-[11px] text-stone-500">NIS: {surat.santri_nis} • {surat.kelas_jenjang}</div>
                </div>

                <span className="text-[11px] px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 font-semibold border border-amber-200">
                  {surat.lama_hari} Hari Istirahat
                </span>
              </div>

              <div className="p-2.5 bg-stone-50 rounded-xl space-y-1 text-xs text-stone-700">
                <div>
                  <span className="text-stone-500 font-medium">Diagnosa: </span>
                  <strong className="text-stone-900">{surat.diagnosa}</strong>
                </div>
                <div>
                  <span className="text-stone-500 font-medium">Rekomendasi: </span>
                  <span className="font-semibold text-emerald-900">{surat.rekomendasi}</span>
                </div>
                <div>
                  <span className="text-stone-500 font-medium">Masa Istirahat: </span>
                  <span>{surat.tanggal_mulai} s/d {surat.tanggal_selesai}</span>
                </div>
                <div className="text-[11px] text-stone-500 pt-1 border-t border-stone-200">
                  Pemeriksa: {surat.dokter_pemeriksa} ({surat.sip_nip})
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-stone-100">
                <button
                  onClick={() => setSelectedSuratIzin(surat)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  title="Lihat Pratinjau Surat Izin Sakit"
                >
                  <FileText className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Lihat Surat</span>
                </button>
                <button
                  onClick={() => handlePrintIzin(surat)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer"
                  title="Cetak Langsung atau Simpan Sebagai PDF"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak / PDF</span>
                </button>
                <button
                  onClick={() => handleDownloadIzin(surat)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  title="Unduh File Surat Izin"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Unduh</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB: SURAT RUJUKAN RS                                                */}
      {/* ========================================================================= */}
      {activeSubTab === 'rujukan' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredRujukan.map((rujuk) => (
            <div key={rujuk.id} className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs space-y-3 hover:border-rose-300 transition-colors">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono font-bold text-rose-800 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                    No: {rujuk.nomor_surat}
                  </span>
                  <h4 className="font-bold text-stone-900 text-sm mt-1">{rujuk.santri_nama}</h4>
                  <div className="text-[11px] text-stone-500">NIS: {rujuk.santri_nis} • Tgl Lahir: {rujuk.tanggal_lahir}</div>
                </div>

                <span className="text-[11px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-bold">
                  Rujukan Faskes
                </span>
              </div>

              <div className="p-2.5 bg-rose-50/40 rounded-xl space-y-1 text-xs text-stone-700">
                <div>
                  <span className="text-stone-500 font-medium">Tujuan Faskes: </span>
                  <strong className="text-rose-900">{rujuk.tujuan_faskes}</strong>
                </div>
                <div>
                  <span className="text-stone-500 font-medium">Diagnosa Sementara: </span>
                  <span className="font-semibold text-stone-900">{rujuk.diagnosa_sementara}</span>
                </div>
                <div>
                  <span className="text-stone-500 font-medium">Tanda Vital: </span>
                  <span>{rujuk.tanda_vital}</span>
                </div>
                <div>
                  <span className="text-stone-500 font-medium">Alasan Rujukan: </span>
                  <span className="italic">{rujuk.alasan_rujukan}</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-rose-100">
                <button
                  onClick={() => setSelectedRujukan(rujuk)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  title="Lihat Pratinjau Surat Rujukan"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Lihat Surat</span>
                </button>
                <button
                  onClick={() => handlePrintRujukan(rujuk)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-700 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer"
                  title="Cetak Langsung atau Simpan Sebagai PDF"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak / PDF</span>
                </button>
                <button
                  onClick={() => handleDownloadRujukan(rujuk)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  title="Unduh File Surat Rujukan"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Unduh</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: PRATINJAU / DETAIL SURAT INFORMED CONSENT                           */}
      {/* ========================================================================= */}
      {selectedConsent && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto border border-stone-300 shadow-2xl p-6 sm:p-8 space-y-6 text-stone-900 text-xs">
            {/* Kop Surat Resmi */}
            <div className="text-center border-b-2 border-emerald-900 pb-4 relative">
              <div className="font-serif font-bold text-base sm:text-lg text-emerald-950 uppercase tracking-wide">
                YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI
              </div>
              <div className="font-serif font-bold text-lg sm:text-xl text-emerald-900 tracking-wider">
                POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN
              </div>
              <div className="text-[11px] text-stone-600 mt-1">
                Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129
              </div>
              <div className="text-[10px] text-stone-500">
                Telp/WhatsApp: (0354) 682110 • Unit Layanan Kesehatan Primer &amp; Pengasuhan Terpadu
              </div>
            </div>

            {/* Title */}
            <div className="text-center space-y-1">
              <h3 className="font-bold text-sm sm:text-base uppercase tracking-wider text-emerald-900 underline">
                SURAT PERSETUJUAN TINDAKAN MEDIS (INFORMED CONSENT)
              </h3>
              <div className="text-[11px] font-semibold text-amber-800">
                KHUSUS SANTRI DI BAWAH UMUR (&lt; 18 TAHUN) DENGAN PENDAMPINGAN ASRAMA
              </div>
              <div className="font-mono text-xs text-stone-600">
                Nomor: {selectedConsent.nomor_surat}
              </div>
            </div>

            {/* Content */}
            <div className="space-y-3 leading-relaxed text-xs">
              <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-[11px] text-amber-900">
                <strong>Ketentuan Wali Pengganti:</strong> Karena santri berstatus di bawah umur (&lt; 18 tahun) serta berjarak dari domisili orang tua/wali kandung, persetujuan tindakan medis diwakilkan kepada Ketua Kelompok Santri / Pendamping Asrama yang bersangkutan, dan disaksikan oleh Kader Santri Husada bertugas di Poskestren Al-Amien.
              </div>

              {/* Data Santri */}
              <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200 space-y-1.5">
                <div className="font-bold text-stone-800 text-xs border-b border-stone-200 pb-1 mb-2">
                  I. IDENTITAS SANTRI (PASIEN)
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Nama Lengkap</span>
                  <span className="col-span-2 font-bold text-stone-900">: {selectedConsent.santri_nama}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Nomor Induk Santri (NIS)</span>
                  <span className="col-span-2 font-mono">: {selectedConsent.santri_nis}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Usia &amp; Tgl Lahir</span>
                  <span className="col-span-2">: <strong>{selectedConsent.santri_umur} Tahun</strong> (Lahir: {selectedConsent.santri_tanggal_lahir}) — <span className="text-amber-800 font-bold">{selectedConsent.santri_umur < 18 ? 'Di Bawah Umur (< 18 Thn)' : 'Dewasa'}</span></span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Jenjang &amp; Kelas</span>
                  <span className="col-span-2">: {selectedConsent.kelas_jenjang}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Asrama &amp; Kamar</span>
                  <span className="col-span-2">: {selectedConsent.asrama_kamar}</span>
                </div>
              </div>

              {/* Penjelasan Tindakan */}
              <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200 space-y-1.5">
                <div className="font-bold text-stone-800 text-xs border-b border-stone-200 pb-1 mb-2">
                  II. PENJELASAN TINDAKAN KLINIS
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Diagnosa Medis</span>
                  <span className="col-span-2 font-bold text-emerald-950">: {selectedConsent.diagnosa}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Tindakan Direncanakan</span>
                  <span className="col-span-2 font-bold text-stone-900">: {selectedConsent.tindakan_medis}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Indikasi Medis</span>
                  <span className="col-span-2">: {selectedConsent.indikasi_tindakan || 'Tatalaksana pemulihan klinis santri'}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Penjelasan Risiko</span>
                  <span className="col-span-2">: {selectedConsent.resiko_penjelasan || 'Telah disampaikan dan dipahami dengan baik'}</span>
                </div>
                {selectedConsent.catatan_tambahan && (
                  <div className="grid grid-cols-3">
                    <span className="text-stone-500">Catatan Khusus</span>
                    <span className="col-span-2 italic">: {selectedConsent.catatan_tambahan}</span>
                  </div>
                )}
              </div>

              {/* Status Persetujuan */}
              <div className={`p-3 rounded-xl border text-center font-bold text-xs ${
                selectedConsent.status_persetujuan === 'Setuju'
                  ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
                  : 'bg-rose-50 text-rose-900 border-rose-300'
              }`}>
                {selectedConsent.status_persetujuan === 'Setuju'
                  ? '✓ DENGAN INI MENYATAKAN MEMBERIKAN PERSETUJUAN PENUH ATAS TINDAKAN MEDIS TERSEBUT'
                  : '✗ MENYATAKAN MENOLAK DILAKUKAN TINDAKAN MEDIS TERSEBUT'}
              </div>
            </div>

            {/* Signatures Area: Sesuai Instruksi User: Ditandatangani Ketua Kelompok & Kader yang Bertugas */}
            <div className="pt-4 border-t border-stone-200 space-y-4">
              <div className="text-center font-bold text-[11px] text-stone-500 uppercase tracking-wider">
                PENANDATANGANAN RESMI LEMBAR INFORMED CONSENT
              </div>
              <div className="grid grid-cols-2 gap-4 text-center text-xs">
                {/* Ketua Kelompok */}
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <div className="text-[11px] text-stone-600">
                    Pemberi Persetujuan (Wali Pengganti):<br />
                    <strong className="text-stone-900">Ketua Kelompok / Asrama</strong>
                  </div>
                  <div className="h-14"></div>
                  <div className="font-bold underline text-stone-900">{selectedConsent.nama_ketua_kelompok}</div>
                  <div className="text-[10px] text-stone-500">{selectedConsent.peran_ketua_kelompok}</div>
                </div>

                {/* Kader Bertugas */}
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <div className="text-[11px] text-stone-600">
                    Penerima Persetujuan / Petugas Jaga:<br />
                    <strong className="text-stone-900">Kader Santri Husada Bertugas</strong>
                  </div>
                  <div className="h-14"></div>
                  <div className="font-bold underline text-stone-900">{selectedConsent.nama_kader_bertugas}</div>
                  <div className="text-[10px] text-stone-500">Unit Poskestren Al-Amien</div>
                </div>
              </div>

              {/* Mengetahui Dokter & Santri */}
              <div className="grid grid-cols-2 gap-4 text-center text-xs pt-1">
                <div>
                  <div className="text-[10px] text-stone-500">Santri Pasien Bersangkutan:</div>
                  <div className="h-10"></div>
                  <div className="font-semibold text-stone-800 underline">{selectedConsent.santri_nama}</div>
                  <div className="text-[10px] text-stone-400">NIS: {selectedConsent.santri_nis}</div>
                </div>

                <div>
                  <div className="text-[10px] text-stone-500">Kediri, {selectedConsent.tanggal_dibuat}</div>
                  <div className="text-[11px] font-semibold text-stone-700">Dokter Penanggung Jawab</div>
                  <div className="h-8"></div>
                  <div className="font-bold underline text-stone-900">{selectedConsent.dokter_penanggung_jawab}</div>
                  <div className="text-[10px] text-stone-400">{selectedConsent.sip_dokter || 'Poskestren Al-Amien'}</div>
                </div>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-stone-200">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handlePrintConsent(selectedConsent)}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                  title="Cetak langsung ke printer atau Simpan sebagai PDF"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak / Simpan PDF (Print)</span>
                </button>
                <button
                  onClick={() => handleDownloadConsent(selectedConsent)}
                  className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                  title="Unduh file dokumen format PDF/HTML"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh Dokumen</span>
                </button>
              </div>
              <button
                onClick={() => setSelectedConsent(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: BUAT SURAT INFORMED CONSENT BARU                                   */}
      {/* ========================================================================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[92vh] overflow-y-auto border border-stone-300 shadow-2xl p-6 space-y-5 text-stone-900 text-xs">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-sm sm:text-base text-stone-900">
                  Buat Lembar Informed Consent Santri
                </h3>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="w-7 h-7 flex items-center justify-center rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveConsentModal} className="space-y-4">
              {/* Santri Selector */}
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Pilih Santri Pasien:
                </label>
                <select
                  value={formSantriId}
                  onChange={(e) => handleSelectSantriForConsent(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-300 bg-white font-medium text-xs focus:ring-2 focus:ring-emerald-500"
                >
                  {santriList.map((s) => {
                    const age = calculateAge(s.tanggal_lahir);
                    const isMinor = age < 18;
                    return (
                      <option key={s.id} value={s.id}>
                        {s.nama_lengkap} ({s.nis}) — {s.asrama_komplek} — {age} Thn {isMinor ? '(Di Bawah Umur)' : ''}
                      </option>
                    );
                  })}
                </select>

                {/* Underage Detection Alert */}
                {currentSelectedSantri && (
                  <div className={`mt-2 p-2.5 rounded-xl text-xs flex items-center justify-between border ${
                    currentSantriIsMinor 
                      ? 'bg-amber-50 border-amber-300 text-amber-900' 
                      : 'bg-emerald-50 border-emerald-300 text-emerald-900'
                  }`}>
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
                      <span>
                        Usia Santri: <strong>{currentSantriAge} Tahun</strong> (Lahir: {currentSelectedSantri.tanggal_lahir}).
                        {currentSantriIsMinor ? ' Status: DI BAWAH UMUR (< 18 Thn) — Wajib TTD Ketua Kelompok & Kader' : ' Status: Dewasa (≥ 18 Thn)'}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Diagnosa */}
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Diagnosa Medis:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Febris Hari Ke-3 / Serangan Asma Akut / Skabies Terinfeksi"
                  value={formDiagnosa}
                  onChange={(e) => setFormDiagnosa(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              {/* Tindakan Medis */}
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Rencana Tindakan / Terapi Medis yang Disetujui:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Observasi Rawat Inap & Pemasangan Infus RL 20 tpm"
                  value={formTindakan}
                  onChange={(e) => setFormTindakan(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-emerald-500"
                  required
                />

                {/* Quick Chips */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {quickActions.map((action, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setFormTindakan(action)}
                      className="text-[10px] px-2 py-1 rounded-lg bg-stone-100 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-300 border border-stone-200 transition-colors text-stone-600 cursor-pointer text-left"
                    >
                      + {action}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Indikasi Klinis Tindakan:
                  </label>
                  <input
                    type="text"
                    placeholder="Contoh: Dehidrasi sedang, demam tinggi"
                    value={formIndikasi}
                    onChange={(e) => setFormIndikasi(e.target.value)}
                    className="w-full p-2 rounded-xl border border-stone-300 text-xs"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">
                    Status Persetujuan:
                  </label>
                  <select
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as 'Setuju' | 'Menolak')}
                    className="w-full p-2 rounded-xl border border-stone-300 text-xs font-semibold"
                  >
                    <option value="Setuju">✓ Setuju Dilakukan Tindakan Medis</option>
                    <option value="Menolak">✗ Menolak Tindakan Medis</option>
                  </select>
                </div>
              </div>

              {/* Data Penandatangan Sesuai Instruksi User */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
                <div className="font-bold text-stone-800 text-xs flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-emerald-700" />
                  <span>Pihak Penandatangan (Ketua Kelompok &amp; Kader Bertugas)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium text-stone-600 mb-1">
                      Nama Ketua Kelompok / Kamar (Pihak I):
                    </label>
                    <input
                      type="text"
                      placeholder="Nama Ketua Kelompok Santri"
                      value={formNamaKetua}
                      onChange={(e) => setFormNamaKetua(e.target.value)}
                      className="w-full p-2 rounded-xl border border-stone-300 text-xs bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-stone-600 mb-1">
                      Peran / Jabatan:
                    </label>
                    <input
                      type="text"
                      value={formPeranKetua}
                      onChange={(e) => setFormPeranKetua(e.target.value)}
                      className="w-full p-2 rounded-xl border border-stone-300 text-xs bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium text-stone-600 mb-1">
                      Kader Santri Husada Bertugas (Pihak II):
                    </label>
                    <input
                      type="text"
                      value={formNamaKader}
                      onChange={(e) => setFormNamaKader(e.target.value)}
                      className="w-full p-2 rounded-xl border border-stone-300 text-xs bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-stone-600 mb-1">
                      Dokter Penanggung Jawab:
                    </label>
                    <input
                      type="text"
                      value={formDokter}
                      onChange={(e) => setFormDokter(e.target.value)}
                      className="w-full p-2 rounded-xl border border-stone-300 text-xs bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Catatan Khusus */}
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Catatan Tambahan / Komunikasi dengan Wali di Rumah:
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Wali santri di Blitar telah dihubungi via telepon dan menyetujui diwakilkan."
                  value={formCatatan}
                  onChange={(e) => setFormCatatan(e.target.value)}
                  className="w-full p-2 rounded-xl border border-stone-300 text-xs"
                />
              </div>

              {/* Footer Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 active:bg-emerald-800 text-white font-bold rounded-xl text-xs shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Simpan &amp; Terbitkan Informed Consent</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: PRATINJAU SURAT KETERANGAN SAKIT                                   */}
      {/* ========================================================================= */}
      {selectedSuratIzin && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto border border-stone-300 shadow-2xl p-6 sm:p-8 space-y-6 text-stone-900 text-xs">
            {/* Kop Surat Resmi */}
            <div className="text-center border-b-2 border-emerald-900 pb-4 relative">
              <div className="font-serif font-bold text-base sm:text-lg text-emerald-950 uppercase tracking-wide">
                YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI
              </div>
              <div className="font-serif font-bold text-lg sm:text-xl text-emerald-900 tracking-wider">
                POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN
              </div>
              <div className="text-[11px] text-stone-600 mt-1">
                Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129
              </div>
              <div className="text-[10px] text-stone-500">
                Telp/WhatsApp: (0354) 682110 • Email: poskestren@alamienkediri.ponpes.id
              </div>
            </div>

            {/* Title */}
            <div className="text-center space-y-1">
              <h3 className="font-bold text-sm sm:text-base uppercase tracking-wider underline">
                SURAT KETERANGAN SAKIT (IZIN ISTIRAHAT)
              </h3>
              <div className="font-mono text-xs text-stone-600">
                Nomor: {selectedSuratIzin.nomor_surat}
              </div>
            </div>

            {/* Content */}
            <div className="space-y-3 leading-relaxed text-xs">
              <p>
                Yang bertanda tangan di bawah ini, Tenaga Medis Poskestren Pondok Pesantren Al-Amien Kediri, menerangkan bahwa santri:
              </p>

              <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200 space-y-1.5 ml-2">
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Nama Lengkap</span>
                  <span className="col-span-2 font-bold text-stone-900">: {selectedSuratIzin.santri_nama}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Nomor Induk Santri (NIS)</span>
                  <span className="col-span-2 font-mono">: {selectedSuratIzin.santri_nis}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Jenjang &amp; Kelas</span>
                  <span className="col-span-2">: {selectedSuratIzin.kelas_jenjang}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Asrama &amp; Kamar</span>
                  <span className="col-span-2">: {selectedSuratIzin.asrama_kamar}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Diagnosa Medis</span>
                  <span className="col-span-2 font-semibold text-emerald-950">: {selectedSuratIzin.diagnosa}</span>
                </div>
              </div>

              <p>
                Berdasarkan hasil pemeriksaan klinis di Poskestren Al-Amien Kediri, yang bersangkutan dalam keadaan sakit dan memerlukan istirahat selama{' '}
                <strong>{selectedSuratIzin.lama_hari} hari</strong>, terhitung mulai tanggal{' '}
                <strong>{selectedSuratIzin.tanggal_mulai}</strong> sampai dengan tanggal{' '}
                <strong>{selectedSuratIzin.tanggal_selesai}</strong>.
              </p>

              <p>
                Rekomendasi Penanganan: <strong>{selectedSuratIzin.rekomendasi}</strong>. Santri dibebaskan sementara dari kegiatan belajar mengajar di kelas, halaqah mengaji, dan kerja bakti pondok.
              </p>

              <p>
                Demikian surat keterangan ini dibuat dengan sebenarnya untuk dapat dipergunakan sebagaimana mestinya oleh Bagian Pengasuhan Santri dan Asatidz Madrasah.
              </p>
            </div>

            {/* Signature Area */}
            <div className="pt-6 flex justify-between items-end text-xs">
              <div className="text-[10px] text-stone-400 max-w-xs">
                *Tembusan:<br />
                1. Bagian Keamanan &amp; Pengasuhan Pondok<br />
                2. Wali Kelas / Madrasah Al-Amien<br />
                3. Arsip Poskestren
              </div>

              <div className="text-center space-y-12">
                <div>
                  Kediri, {selectedSuratIzin.tanggal_dibuat}<br />
                  <span className="font-semibold">Dokter / Tenaga Medis Poskestren</span>
                </div>

                <div>
                  <div className="font-bold underline text-stone-900">{selectedSuratIzin.dokter_pemeriksa}</div>
                  <div className="text-[10px] text-stone-500 font-mono">{selectedSuratIzin.sip_nip}</div>
                </div>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-stone-200">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handlePrintIzin(selectedSuratIzin)}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                  title="Cetak langsung ke printer atau Simpan sebagai PDF"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak / Simpan PDF (Print)</span>
                </button>
                <button
                  onClick={() => handleDownloadIzin(selectedSuratIzin)}
                  className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                  title="Unduh file surat izin format PDF/HTML"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh Dokumen</span>
                </button>
              </div>
              <button
                onClick={() => setSelectedSuratIzin(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: PRATINJAU SURAT RUJUKAN RS                                         */}
      {/* ========================================================================= */}
      {selectedRujukan && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto border border-stone-300 shadow-2xl p-6 sm:p-8 space-y-6 text-stone-900 text-xs">
            {/* Kop Surat Resmi */}
            <div className="text-center border-b-2 border-emerald-900 pb-4 relative">
              <div className="font-serif font-bold text-base sm:text-lg text-emerald-950 uppercase tracking-wide">
                YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI
              </div>
              <div className="font-serif font-bold text-lg sm:text-xl text-emerald-900 tracking-wider">
                POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN
              </div>
              <div className="text-[11px] text-stone-600 mt-1">
                Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129
              </div>
              <div className="text-[10px] text-stone-500">
                Telp/WhatsApp: (0354) 682110 • Unit Layanan Kesehatan Primer Terpadu
              </div>
            </div>

            {/* Title */}
            <div className="text-center space-y-1">
              <h3 className="font-bold text-sm sm:text-base uppercase tracking-wider text-rose-900 underline">
                SURAT PENGANTAR RUJUKAN PASIEN
              </h3>
              <div className="font-mono text-xs text-stone-600">
                Nomor: {selectedRujukan.nomor_surat}
              </div>
            </div>

            {/* Content */}
            <div className="space-y-3 leading-relaxed text-xs">
              <div className="space-y-0.5">
                <div>Kepada Yth.</div>
                <div className="font-bold text-sm text-stone-900">
                  Dokter Jaga / Poliklinik {selectedRujukan.tujuan_faskes}
                </div>
                <div>di Tempat</div>
              </div>

              <p>
                Dengan hormat, bersama ini kami menghadapkan pasien santri Pondok Pesantren Al-Amien Kediri:
              </p>

              <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200 space-y-1.5 ml-2">
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Nama Lengkap</span>
                  <span className="col-span-2 font-bold text-stone-900">: {selectedRujukan.santri_nama}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Nomor Induk (NIS)</span>
                  <span className="col-span-2 font-mono">: {selectedRujukan.santri_nis}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Tanggal Lahir</span>
                  <span className="col-span-2">: {selectedRujukan.tanggal_lahir}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Tanda-Tanda Vital</span>
                  <span className="col-span-2 font-semibold text-rose-950">: {selectedRujukan.tanda_vital}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Diagnosa Sementara</span>
                  <span className="col-span-2 font-bold text-rose-900">: {selectedRujukan.diagnosa_sementara}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Alasan Rujukan</span>
                  <span className="col-span-2">: {selectedRujukan.alasan_rujukan}</span>
                </div>
                <div className="grid grid-cols-3">
                  <span className="text-stone-500">Terapi Awal</span>
                  <span className="col-span-2">: {selectedRujukan.terapi_awal_diberikan}</span>
                </div>
              </div>

              <p>
                Mohon penanganan klinis, pemeriksaan penunjang (laboratorium/radiologi), serta tatalaksana lebih lanjut. Pasien didampingi oleh Kader Santri Husada / Pengasuhan Pondok Pesantren Al-Amien.
              </p>
              <p>
                Atas perhatian dan kerja sama sejawat, kami ucapkan terima kasih.
              </p>
            </div>

            {/* Signature Area */}
            <div className="pt-8 flex justify-end text-xs">
              <div className="text-center space-y-12">
                <div>
                  Kediri, {selectedRujukan.tanggal_surat}<br />
                  <span className="font-semibold">Dokter Perujuk Poskestren Al-Amien</span>
                </div>

                <div>
                  <div className="font-bold underline text-stone-900">{selectedRujukan.dokter_perujuk}</div>
                  <div className="text-[10px] text-stone-500">Poskestren Ponpes Al-Amien Kediri</div>
                </div>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-stone-200">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handlePrintRujukan(selectedRujukan)}
                  className="px-4 py-2 bg-rose-700 hover:bg-rose-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                  title="Cetak langsung ke printer atau Simpan sebagai PDF"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak / Simpan PDF (Print)</span>
                </button>
                <button
                  onClick={() => handleDownloadRujukan(selectedRujukan)}
                  className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-300 font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                  title="Unduh file surat rujukan format PDF/HTML"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh Dokumen</span>
                </button>
              </div>
              <button
                onClick={() => setSelectedRujukan(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
