import React, { useState } from 'react';
import { 
  Pill, 
  Search, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  Calendar, 
  RefreshCw, 
  PackagePlus,
  ShieldAlert
} from 'lucide-react';
import { Obat } from '../types';

interface ApotekViewProps {
  obatList: Obat[];
  onSaveObat: (obat: Obat) => void;
  onRestock: (obatId: string, additionalQty: number) => void;
}

export const ApotekView: React.FC<ApotekViewProps> = ({
  obatList,
  onSaveObat,
  onRestock,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  
  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [restockModalItem, setRestockModalItem] = useState<Obat | null>(null);
  const [restockQty, setRestockQty] = useState<number>(20);

  // New medication form
  const [newObat, setNewObat] = useState<Partial<Obat>>({
    kode_obat: `OBT-${Math.floor(100 + Math.random() * 900)}`,
    nama_obat: '',
    kategori: 'Analgesik & Antipiretik',
    bentuk_sediaan: 'Tablet',
    satuan: 'strip',
    stok: 30,
    stok_minimum: 15,
    kadaluarsa: '2028-01-01',
    aturan_pakai_default: '3 x 1 tablet sesudah makan',
    keterangan: ''
  });

  const categories = [
    'All',
    'Obat Kulit / Skabies',
    'Analgesik & Antipiretik',
    'Saluran Pencernaan / Maag',
    'Saluran Pernapasan / Batuk',
    'Antibiotik',
    'Antihistamin / Alergi',
    'Vitamin & Suplemen',
    'Cairan & Antiseptik'
  ];

  const filteredObat = obatList.filter(o => {
    const matchSearch =
      o.nama_obat.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.kode_obat.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.kategori.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchCat = filterCategory === 'All' || o.kategori === filterCategory;
    return matchSearch && matchCat;
  });

  const handleCreateObat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newObat.nama_obat) return;

    const created: Obat = {
      id: `obt-${Date.now()}`,
      kode_obat: newObat.kode_obat || `OBT-${Date.now()}`,
      nama_obat: newObat.nama_obat,
      kategori: newObat.kategori as any || 'Analgesik & Antipiretik',
      bentuk_sediaan: newObat.bentuk_sediaan as any || 'Tablet',
      satuan: newObat.satuan as any || 'strip',
      stok: Number(newObat.stok) || 10,
      stok_minimum: Number(newObat.stok_minimum) || 10,
      kadaluarsa: newObat.kadaluarsa || '2028-01-01',
      aturan_pakai_default: newObat.aturan_pakai_default || 'Sesuai anjuran dokter',
      keterangan: newObat.keterangan || ''
    };

    onSaveObat(created);
    setIsAddModalOpen(false);
  };

  const handleConfirmRestock = () => {
    if (restockModalItem && restockQty > 0) {
      onRestock(restockModalItem.id, restockQty);
      setRestockModalItem(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Pill className="w-5 h-5 text-emerald-700" />
            <h2 className="text-lg sm:text-xl font-bold text-stone-900">
              Instalasi Farmasi &amp; Apotek Poskestren Al Amien
            </h2>
          </div>
          <p className="text-xs text-stone-500 mt-0.5">
            Manajemen stok obat santri, batch kadaluarsa, restock apotek, dan penggunaan resep
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-xs shadow-sm transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Master Obat</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="w-full sm:w-80 relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari nama obat, kode, kategori..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 bg-stone-50/50"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="py-2 px-3 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 bg-stone-50/50"
          >
            {categories.map((c, idx) => (
              <option key={idx} value={c}>
                {c === 'All' ? 'Semua Kategori Obat' : c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Medicine Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredObat.map((obat) => {
          const isLowStock = obat.stok <= obat.stok_minimum;
          const isCritical = obat.stok <= 5;

          return (
            <div
              key={obat.id}
              className={`p-4 rounded-2xl border bg-white shadow-xs space-y-3 transition-colors ${
                isCritical ? 'border-rose-300' : isLowStock ? 'border-amber-300' : 'border-stone-200'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="font-mono text-[10px] text-stone-400 uppercase tracking-wider">{obat.kode_obat}</span>
                  <h4 className="font-bold text-stone-900 text-sm mt-0.5">{obat.nama_obat}</h4>
                  <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full bg-stone-100 text-stone-700 font-semibold">
                    {obat.kategori}
                  </span>
                </div>

                <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                  isCritical ? 'bg-rose-100 text-rose-800' :
                  isLowStock ? 'bg-amber-100 text-amber-800' :
                  'bg-emerald-100 text-emerald-800'
                }`}>
                  {isCritical ? 'Kritis!' : isLowStock ? 'Menipis' : 'Stok Aman'}
                </span>
              </div>

              {/* Stock Bar */}
              <div className="space-y-1 text-xs">
                <div className="flex items-center justify-between text-stone-600">
                  <span>Stok Tersedia:</span>
                  <span className="font-bold text-stone-900">
                    {obat.stok} {obat.satuan} <span className="text-[11px] font-normal text-stone-400">(Min: {obat.stok_minimum})</span>
                  </span>
                </div>
                <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      isCritical ? 'bg-rose-500' : isLowStock ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${Math.min(Math.round((obat.stok / (obat.stok_minimum * 3)) * 100), 100)}%` }}
                  />
                </div>
              </div>

              {/* Expiry & Rules */}
              <div className="text-[11px] space-y-1 text-stone-600 pt-2 border-t border-stone-100">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1 text-stone-500">
                    <Calendar className="w-3 h-3 text-stone-400" />
                    Kadaluarsa:
                  </span>
                  <span className="font-medium text-stone-800">{obat.kadaluarsa}</span>
                </div>
                <div>
                  <span className="text-stone-500">Aturan Pakai: </span>
                  <span className="italic text-stone-800">{obat.aturan_pakai_default}</span>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2 flex items-center justify-end">
                <button
                  onClick={() => {
                    setRestockModalItem(obat);
                    setRestockQty(20);
                  }}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-300 text-stone-700 font-semibold rounded-xl text-xs border border-stone-200 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <PackagePlus className="w-3.5 h-3.5" />
                  <span>Restock Obat</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Restock Modal */}
      {restockModalItem && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 border border-stone-200 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
                <PackagePlus className="w-4 h-4 text-emerald-600" />
                <span>Tambah Stok Obat</span>
              </h3>
              <button onClick={() => setRestockModalItem(null)} className="font-bold text-stone-400">✕</button>
            </div>

            <div className="space-y-1">
              <div className="font-bold text-stone-900 text-sm">{restockModalItem.nama_obat}</div>
              <div className="text-stone-500">Sisa stok saat ini: {restockModalItem.stok} {restockModalItem.satuan}</div>
            </div>

            <div>
              <label className="block font-semibold text-stone-700 mb-1">Jumlah Tambahan Stok ({restockModalItem.satuan}):</label>
              <input
                type="number"
                min="1"
                max="500"
                value={restockQty}
                onChange={(e) => setRestockQty(parseInt(e.target.value) || 1)}
                className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600 text-sm font-bold"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200">
              <button
                onClick={() => setRestockModalItem(null)}
                className="px-4 py-2 bg-stone-100 text-stone-700 font-semibold rounded-xl"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmRestock}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl"
              >
                Simpan Penambahan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Obat Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 border border-stone-200 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
                <Pill className="w-4 h-4 text-emerald-600" />
                <span>Pendaftaran Master Obat Baru</span>
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="font-bold text-stone-400">✕</button>
            </div>

            <form onSubmit={handleCreateObat} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Kode Obat</label>
                  <input
                    type="text"
                    required
                    value={newObat.kode_obat || ''}
                    onChange={(e) => setNewObat({ ...newObat, kode_obat: e.target.value })}
                    className="w-full p-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Kategori Obat</label>
                  <select
                    value={newObat.kategori || 'Analgesik & Antipiretik'}
                    onChange={(e) => setNewObat({ ...newObat, kategori: e.target.value as any })}
                    className="w-full p-2 rounded-lg border border-stone-300"
                  >
                    {categories.filter(c => c !== 'All').map((c, i) => (
                      <option key={i} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Nama Obat &amp; Dosis *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Amoxicillin 500 mg"
                  value={newObat.nama_obat || ''}
                  onChange={(e) => setNewObat({ ...newObat, nama_obat: e.target.value })}
                  className="w-full p-2 rounded-lg border border-stone-300"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Bentuk Sediaan</label>
                  <select
                    value={newObat.bentuk_sediaan || 'Tablet'}
                    onChange={(e) => setNewObat({ ...newObat, bentuk_sediaan: e.target.value as any })}
                    className="w-full p-2 rounded-lg border border-stone-300"
                  >
                    <option value="Tablet">Tablet</option>
                    <option value="Kapsul">Kapsul</option>
                    <option value="Sirup">Sirup</option>
                    <option value="Salep / Krim">Salep / Krim</option>
                    <option value="Tetes">Tetes</option>
                    <option value="Cairan">Cairan</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Satuan</label>
                  <select
                    value={newObat.satuan || 'strip'}
                    onChange={(e) => setNewObat({ ...newObat, satuan: e.target.value as any })}
                    className="w-full p-2 rounded-lg border border-stone-300"
                  >
                    <option value="strip">strip</option>
                    <option value="botol">botol</option>
                    <option value="tube">tube</option>
                    <option value="ampul">ampul</option>
                    <option value="pcs">pcs</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Stok Awal</label>
                  <input
                    type="number"
                    value={newObat.stok || 0}
                    onChange={(e) => setNewObat({ ...newObat, stok: parseInt(e.target.value) || 0 })}
                    className="w-full p-2 rounded-lg border border-stone-300"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Batas Minimum Stok</label>
                  <input
                    type="number"
                    value={newObat.stok_minimum || 10}
                    onChange={(e) => setNewObat({ ...newObat, stok_minimum: parseInt(e.target.value) || 10 })}
                    className="w-full p-2 rounded-lg border border-stone-300"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Tanggal Expired / Kadaluarsa</label>
                  <input
                    type="date"
                    value={newObat.kadaluarsa || '2028-01-01'}
                    onChange={(e) => setNewObat({ ...newObat, kadaluarsa: e.target.value })}
                    className="w-full p-2 rounded-lg border border-stone-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Aturan Pakai Standar</label>
                <input
                  type="text"
                  placeholder="3 x 1 tablet sehari sesudah makan"
                  value={newObat.aturan_pakai_default || ''}
                  onChange={(e) => setNewObat({ ...newObat, aturan_pakai_default: e.target.value })}
                  className="w-full p-2 rounded-lg border border-stone-300"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 text-stone-700 font-semibold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl"
                >
                  Simpan Master Obat
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
