import React from 'react';
import { 
  Activity, 
  Users, 
  FileText, 
  Pill, 
  Award, 
  Database, 
  PlusCircle, 
  HeartHandshake,
  Clock,
  ShieldAlert
} from 'lucide-react';
import { PetugasPoskestren } from '../types';

interface HeaderProps {
  activeTab: 'dashboard' | 'santri' | 'rekam-medis' | 'apotek' | 'surat' | 'laravel';
  setActiveTab: (tab: 'dashboard' | 'santri' | 'rekam-medis' | 'apotek' | 'surat' | 'laravel') => void;
  onOpenNewPeriksa: () => void;
  petugasList: PetugasPoskestren[];
  santriSakitCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewPeriksa,
  petugasList,
  santriSakitCount,
}) => {
  const petugasJaga = petugasList.find(p => p.status_jaga === 'Bertugas Hari Ini');

  return (
    <header className="bg-emerald-900 text-white shadow-md sticky top-0 z-40">
      {/* Top Banner / Identity */}
      <div className="border-b border-emerald-800/80 bg-emerald-950/70 px-4 py-2 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-emerald-200">
            <HeartHandshake className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold tracking-wide">POSKESTREN AL-AMIEN KEDIRI</span>
            <span className="text-emerald-500">•</span>
            <span className="text-emerald-300/90 hidden sm:inline">Ngasinan, Rejomulyo, Kota Kediri, Jawa Timur</span>
          </div>

          <div className="flex items-center gap-4 text-emerald-300">
            {petugasJaga && (
              <div className="flex items-center gap-1.5 bg-emerald-900/90 px-2.5 py-0.5 rounded-full border border-emerald-700/50">
                <Clock className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span>Petugas Jaga: <strong className="text-white font-medium">{petugasJaga.nama}</strong> ({petugasJaga.peran})</span>
              </div>
            )}
            {santriSakitCount > 0 && (
              <div className="flex items-center gap-1 bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/40">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span><strong>{santriSakitCount}</strong> Santri dalam Perawatan</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Logo & App Title */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg border border-emerald-400/30">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                  <span>DEK SANTRI</span>
                  <span className="text-xs font-semibold bg-emerald-700/80 text-emerald-100 px-2 py-0.5 rounded-md border border-emerald-500/40 uppercase tracking-wider">
                    v2.4 Poskestren
                  </span>
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-emerald-200/90 font-medium">
                Digitalisasi Pengelolaan Data &amp; Riwayat Kesehatan Santri Berbasis TI • Ponpes Al Amien Kediri
              </p>
            </div>
          </div>

          {/* Quick Action */}
          <div className="flex items-center gap-2.5">
            <button
              id="btn-quick-new-checkup"
              onClick={onOpenNewPeriksa}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-emerald-950 font-bold rounded-lg shadow-md transition-all text-sm cursor-pointer hover:shadow-emerald-500/20"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Pemeriksaan Baru</span>
            </button>

            <button
              id="btn-header-laravel-db"
              onClick={() => setActiveTab('laravel')}
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-all ${
                activeTab === 'laravel'
                  ? 'bg-amber-500 text-stone-950 border-amber-400 shadow-md'
                  : 'bg-emerald-950/60 hover:bg-emerald-800 text-emerald-200 border-emerald-700/60'
              }`}
            >
              <Database className="w-3.5 h-3.5 text-amber-300" />
              <span>Database Laravel</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 sm:gap-2 mt-4 pt-2 border-t border-emerald-800/60 overflow-x-auto no-scrollbar text-sm">
          <button
            id="tab-dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'dashboard'
                ? 'bg-emerald-800 text-white font-semibold shadow-inner'
                : 'text-emerald-200/80 hover:bg-emerald-800/50 hover:text-white'
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>Dashboard &amp; Epidemiologi</span>
          </button>

          <button
            id="tab-santri"
            onClick={() => setActiveTab('santri')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'santri'
                ? 'bg-emerald-800 text-white font-semibold shadow-inner'
                : 'text-emerald-200/80 hover:bg-emerald-800/50 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4 text-emerald-400" />
            <span>Data Santri (Banin / Banat)</span>
          </button>

          <button
            id="tab-rekam-medis"
            onClick={() => setActiveTab('rekam-medis')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'rekam-medis'
                ? 'bg-emerald-800 text-white font-semibold shadow-inner'
                : 'text-emerald-200/80 hover:bg-emerald-800/50 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-400" />
            <span>Rekam Medis (EHR)</span>
          </button>

          <button
            id="tab-apotek"
            onClick={() => setActiveTab('apotek')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'apotek'
                ? 'bg-emerald-800 text-white font-semibold shadow-inner'
                : 'text-emerald-200/80 hover:bg-emerald-800/50 hover:text-white'
            }`}
          >
            <Pill className="w-4 h-4 text-emerald-400" />
            <span>Apotek &amp; Obat</span>
          </button>

          <button
            id="tab-surat"
            onClick={() => setActiveTab('surat')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
              activeTab === 'surat'
                ? 'bg-emerald-800 text-white font-semibold shadow-inner'
                : 'text-emerald-200/80 hover:bg-emerald-800/50 hover:text-white'
            }`}
          >
            <Award className="w-4 h-4 text-emerald-400" />
            <span>Surat Izin &amp; Rujukan</span>
          </button>

          <button
            id="tab-laravel"
            onClick={() => setActiveTab('laravel')}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ml-auto ${
              activeTab === 'laravel'
                ? 'bg-amber-600 text-white font-semibold shadow-inner'
                : 'text-amber-300 hover:bg-emerald-800/50'
            }`}
          >
            <Database className="w-4 h-4 text-amber-400" />
            <span>Skema Laravel &amp; SQL</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
