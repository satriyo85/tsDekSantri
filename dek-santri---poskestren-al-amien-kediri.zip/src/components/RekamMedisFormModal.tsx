import React, { useState, useEffect } from 'react';
import { 
  HeartPulse, 
  Users, 
  ShieldAlert, 
  Pill, 
  Plus, 
  Trash2, 
  FileText, 
  Check, 
  AlertTriangle,
  Stethoscope,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { Santri, Obat, RekamMedis, ResepDetail, StatusPenanganan, PetugasPoskestren, SuratIzinSakit, SuratRujukan, SuratInformedConsent } from '../types';
import { calculateAge, isUnderage } from '../utils/printHelper';

interface RekamMedisFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  santriList: Santri[];
  obatList: Obat[];
  petugasList: PetugasPoskestren[];
  initialSelectedSantri?: Santri | null;
  onSaveRekamMedis: (
    rm: RekamMedis, 
    usedMeds: { obatId: string; jumlah: number }[],
    suratIzin?: SuratIzinSakit,
    suratRujukan?: SuratRujukan,
    suratConsent?: SuratInformedConsent
  ) => void;
}

const commonDiagnoses = [
  { label: 'Skabies (Kudis Santri)', code: 'B86', defaultTindakan: 'Edukasi sanitasi sprei/pakaian & isolasi sarung' },
  { label: 'ISPA / Batuk Pilek Akut', code: 'J06.9', defaultTindakan: 'Edukasi minum air hangat & istirahat' },
  { label: 'Gastritis / Dispepsia Akut', code: 'K29.7', defaultTindakan: 'Pola makan teratur, hindari pedas/asam' },
  { label: 'Febris / Demam Akut', code: 'R50.9', defaultTindakan: 'Kompres air hangat, observasi hidrasi' },
  { label: 'Cephalgia / Sakit Kepala', code: 'R51', defaultTindakan: 'Istirahat dan evaluasi pola tidur santri' },
  { label: 'Dermatitis Kontak / Alergi', code: 'L30.9', defaultTindakan: 'Identifikasi pencetus alergen dan kompres' },
];

export const RekamMedisFormModal: React.FC<RekamMedisFormModalProps> = ({
  isOpen,
  onClose,
  santriList,
  obatList,
  petugasList,
  initialSelectedSantri,
  onSaveRekamMedis,
}) => {
  const [selectedSantriId, setSelectedSantriId] = useState<string>(
    initialSelectedSantri?.id || (santriList[0]?.id || '')
  );

  const selectedSantri = santriList.find(s => s.id === selectedSantriId);

  // Form Fields
  const [petugasPemeriksa, setPetugasPemeriksa] = useState<string>(
    petugasList[0]?.nama || 'dr. H. Riza Fahmi, Sp.PD'
  );
  const [keluhanUtama, setKeluhanUtama] = useState('');
  const [riwayatSekarang, setRiwayatSekarang] = useState('');
  
  // Vital Signs
  const [tekananDarah, setTekananDarah] = useState('110/70');
  const [suhuTubuh, setSuhuTubuh] = useState<number>(36.8);
  const [nadi, setNadi] = useState<number>(80);
  const [lajuNapas, setLajuNapas] = useState<number>(20);
  const [beratBadan, setBeratBadan] = useState<number>(50);
  const [tinggiBadan, setTinggiBadan] = useState<number>(160);

  // Diagnosis
  const [diagnosaPrimer, setDiagnosaPrimer] = useState('');
  const [kodeIcd10, setKodeIcd10] = useState('');
  const [tindakanMedis, setTindakanMedis] = useState('');

  // Status & Duration
  const [statusPenanganan, setStatusPenanganan] = useState<StatusPenanganan>('Rawat Jalan');
  const [lamaIstirahat, setLamaIstirahat] = useState<number>(1);
  const [catatanPetugas, setCatatanPetugas] = useState('');

  // Medicines (Resep)
  const [resepItems, setResepItems] = useState<ResepDetail[]>([]);
  const [selectedObatId, setSelectedObatId] = useState<string>(obatList[0]?.id || '');
  const [obatQty, setObatQty] = useState<number>(1);
  const [obatSigna, setObatSigna] = useState<string>('3 x 1 tablet sesudah makan');

  // Letter triggers
  const [buatSuratIzin, setBuatSuratIzin] = useState<boolean>(false);
  const [buatSuratRujukan, setBuatSuratRujukan] = useState<boolean>(false);
  const [tujuanRujukan, setTujuanRujukan] = useState('IGD RSUD Gambiran Kota Kediri');

  // Informed Consent triggers for minors (< 18 years old)
  const [buatInformedConsent, setBuatInformedConsent] = useState<boolean>(false);
  const [namaKetuaKelompok, setNamaKetuaKelompok] = useState<string>('');
  const [peranKetuaKelompok, setPeranKetuaKelompok] = useState<string>('Ketua Kelompok Kamar / Pendamping Santri');
  const [namaKaderBertugas, setNamaKaderBertugas] = useState<string>(
    petugasList.find(p => p.peran === 'Kader Santri Husada')?.nama || 'Ustadz Wildan (Kader Santri Husada)'
  );

  const santriAge = selectedSantri ? calculateAge(selectedSantri.tanggal_lahir) : 0;
  const isMinor = selectedSantri ? isUnderage(selectedSantri.tanggal_lahir) : true;

  useEffect(() => {
    if (initialSelectedSantri) {
      setSelectedSantriId(initialSelectedSantri.id);
    }
  }, [initialSelectedSantri]);

  useEffect(() => {
    if (selectedSantri) {
      setNamaKetuaKelompok(`Ketua Kamar ${selectedSantri.kamar}`);
      if (isMinor && (statusPenanganan === 'Observasi Poskestren' || statusPenanganan === 'Rujukan Rumah Sakit')) {
        setBuatInformedConsent(true);
      }
    }
  }, [selectedSantriId, statusPenanganan]);

  // Handle Quick diagnosis selection
  const handleSelectQuickDiagnosis = (item: typeof commonDiagnoses[0]) => {
    setDiagnosaPrimer(item.label);
    setKodeIcd10(item.code);
    if (!tindakanMedis) {
      setTindakanMedis(item.defaultTindakan);
    }
  };

  // Add medicine to prescription
  const handleAddMedicine = () => {
    const obat = obatList.find(o => o.id === selectedObatId);
    if (!obat) return;

    if (obat.stok < obatQty) {
      alert(`Stok obat ${obat.nama_obat} hanya tersisa ${obat.stok} ${obat.satuan}. Tidak mencukupi permintaan ${obatQty}!`);
      return;
    }

    // Check if already added
    const existingIndex = resepItems.findIndex(i => i.obat_id === obat.id);
    if (existingIndex >= 0) {
      const updated = [...resepItems];
      updated[existingIndex].jumlah += obatQty;
      updated[existingIndex].aturan_pakai = obatSigna;
      setResepItems(updated);
    } else {
      setResepItems([
        ...resepItems,
        {
          obat_id: obat.id,
          nama_obat: obat.nama_obat,
          jumlah: obatQty,
          satuan: obat.satuan,
          aturan_pakai: obatSigna,
        }
      ]);
    }
  };

  const handleRemoveMedicine = (index: number) => {
    setResepItems(resepItems.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSantri || !keluhanUtama || !diagnosaPrimer) {
      alert('Mohon lengkapi santri, keluhan utama, dan diagnosa');
      return;
    }

    const now = new Date();
    const dateFormatted = now.toISOString().replace('T', ' ').slice(0, 16);
    const rmId = `rm-${Date.now()}`;
    const generatedNomorRM = `RM-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${String(Math.floor(100 + Math.random() * 900))}`;

    const newRM: RekamMedis = {
      id: rmId,
      nomor_rm: generatedNomorRM,
      santri_id: selectedSantri.id,
      santri_nis: selectedSantri.nis,
      santri_nama: selectedSantri.nama_lengkap,
      santri_asrama: `${selectedSantri.asrama_komplek} / ${selectedSantri.kamar}`,
      tanggal_periksa: dateFormatted,
      petugas_pemeriksa: petugasPemeriksa,
      keluhan_utama: keluhanUtama,
      riwayat_sekarang: riwayatSekarang,
      tekanan_darah: tekananDarah,
      suhu_tubuh: Number(suhuTubuh),
      nadi: Number(nadi),
      laju_napas: Number(lajuNapas),
      berat_badan: Number(beratBadan),
      tinggi_badan: Number(tinggiBadan),
      diagnosa_primer: diagnosaPrimer,
      kode_icd10: kodeIcd10,
      tindakan_medis: tindakanMedis,
      resep_obat: resepItems,
      status_penanganan: statusPenanganan,
      lama_istirahat_hari: lamaIstirahat,
      catatan_petugas: catatanPetugas,
      created_at: dateFormatted,
    };

    // Construct Surat Izin Sakit if checked or if status is not Rawat Jalan
    let suratIzin: SuratIzinSakit | undefined;
    if (buatSuratIzin || statusPenanganan === 'Observasi Poskestren' || statusPenanganan === 'Istirahat di Asrama') {
      const today = new Date();
      const endDate = new Date(today);
      endDate.setDate(today.getDate() + (lamaIstirahat || 1));

      suratIzin = {
        id: `sk-${Date.now()}`,
        nomor_surat: `${Math.floor(100 + Math.random() * 900)}/POSKESTREN-AA/SKS/${now.toLocaleString('en-US', { month: 'short' }).toUpperCase()}/${now.getFullYear()}`,
        rekam_medis_id: rmId,
        santri_id: selectedSantri.id,
        santri_nama: selectedSantri.nama_lengkap,
        santri_nis: selectedSantri.nis,
        asrama_kamar: `${selectedSantri.asrama_komplek} / ${selectedSantri.kamar}`,
        kelas_jenjang: `${selectedSantri.jenjang_pendidikan} - ${selectedSantri.kelas}`,
        diagnosa: diagnosaPrimer,
        tanggal_mulai: today.toISOString().slice(0, 10),
        tanggal_selesai: endDate.toISOString().slice(0, 10),
        lama_hari: lamaIstirahat || 1,
        rekomendasi: statusPenanganan === 'Observasi Poskestren' 
          ? 'Istirahat di Ruang Observasi Poskestren' 
          : 'Istirahat di Kamar Asrama',
        dokter_pemeriksa: petugasPemeriksa,
        sip_nip: 'SIP. 503/441/SIP-D/411.302/2022',
        tanggal_dibuat: today.toISOString().slice(0, 10),
      };
    }

    // Construct Surat Rujukan if checked or status is Rujukan
    let suratRujukan: SuratRujukan | undefined;
    if (buatSuratRujukan || statusPenanganan === 'Rujukan Rumah Sakit') {
      suratRujukan = {
        id: `rujuk-${Date.now()}`,
        nomor_surat: `${Math.floor(10 + Math.random() * 90)}/POSKESTREN-AA/RUJUK/${now.toLocaleString('en-US', { month: 'short' }).toUpperCase()}/${now.getFullYear()}`,
        rekam_medis_id: rmId,
        santri_id: selectedSantri.id,
        santri_nama: selectedSantri.nama_lengkap,
        santri_nis: selectedSantri.nis,
        tanggal_lahir: selectedSantri.tanggal_lahir,
        tujuan_faskes: tujuanRujukan,
        alasan_rujukan: `Pemeriksaan lanjutan dan tatalaksana spesialis untuk ${diagnosaPrimer}`,
        diagnosa_sementara: diagnosaPrimer,
        tanda_vital: `TD: ${tekananDarah} mmHg, Suhu: ${suhuTubuh}°C, Nadi: ${nadi} bpm, RR: ${lajuNapas} x/m`,
        terapi_awal_diberikan: tindakanMedis || 'Pertolongan pertama & stabilisasi di Poskestren Al Amien',
        dokter_perujuk: petugasPemeriksa,
        tanggal_surat: now.toISOString().slice(0, 10),
      };
    }

    // Construct Surat Informed Consent if checked
    let suratConsent: SuratInformedConsent | undefined;
    if (buatInformedConsent) {
      const romanMonths = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
      const currentRomanMonth = romanMonths[now.getMonth()];

      suratConsent = {
        id: `ic-${Date.now()}`,
        nomor_surat: `${Math.floor(10 + Math.random() * 90)}/POSKESTREN-AA/IC/${currentRomanMonth}/${now.getFullYear()}`,
        rekam_medis_id: rmId,
        santri_id: selectedSantri.id,
        santri_nama: selectedSantri.nama_lengkap,
        santri_nis: selectedSantri.nis,
        santri_umur: santriAge,
        santri_tanggal_lahir: selectedSantri.tanggal_lahir,
        santri_jk: selectedSantri.jenis_kelamin,
        asrama_kamar: `${selectedSantri.asrama_komplek} / ${selectedSantri.kamar}`,
        kelas_jenjang: `${selectedSantri.jenjang_pendidikan} - ${selectedSantri.kelas}`,
        diagnosa: diagnosaPrimer,
        tindakan_medis: tindakanMedis || `Observasi & Terapi Medis di Poskestren Al-Amien`,
        indikasi_tindakan: keluhanUtama,
        resiko_penjelasan: 'Telah dijelaskan secara lisan risiko dan alternatif tindakan klinis',
        status_persetujuan: 'Setuju',
        nama_ketua_kelompok: namaKetuaKelompok || `Ketua Kamar ${selectedSantri.kamar}`,
        peran_ketua_kelompok: peranKetuaKelompok,
        nama_kader_bertugas: namaKaderBertugas,
        dokter_penanggung_jawab: petugasPemeriksa,
        sip_dokter: 'SIP. 503/441/SIP-D/411.302/2022',
        tanggal_dibuat: now.toISOString().slice(0, 10),
        catatan_tambahan: catatanPetugas || `Pemeriksaan klinis RM ${generatedNomorRM}`,
      };
    }

    // Used medicines to deduct
    const usedMeds = resepItems.map(item => ({
      obatId: item.obat_id,
      jumlah: item.jumlah,
    }));

    onSaveRekamMedis(newRM, usedMeds, suratIzin, suratRujukan, suratConsent);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto border border-stone-200 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="sticky top-0 bg-emerald-900 text-white p-4 sm:p-5 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/30 flex items-center justify-center border border-emerald-400/40">
              <HeartPulse className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">Formulir Pemeriksaan Kesehatan Santri (Rekam Medis)</h3>
              <p className="text-xs text-emerald-200">Poskestren Pondok Pesantren Al Amien Kediri</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-xl bg-emerald-800 text-emerald-200 hover:text-white font-bold"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5 text-xs text-stone-700">
          {/* 1. Pilih Santri & Deteksi Alergi */}
          <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex-1">
                <label className="block font-bold text-stone-800 mb-1">Pilih Santri yang Diperiksa *</label>
                <select
                  value={selectedSantriId}
                  onChange={(e) => setSelectedSantriId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600 bg-white font-semibold text-stone-900 text-xs"
                >
                  {santriList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.nama_lengkap} (NIS: {s.nis}) — {s.asrama_komplek} / {s.kamar}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:w-64">
                <label className="block font-semibold text-stone-700 mb-1">Tenaga Medis Pemeriksa</label>
                <select
                  value={petugasPemeriksa}
                  onChange={(e) => setPetugasPemeriksa(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600 bg-white text-xs"
                >
                  {petugasList.map((p) => (
                    <option key={p.id} value={p.nama}>
                      {p.nama} ({p.peran})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Patient Warning Banner if allergy exists */}
            {selectedSantri && (
              <div className="pt-2 border-t border-stone-200 flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold text-stone-600">Golongan Darah: <strong>{selectedSantri.golongan_darah}</strong></span>
                  <span>•</span>
                  <span className="font-semibold text-stone-600">Asrama: <strong>{selectedSantri.asrama_komplek} ({selectedSantri.kamar})</strong></span>
                  <span>•</span>
                  <span className="font-semibold text-stone-600">Usia: <strong>{santriAge} Tahun</strong></span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                    isMinor 
                      ? 'bg-amber-50 text-amber-900 border-amber-300' 
                      : 'bg-stone-100 text-stone-700 border-stone-300'
                  }`}>
                    {isMinor ? '⚠️ Di Bawah Umur (< 18 Thn)' : 'Dewasa (≥ 18 Thn)'}
                  </span>
                </div>

                {selectedSantri.riwayat_alergi && selectedSantri.riwayat_alergi !== 'Tidak Ada' ? (
                  <div className="flex items-center gap-1.5 px-2.5 py-1 bg-rose-100 text-rose-800 font-bold rounded-lg border border-rose-300 animate-pulse">
                    <ShieldAlert className="w-4 h-4 text-rose-600" />
                    <span>PERINGATAN ALERGI: {selectedSantri.riwayat_alergi}</span>
                  </div>
                ) : (
                  <span className="text-emerald-700 font-medium">Riwayat Alergi: Bersih (Tidak Ada)</span>
                )}
              </div>
            )}
          </div>

          {/* 2. Tanda-Tanda Vital (TTV) */}
          <div className="space-y-2">
            <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Stethoscope className="w-4 h-4 text-emerald-700" />
              <span>Tanda-Tanda Vital (TTV) &amp; Fisik</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2.5 bg-stone-50/70 p-3 rounded-xl border border-stone-200">
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">Tensi (TD)</label>
                <input
                  type="text"
                  value={tekananDarah}
                  onChange={(e) => setTekananDarah(e.target.value)}
                  placeholder="110/70"
                  className="w-full p-2 rounded-lg border border-stone-300 focus:outline-emerald-600 bg-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">Suhu (°C) *</label>
                <input
                  type="number"
                  step="0.1"
                  required
                  value={suhuTubuh}
                  onChange={(e) => setSuhuTubuh(parseFloat(e.target.value))}
                  className={`w-full p-2 rounded-lg border focus:outline-emerald-600 bg-white font-bold ${
                    suhuTubuh >= 38 ? 'text-rose-600 border-rose-300' : 'border-stone-300'
                  }`}
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">Nadi (x/mnt)</label>
                <input
                  type="number"
                  value={nadi}
                  onChange={(e) => setNadi(parseInt(e.target.value))}
                  className="w-full p-2 rounded-lg border border-stone-300 focus:outline-emerald-600 bg-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">Napas (RR)</label>
                <input
                  type="number"
                  value={lajuNapas}
                  onChange={(e) => setLajuNapas(parseInt(e.target.value))}
                  className="w-full p-2 rounded-lg border border-stone-300 focus:outline-emerald-600 bg-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">Berat (kg)</label>
                <input
                  type="number"
                  value={beratBadan}
                  onChange={(e) => setBeratBadan(parseFloat(e.target.value))}
                  className="w-full p-2 rounded-lg border border-stone-300 focus:outline-emerald-600 bg-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-0.5">Tinggi (cm)</label>
                <input
                  type="number"
                  value={tinggiBadan}
                  onChange={(e) => setTinggiBadan(parseFloat(e.target.value))}
                  className="w-full p-2 rounded-lg border border-stone-300 focus:outline-emerald-600 bg-white"
                />
              </div>
            </div>
          </div>

          {/* 3. Keluhan Utama & Anamnesa */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Keluhan Utama / Anamnesa *</label>
              <textarea
                required
                rows={3}
                value={keluhanUtama}
                onChange={(e) => setKeluhanUtama(e.target.value)}
                placeholder="Contoh: Gatal-gatal di sela jari memburuk malam hari / Sesak napas setelah kerja bakti"
                className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
              />
            </div>
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Riwayat Penyakit Sekarang / Catatan Tambahan</label>
              <textarea
                rows={3}
                value={riwayatSekarang}
                onChange={(e) => setRiwayatSekarang(e.target.value)}
                placeholder="Sudah dirasakan sejak 3 hari, teman satu kamar ada gejala serupa..."
                className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
              />
            </div>
          </div>

          {/* 4. Diagnosa Klinis & Quick-Picks Poskestren */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block font-semibold text-stone-700">Diagnosa Primer (ICD-10) *</label>
              <span className="text-[11px] text-stone-500">Pilihan Cepat Penyakit Khas Santri:</span>
            </div>

            {/* Quick chips */}
            <div className="flex flex-wrap gap-1.5 mb-2">
              {commonDiagnoses.map((d, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSelectQuickDiagnosis(d)}
                  className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-medium border border-emerald-200 text-[11px] transition-colors cursor-pointer"
                >
                  + {d.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <input
                  type="text"
                  required
                  value={diagnosaPrimer}
                  onChange={(e) => setDiagnosaPrimer(e.target.value)}
                  placeholder="Contoh: Skabies (Kudis Santri) / Gastritis Akut"
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600 font-semibold"
                />
              </div>
              <div>
                <input
                  type="text"
                  value={kodeIcd10}
                  onChange={(e) => setKodeIcd10(e.target.value)}
                  placeholder="Kode ICD-10 (e.g. B86)"
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600 font-mono"
                />
              </div>
            </div>
          </div>

          {/* 5. Tindakan Medis */}
          <div>
            <label className="block font-semibold text-stone-700 mb-1">Tindakan Klinis &amp; Edukasi Kesehatan</label>
            <input
              type="text"
              value={tindakanMedis}
              onChange={(e) => setTindakanMedis(e.target.value)}
              placeholder="Contoh: Perawatan luka lecet, kompres hangat, edukasi jemur kasur & sterilisasi sprei"
              className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
            />
          </div>

          {/* 6. Resep Obat Apotek Poskestren (Dipotong dari Stok) */}
          <div className="p-4 rounded-xl bg-teal-50/50 border border-teal-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Pill className="w-4 h-4 text-teal-700" />
                <h4 className="font-bold text-stone-900 text-xs uppercase tracking-wider">
                  Pemberian Obat (Apotek Poskestren)
                </h4>
              </div>
              <span className="text-[11px] text-teal-800 font-medium">Stok obat akan otomatis berkurang</span>
            </div>

            {/* Add medication control */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 bg-white p-3 rounded-lg border border-teal-200">
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">Nama Obat &amp; Stok Tersedia</label>
                <select
                  value={selectedObatId}
                  onChange={(e) => {
                    setSelectedObatId(e.target.value);
                    const obt = obatList.find(o => o.id === e.target.value);
                    if (obt && obt.aturan_pakai_default) {
                      setObatSigna(obt.aturan_pakai_default);
                    }
                  }}
                  className="w-full p-2 rounded-lg border border-stone-300 text-xs"
                >
                  {obatList.map((o) => (
                    <option key={o.id} value={o.id} disabled={o.stok <= 0}>
                      {o.nama_obat} ({o.kategori}) — Sisa: {o.stok} {o.satuan} {o.stok <= 0 ? '(HABIS)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">Jumlah</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={obatQty}
                  onChange={(e) => setObatQty(parseInt(e.target.value) || 1)}
                  className="w-full p-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">Aturan Pakai / Signa</label>
                <input
                  type="text"
                  value={obatSigna}
                  onChange={(e) => setObatSigna(e.target.value)}
                  placeholder="3 x 1 tablet sesudah makan"
                  className="w-full p-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>

              <div className="sm:col-span-4 flex justify-end mt-1">
                <button
                  type="button"
                  onClick={handleAddMedicine}
                  className="px-3 py-1.5 bg-teal-700 hover:bg-teal-600 text-white rounded-lg font-semibold flex items-center gap-1 text-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambahkan ke Resep Santri</span>
                </button>
              </div>
            </div>

            {/* Medication List */}
            {resepItems.length > 0 && (
              <div className="space-y-1.5 mt-2">
                <span className="font-semibold text-stone-700 text-xs">Obat yang Diberikan untuk Santri:</span>
                <div className="divide-y divide-teal-100 bg-white rounded-lg border border-teal-200 overflow-hidden">
                  {resepItems.map((item, idx) => (
                    <div key={idx} className="p-2 flex items-center justify-between text-xs">
                      <div>
                        <strong className="text-teal-950">{item.nama_obat}</strong>
                        <span className="text-stone-500 ml-2 font-mono">
                          x {item.jumlah} {item.satuan}
                        </span>
                        <div className="text-[11px] text-stone-600 italic">Signa: {item.aturan_pakai}</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveMedicine(idx)}
                        className="p-1 text-rose-600 hover:bg-rose-50 rounded"
                        title="Hapus Obat"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 7. Status Penanganan & Tindak Lanjut */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-stone-50 p-4 rounded-xl border border-stone-200">
            <div>
              <label className="block font-semibold text-stone-700 mb-1">Status Penanganan Santri *</label>
              <select
                value={statusPenanganan}
                onChange={(e) => setStatusPenanganan(e.target.value as StatusPenanganan)}
                className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600 bg-white font-bold"
              >
                <option value="Rawat Jalan">Rawat Jalan (Dapat Mengikuti Kegiatan Biasa)</option>
                <option value="Observasi Poskestren">Observasi Poskestren (Bed Rest di Klinik Al Amien)</option>
                <option value="Istirahat di Asrama">Istirahat di Asrama (Isolasi / Bed Rest di Kamar)</option>
                <option value="Izin Pulang ke Rumah">Izin Pulang ke Orang Tua (Home Care Sementara)</option>
                <option value="Rujukan Rumah Sakit">Rujukan Rumah Sakit (RSUD Gambiran / Bhayangkara)</option>
              </select>
            </div>

            {statusPenanganan !== 'Rawat Jalan' && (
              <div>
                <label className="block font-semibold text-stone-700 mb-1">Lama Izin Istirahat (Hari)</label>
                <input
                  type="number"
                  min="1"
                  max="14"
                  value={lamaIstirahat}
                  onChange={(e) => setLamaIstirahat(parseInt(e.target.value) || 1)}
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600 bg-white"
                />
              </div>
            )}

            {/* Document Checkbox options */}
            <div className="sm:col-span-2 pt-2 border-t border-stone-200 space-y-2">
              <label className="flex items-center gap-2 font-semibold text-stone-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={buatSuratIzin || statusPenanganan === 'Observasi Poskestren' || statusPenanganan === 'Istirahat di Asrama'}
                  onChange={(e) => setBuatSuratIzin(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded"
                />
                <span>Terbitkan Surat Keterangan Sakit / Izin Istirahat Resmi Poskestren Al Amien</span>
              </label>

              {(statusPenanganan === 'Rujukan Rumah Sakit' || buatSuratRujukan) && (
                <div className="p-3 bg-rose-50 rounded-lg border border-rose-200 space-y-2">
                  <label className="flex items-center gap-2 font-semibold text-rose-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={buatSuratRujukan || statusPenanganan === 'Rujukan Rumah Sakit'}
                      onChange={(e) => setBuatSuratRujukan(e.target.checked)}
                      className="w-4 h-4 text-rose-600 rounded"
                    />
                    <span>Terbitkan Surat Pengantar Rujukan Medis ke Rumah Sakit</span>
                  </label>
                  <div>
                    <label className="block text-[11px] font-semibold text-rose-800 mb-1">Fasilitas Kesehatan Rujukan</label>
                    <input
                      type="text"
                      value={tujuanRujukan}
                      onChange={(e) => setTujuanRujukan(e.target.value)}
                      placeholder="Contoh: IGD RSUD Gambiran Kota Kediri / RS Bhayangkara Kediri"
                      className="w-full p-2 rounded-lg border border-rose-300 text-xs bg-white"
                    />
                  </div>
                </div>
              )}

              {/* Informed Consent for Minors */}
              <div className={`p-3.5 rounded-xl border transition-colors ${
                buatInformedConsent || isMinor
                  ? 'bg-amber-50/80 border-amber-300'
                  : 'bg-stone-50 border-stone-200'
              }`}>
                <label className="flex items-start gap-2.5 font-bold text-amber-950 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={buatInformedConsent}
                    onChange={(e) => setBuatInformedConsent(e.target.checked)}
                    className="w-4 h-4 mt-0.5 text-emerald-600 rounded"
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-700 inline" />
                      <span>Terbitkan Surat Persetujuan Tindakan Medis (Informed Consent)</span>
                      {isMinor && (
                        <span className="px-1.5 py-0.5 text-[10px] bg-amber-200 text-amber-900 rounded font-bold">
                          Wajib Santri Di Bawah Umur (&lt; 18 Thn)
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] font-normal text-amber-800 mt-0.5">
                      Dokumen resmi yang ditandatangani oleh <strong>Ketua Kelompok Santri / Asrama</strong> dan <strong>Kader Santri Husada</strong> yang bertugas.
                    </p>
                  </div>
                </label>

                {buatInformedConsent && (
                  <div className="mt-3 pt-3 border-t border-amber-200/80 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                        Nama Ketua Kelompok / Kamar (Pihak I) *
                      </label>
                      <input
                        type="text"
                        value={namaKetuaKelompok}
                        onChange={(e) => setNamaKetuaKelompok(e.target.value)}
                        placeholder="Contoh: Ahmad Syakir (Ketua Kamar)"
                        className="w-full p-2 rounded-lg border border-stone-300 text-xs bg-white"
                        required={buatInformedConsent}
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                        Peran / Posisi di Asrama
                      </label>
                      <input
                        type="text"
                        value={peranKetuaKelompok}
                        onChange={(e) => setPeranKetuaKelompok(e.target.value)}
                        className="w-full p-2 rounded-lg border border-stone-300 text-xs bg-white"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                        Kader Santri Husada yang Bertugas (Pihak II) *
                      </label>
                      <input
                        type="text"
                        value={namaKaderBertugas}
                        onChange={(e) => setNamaKaderBertugas(e.target.value)}
                        placeholder="Nama Kader Santri Husada / Petugas Poskestren"
                        className="w-full p-2 rounded-lg border border-stone-300 text-xs bg-white"
                        required={buatInformedConsent}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Simpan Rekam Medis &amp; Potong Stok</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
