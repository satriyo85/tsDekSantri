import React from 'react';
import { 
  Users, 
  MapPin, 
  Droplet, 
  Phone, 
  ShieldAlert, 
  Clock, 
  Stethoscope, 
  FileText, 
  HeartPulse, 
  Pill, 
  Printer, 
  Download,
  CheckCircle2, 
  AlertCircle, 
  Bed
} from 'lucide-react';
import { Santri, RekamMedis } from '../types';
import { printHtmlContent, downloadDocumentFile } from '../utils/printHelper';

interface SantriDetailModalProps {
  santri: Santri | null;
  rekamMedisList: RekamMedis[];
  onClose: () => void;
  onNewCheckup: (santri: Santri) => void;
}

export const SantriDetailModal: React.FC<SantriDetailModalProps> = ({
  santri,
  rekamMedisList,
  onClose,
  onNewCheckup,
}) => {
  if (!santri) return null;

  const history = rekamMedisList
    .filter(rm => rm.santri_id === santri.id)
    .sort((a, b) => new Date(b.tanggal_periksa).getTime() - new Date(a.tanggal_periksa).getTime());

  const hasAllergy = santri.riwayat_alergi && santri.riwayat_alergi !== 'Tidak Ada';

  const generateBukuRiwayatSantriHtml = () => {
    const historyRows = history.map((rm, i) => {
      const meds = rm.resep_obat && rm.resep_obat.length > 0
        ? rm.resep_obat.map(m => `${m.nama_obat} (${m.jumlah})`).join(', ')
        : '-';

      return `
        <tr>
          <td style="text-align: center;">${i + 1}</td>
          <td style="white-space: nowrap; font-size: 8.5pt;">${rm.tanggal_periksa}</td>
          <td>${rm.keluhan_utama}</td>
          <td style="font-size: 8.5pt;">${rm.tekanan_darah || '-'}, ${rm.suhu_tubuh || '-'}°C</td>
          <td><strong>${rm.diagnosa_primer}</strong> ${rm.kode_icd10 ? `(${rm.kode_icd10})` : ''}</td>
          <td style="font-size: 8.5pt;">${meds}</td>
          <td><span style="font-weight: bold;">${rm.status_penanganan}</span></td>
          <td style="font-size: 8.5pt;">${rm.petugas_pemeriksa}</td>
        </tr>
      `;
    }).join('');

    return `
      <div class="header-kop">
        <div class="kop-yayasan">YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI</div>
        <div class="kop-poskestren">POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN</div>
        <div class="kop-alamat">Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129<br>Sistem Digitalisasi Pengelolaan Data dan Riwayat Kesehatan Santri (DEK SANTRI)</div>
      </div>

      <div class="doc-header">
        <div class="doc-title">BUKU CATATAN RIWAYAT KESEHATAN SANTRI (EHR)</div>
        <div class="doc-nomor">Nomor Induk Santri (NIS): ${santri.nis}</div>
      </div>

      <div class="content-box">
        <div style="font-weight: bold; margin-bottom: 6px; font-size: 10pt; color: #064e3b; border-bottom: 1px solid #e7e5e4; padding-bottom: 4px;">
          I. BIODATA &amp; IDENTITAS SANTRI
        </div>
        <div class="grid-row"><span class="grid-label">Nama Lengkap</span><span class="grid-value">: <strong>${santri.nama_lengkap}</strong> (${santri.jenis_kelamin === 'L' ? 'Santri Putra / Banin' : 'Santri Putri / Banat'})</span></div>
        <div class="grid-row"><span class="grid-label">Tempat, Tanggal Lahir</span><span class="grid-value">: ${santri.tempat_lahir}, ${santri.tanggal_lahir}</span></div>
        <div class="grid-row"><span class="grid-label">Pendidikan Pesantren</span><span class="grid-value">: ${santri.jenjang_pendidikan} • Kelas ${santri.kelas}</span></div>
        <div class="grid-row"><span class="grid-label">Asrama &amp; Kamar</span><span class="grid-value">: ${santri.asrama_komplek}, Kamar: ${santri.kamar}</span></div>
        <div class="grid-row"><span class="grid-label">Golongan Darah</span><span class="grid-value">: <strong>${santri.golongan_darah || '-'}</strong></span></div>
        <div class="grid-row"><span class="grid-label">Wali / Orang Tua</span><span class="grid-value">: ${santri.nama_wali} (Telp: ${santri.telepon_wali})</span></div>
        <div class="grid-row"><span class="grid-label">Alamat Asal</span><span class="grid-value">: ${santri.alamat_asal}</span></div>
      </div>

      <div class="content-box" style="margin-top: 10px; background-color: #fefce8; border-color: #fef08a;">
        <div style="font-weight: bold; margin-bottom: 4px; font-size: 9.5pt; color: #854d0e;">
          II. RIWAYAT MEDIS KHUSUS &amp; ALERGI
        </div>
        <div class="grid-row"><span class="grid-label">Riwayat Alergi Obat/Makanan</span><span class="grid-value">: <strong style="color: #b91c1c;">${santri.riwayat_alergi || 'Tidak Ada'}</strong></span></div>
        <div class="grid-row"><span class="grid-label">Penyakit Kronis / Bawaan</span><span class="grid-value">: ${santri.riwayat_penyakit_kronis || 'Tidak Ada'}</span></div>
        <div class="grid-row"><span class="grid-label">Pengurus Asrama Santri</span><span class="grid-value">: ${santri.asrama_komplek} (Kamar ${santri.kamar})</span></div>
      </div>

      <div style="margin-top: 14px;">
        <div style="font-weight: bold; font-size: 10pt; margin-bottom: 6px; color: #1c1917;">
          III. REKAM HISTORIS KUNJUNGAN &amp; PEMERIKSAAN KLINIS (${history.length} Catatan)
        </div>
        <table>
          <thead>
            <tr>
              <th>No</th>
              <th>Tanggal</th>
              <th>Keluhan</th>
              <th>TTV</th>
              <th>Diagnosa</th>
              <th>Terapi Farmasi</th>
              <th>Status</th>
              <th>Pemeriksa</th>
            </tr>
          </thead>
          <tbody>
            ${historyRows || '<tr><td colspan="8" style="text-align: center; color: #78716c;">Belum pernah tercatat melakukan kunjungan/berobat ke Poskestren. Santri dalam kondisi prima.</td></tr>'}
          </tbody>
        </table>
      </div>

      <div class="signature-wrap">
        <div class="signature-box">
          <div>Mengetahui,<br><span class="font-bold">Ketua Pengurus Asrama</span></div>
          <div class="signature-space"></div>
          <div class="font-bold underline">Ustadz / Ustadzah Asrama</div>
          <div style="font-size: 8.5pt; color: #57534e;">${santri.asrama_komplek}</div>
        </div>

        <div class="signature-box">
          <div>Kediri, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}<br><span class="font-bold">Penanggung Jawab Poskestren</span></div>
          <div class="signature-space"></div>
          <div class="font-bold underline">dr. H. Ahmad Fauzi, M.Kes</div>
          <div style="font-size: 8.5pt; color: #57534e;">Poskestren Ponpes Al-Amien Kediri</div>
        </div>
      </div>
    `;
  };

  const handlePrintBuku = () => {
    printHtmlContent({
      title: `Buku Riwayat Kesehatan - ${santri.nama_lengkap} (${santri.nis})`,
      bodyHtml: generateBukuRiwayatSantriHtml(),
    });
  };

  const handleDownloadBuku = () => {
    const filename = `Riwayat_Kesehatan_${santri.nis}_${santri.nama_lengkap.replace(/[^a-zA-Z0-9]/g, '_')}`;
    downloadDocumentFile(
      filename,
      `Buku Riwayat Kesehatan - ${santri.nama_lengkap}`,
      generateBukuRiwayatSantriHtml()
    );
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 z-50 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto border border-stone-200 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-stone-100 p-4 sm:p-5 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
              santri.jenis_kelamin === 'L' ? 'bg-emerald-100 text-emerald-900' : 'bg-rose-100 text-rose-900'
            }`}>
              {santri.jenis_kelamin === 'L' ? 'Banin' : 'Banat'}
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-base sm:text-lg flex items-center gap-2">
                <span>{santri.nama_lengkap}</span>
                <span className="text-xs font-mono bg-stone-100 text-stone-600 px-2 py-0.5 rounded">
                  NIS: {santri.nis}
                </span>
              </h3>
              <p className="text-xs text-stone-500">
                Buku Riwayat Kesehatan Santri (EHR) • Poskestren Al Amien Kediri
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleDownloadBuku}
              title="Unduh Berkas Buku Riwayat Kesehatan (HTML / PDF)"
              className="p-2 text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-xl border border-emerald-300 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Unduh File</span>
            </button>
            <button
              onClick={handlePrintBuku}
              title="Cetak langsung atau Simpan sebagai PDF"
              className="p-2 text-white bg-emerald-700 hover:bg-emerald-600 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / Simpan PDF</span>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-xl bg-stone-100 text-stone-600 hover:bg-stone-200 font-bold cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-6 text-xs text-stone-700">
          {/* Identity Card */}
          <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <span className="text-[11px] text-stone-400 uppercase font-semibold">Jenjang &amp; Kelas</span>
              <div className="font-semibold text-stone-900 mt-0.5">{santri.jenjang_pendidikan} ({santri.kelas})</div>
            </div>

            <div>
              <span className="text-[11px] text-stone-400 uppercase font-semibold">Asrama &amp; Kamar</span>
              <div className="font-semibold text-stone-900 mt-0.5 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-stone-500" />
                <span>{santri.asrama_komplek} / {santri.kamar}</span>
              </div>
            </div>

            <div>
              <span className="text-[11px] text-stone-400 uppercase font-semibold">Golongan Darah</span>
              <div className="font-bold text-stone-900 mt-0.5 flex items-center gap-1">
                <Droplet className="w-3.5 h-3.5 text-rose-600" />
                <span>Tipe {santri.golongan_darah}</span>
              </div>
            </div>

            <div>
              <span className="text-[11px] text-stone-400 uppercase font-semibold">Tempat, Tanggal Lahir</span>
              <div className="font-medium text-stone-800 mt-0.5">{santri.tempat_lahir}, {santri.tanggal_lahir}</div>
            </div>

            <div>
              <span className="text-[11px] text-stone-400 uppercase font-semibold">Wali &amp; No. Telepon</span>
              <div className="font-medium text-stone-800 mt-0.5 flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>{santri.nama_wali} ({santri.telepon_wali})</span>
              </div>
            </div>

            <div>
              <span className="text-[11px] text-stone-400 uppercase font-semibold">Status Kesehatan Saat Ini</span>
              <div className="mt-0.5">
                <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                  santri.status_kesehatan === 'Aktif'
                    ? 'bg-emerald-100 text-emerald-800'
                    : santri.status_kesehatan === 'Observasi_Poskestren'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-rose-100 text-rose-800'
                }`}>
                  {santri.status_kesehatan === 'Aktif' && <CheckCircle2 className="w-3 h-3 text-emerald-700" />}
                  {santri.status_kesehatan === 'Observasi_Poskestren' && <Bed className="w-3 h-3 text-amber-700" />}
                  {santri.status_kesehatan === 'Rujukan_RS' && <AlertCircle className="w-3 h-3 text-rose-700" />}
                  {santri.status_kesehatan.replace('_', ' ')}
                </span>
              </div>
            </div>
          </div>

          {/* Safety & Allergy Alert Box */}
          <div className={`p-4 rounded-xl border flex items-start gap-3 ${
            hasAllergy ? 'bg-rose-50 border-rose-200 text-rose-900' : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}>
            <ShieldAlert className={`w-5 h-5 shrink-0 mt-0.5 ${hasAllergy ? 'text-rose-600' : 'text-emerald-600'}`} />
            <div className="space-y-1">
              <div className="font-bold text-xs">
                {hasAllergy ? 'PERHATIAN KHUSUS: SANTRI MEMILIKI RIWAYAT ALERGI' : 'Tidak Ada Riwayat Alergi Dilaporkan'}
              </div>
              <div className="text-[11px] leading-relaxed">
                <strong>Riwayat Alergi:</strong> {santri.riwayat_alergi || 'Tidak Ada'} <br />
                <strong>Penyakit Kronis / Bawaan:</strong> {santri.riwayat_penyakit_kronis || 'Tidak Ada'}
              </div>
            </div>
          </div>

          {/* Action to create checkup for this santri */}
          <div className="flex items-center justify-between bg-emerald-900 text-white p-4 rounded-xl shadow-xs">
            <div>
              <div className="font-bold text-sm">Santri Mengeluh Sakit Hari Ini?</div>
              <div className="text-emerald-200 text-[11px]">Buka formulir pemeriksaan fisik, diagnosa, dan pemberian obat poskestren</div>
            </div>
            <button
              onClick={() => {
                onClose();
                onNewCheckup(santri);
              }}
              className="px-4 py-2 bg-emerald-400 hover:bg-emerald-300 text-emerald-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <HeartPulse className="w-4 h-4" />
              <span>Periksa Santri Ini</span>
            </button>
          </div>

          {/* Examination History Timeline */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-stone-200 pb-2">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-700" />
                <h4 className="font-bold text-stone-900 text-sm">
                  Riwayat Kunjungan Medis ({history.length} Pemeriksaan)
                </h4>
              </div>
            </div>

            {history.length === 0 ? (
              <div className="py-8 text-center text-stone-400 bg-stone-50 rounded-xl border border-stone-200">
                Santri belum memiliki catatan kunjungan rekam medis di Poskestren Al Amien.
              </div>
            ) : (
              <div className="space-y-4">
                {history.map((rm) => (
                  <div key={rm.id} className="p-4 rounded-xl border border-stone-200 bg-white hover:border-emerald-300 transition-colors space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-100 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-emerald-900">{rm.nomor_rm}</span>
                        <span className="text-stone-400">•</span>
                        <span className="text-stone-600 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-stone-400" />
                          {rm.tanggal_periksa}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-stone-500 font-medium">Pemeriksa: {rm.petugas_pemeriksa}</span>
                        <span className="px-2 py-0.5 rounded-full bg-stone-100 text-stone-700 font-semibold text-[10px]">
                          {rm.status_penanganan}
                        </span>
                      </div>
                    </div>

                    {/* Vitals */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-stone-50 p-2.5 rounded-lg text-[11px]">
                      <div>
                        <span className="text-stone-400">Tekanan Darah:</span>
                        <div className="font-semibold text-stone-800">{rm.tekanan_darah || '-'} mmHg</div>
                      </div>
                      <div>
                        <span className="text-stone-400">Suhu Tubuh:</span>
                        <div className={`font-bold ${rm.suhu_tubuh >= 38 ? 'text-rose-600' : 'text-stone-800'}`}>
                          {rm.suhu_tubuh} °C
                        </div>
                      </div>
                      <div>
                        <span className="text-stone-400">Nadi / RR:</span>
                        <div className="font-semibold text-stone-800">{rm.nadi || '-'} bpm / {rm.laju_napas || '-'} x/m</div>
                      </div>
                      <div>
                        <span className="text-stone-400">BB / TB:</span>
                        <div className="font-semibold text-stone-800">{rm.berat_badan || '-'} kg / {rm.tinggi_badan || '-'} cm</div>
                      </div>
                    </div>

                    {/* Complaint & Diagnosis */}
                    <div className="space-y-1 text-xs">
                      <div>
                        <span className="font-semibold text-stone-600">Keluhan: </span>
                        <span className="text-stone-800">{rm.keluhan_utama}</span>
                      </div>
                      <div>
                        <span className="font-semibold text-emerald-800">Diagnosa: </span>
                        <span className="font-bold text-stone-900">{rm.diagnosa_primer}</span>
                        {rm.kode_icd10 && (
                          <span className="ml-1.5 px-1.5 py-0.2 bg-emerald-100 text-emerald-900 rounded font-mono text-[10px]">
                            {rm.kode_icd10}
                          </span>
                        )}
                      </div>
                      {rm.tindakan_medis && (
                        <div>
                          <span className="font-semibold text-stone-600">Tindakan Klinis: </span>
                          <span className="text-stone-800">{rm.tindakan_medis}</span>
                        </div>
                      )}
                    </div>

                    {/* Prescribed Medicines */}
                    {rm.resep_obat && rm.resep_obat.length > 0 && (
                      <div className="mt-2 pt-2 border-t border-stone-100">
                        <span className="font-semibold text-stone-600 flex items-center gap-1 mb-1.5">
                          <Pill className="w-3.5 h-3.5 text-teal-600" />
                          <span>Resep Obat yang Diberikan:</span>
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {rm.resep_obat.map((item, idx) => (
                            <div key={idx} className="bg-teal-50 text-teal-900 border border-teal-200 px-2.5 py-1 rounded-lg text-[11px]">
                              <strong>{item.nama_obat}</strong> ({item.jumlah} {item.satuan}) • <em>{item.aturan_pakai}</em>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-stone-50 border-t border-stone-200 p-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handlePrintBuku}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / Simpan PDF (Print)</span>
            </button>
            <button
              onClick={handleDownloadBuku}
              className="px-3 py-2 bg-white hover:bg-stone-100 text-stone-700 border border-stone-200 font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Unduh File</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onNewCheckup(santri);
              }}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Stethoscope className="w-4 h-4" />
              <span>Periksa Santri Ini</span>
            </button>
            <button
              onClick={onClose}
              className="px-5 py-2 bg-stone-200 hover:bg-stone-300 text-stone-800 font-semibold rounded-xl text-xs cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
