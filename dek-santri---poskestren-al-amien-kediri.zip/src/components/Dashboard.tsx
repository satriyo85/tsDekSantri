import React from 'react';
import { 
  Users, 
  Activity, 
  Bed, 
  AlertTriangle, 
  TrendingUp, 
  Building2, 
  Calendar, 
  HeartPulse, 
  ArrowRight,
  ShieldCheck,
  Stethoscope,
  Clock,
  Pill
} from 'lucide-react';
import { Santri, RekamMedis, Obat, PetugasPoskestren, NavTab } from '../types';

interface DashboardProps {
  santriList: Santri[];
  rekamMedisList: RekamMedis[];
  obatList: Obat[];
  petugasList: PetugasPoskestren[];
  onSelectSantri: (santri: Santri) => void;
  onOpenNewPeriksa: () => void;
  onNavigateTab: (tab: NavTab) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  santriList,
  rekamMedisList,
  obatList,
  petugasList,
  onSelectSantri,
  onOpenNewPeriksa,
  onNavigateTab,
}) => {
  // Calculations
  const totalSantri = santriList.length;
  const santriObservasi = santriList.filter(s => s.status_kesehatan === 'Observasi_Poskestren').length;
  const santriIzinAsrama = santriList.filter(s => s.status_kesehatan === 'Izin_Asrama').length;
  const santriRujukan = santriList.filter(s => s.status_kesehatan === 'Rujukan_RS').length;
  const totalSakit = santriObservasi + santriIzinAsrama + santriRujukan;
  
  const todayDateStr = new Date().toISOString().slice(0, 10);
  const kunjunganHariIni = rekamMedisList.filter(rm => rm.tanggal_periksa.startsWith(todayDateStr) || rm.tanggal_periksa.startsWith('2026-09-19')).length;
  
  const obatMenipis = obatList.filter(o => o.stok <= o.stok_minimum);

  // Common Disease stats from Rekam Medis
  const diseaseCounts: Record<string, number> = {};
  rekamMedisList.forEach(rm => {
    let key = 'Lain-lain';
    const diag = rm.diagnosa_primer.toLowerCase();
    if (diag.includes('skabies') || diag.includes('scabies') || diag.includes('kudis')) key = 'Skabies (Kudis Santri)';
    else if (diag.includes('asma') || diag.includes('ispa') || diag.includes('batuk') || diag.includes('pilek')) key = 'ISPA & Asma';
    else if (diag.includes('dispepsia') || diag.includes('gastritis') || diag.includes('maag')) key = 'Dispepsia / Gastritis';
    else if (diag.includes('dengue') || diag.includes('dbd') || diag.includes('febris') || diag.includes('demam')) key = 'Febris / Suspek DBD';
    else if (diag.includes('cephalgia') || diag.includes('pusing') || diag.includes('kepala')) key = 'Cephalgia / Sakit Kepala';
    else key = rm.diagnosa_primer.split('(')[0].trim();
    
    diseaseCounts[key] = (diseaseCounts[key] || 0) + 1;
  });

  const sortedDiseases = Object.entries(diseaseCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const maxDiseaseCount = Math.max(...sortedDiseases.map(d => d[1]), 1);

  // Asrama breakdown
  const asramaCounts: Record<string, number> = {};
  santriList.filter(s => s.status_kesehatan !== 'Aktif').forEach(s => {
    asramaCounts[s.asrama_komplek] = (asramaCounts[s.asrama_komplek] || 0) + 1;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Welcome & Alert Notice */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 rounded-2xl p-6 text-white shadow-sm border border-emerald-700/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-700/80 text-emerald-200 text-xs font-semibold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
              Sistem Informasi Kesehatan Santri (Poskestren)
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
              Selamat Datang di Portal DEK SANTRI Al Amien Kediri
            </h2>
            <p className="text-emerald-200 text-sm leading-relaxed">
              Memfasilitasi pencatatan rekam medis terpadu, pemantauan wabah sanitasi asrama, ketersediaan obat farmasi, dan penerbitan surat izin sakit resmi untuk kepengasuhan pondok.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenNewPeriksa}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 text-emerald-950 font-bold rounded-xl shadow-md transition-all text-sm cursor-pointer"
            >
              <HeartPulse className="w-4 h-4" />
              <span>Input Periksa Santri</span>
            </button>
            <button
              onClick={() => onNavigateTab('santri')}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-950/70 hover:bg-emerald-950 text-white font-medium rounded-xl border border-emerald-600/50 transition-all text-sm cursor-pointer"
            >
              <Users className="w-4 h-4 text-emerald-300" />
              <span>Daftar Santri</span>
            </button>
            <button
              onClick={() => onNavigateTab('laporan')}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-950/70 hover:bg-emerald-950 text-white font-medium rounded-xl border border-emerald-600/50 transition-all text-sm cursor-pointer"
            >
              <TrendingUp className="w-4 h-4 text-amber-300" />
              <span>Rekap Laporan</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Santri Terdaftar */}
        <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-xs hover:border-emerald-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Total Santri Terdaftar</span>
            <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-stone-900">{totalSantri}</span>
            <span className="text-xs text-stone-500">Santri Banin &amp; Banat</span>
          </div>
          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
            <span>Sehat: <strong>{totalSantri - totalSakit}</strong></span>
            <button onClick={() => onNavigateTab('santri')} className="text-emerald-700 font-semibold hover:underline">
              Kelola &rarr;
            </button>
          </div>
        </div>

        {/* KPI 2: Sedang Sakit / Observasi */}
        <div className="bg-white rounded-xl p-5 border border-amber-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-700 uppercase tracking-wider">Santri Dalam Perawatan</span>
            <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Bed className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-amber-900">{totalSakit}</span>
            <span className="text-xs text-amber-700 font-medium">Santri Sakit</span>
          </div>
          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
            <span>Obs Poskestren: <strong>{santriObservasi}</strong></span>
            <span>Izin Asrama: <strong>{santriIzinAsrama}</strong></span>
            <span>Rujuk RS: <strong className="text-rose-600">{santriRujukan}</strong></span>
          </div>
        </div>

        {/* KPI 3: Kunjungan Periksa Hari Ini */}
        <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-xs hover:border-teal-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Kunjungan Hari Ini</span>
            <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center">
              <Activity className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-bold text-stone-900">{kunjunganHariIni}</span>
            <span className="text-xs text-teal-700 font-medium">Pasien Santri</span>
          </div>
          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
            <span>Total Rekam Medis: <strong>{rekamMedisList.length}</strong></span>
            <button onClick={() => onNavigateTab('rekam-medis')} className="text-teal-700 font-semibold hover:underline">
              Buku RM &rarr;
            </button>
          </div>
        </div>

        {/* KPI 4: Stok Obat Apotek */}
        <div className="bg-white rounded-xl p-5 border border-stone-200 shadow-xs hover:border-rose-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">Stok Obat Menipis</span>
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${obatMenipis.length > 0 ? 'bg-rose-50 text-rose-600' : 'bg-stone-50 text-stone-600'}`}>
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className={`text-2xl sm:text-3xl font-bold ${obatMenipis.length > 0 ? 'text-rose-600' : 'text-stone-900'}`}>
              {obatMenipis.length}
            </span>
            <span className="text-xs text-stone-500">item obat &le; batas minimum</span>
          </div>
          <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
            <span>Total Item: <strong>{obatList.length}</strong> jenis</span>
            <button onClick={() => onNavigateTab('apotek')} className="text-emerald-700 font-semibold hover:underline">
              Apotek &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* Disease Surveillance & Asrama Distribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: 5 Penyakit Terbanyak Santri Al Amien */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-stone-200 shadow-xs lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-stone-900 text-base">Tren Penyakit Terbanyak di Poskestren</h3>
              </div>
              <p className="text-xs text-stone-500 mt-0.5">Surveilans epidemiologi keluhan santri Ponpes Al-Amien Kediri</p>
            </div>
            <span className="text-xs font-medium px-2.5 py-1 bg-emerald-50 text-emerald-800 rounded-full border border-emerald-200">
              Periode September 2026
            </span>
          </div>

          <div className="space-y-3.5 mt-2">
            {sortedDiseases.map(([disease, count], idx) => {
              const percentage = Math.round((count / maxDiseaseCount) * 100);
              const isSkinOrScabies = disease.toLowerCase().includes('skabies');
              return (
                <div key={idx} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-stone-800 flex items-center gap-2">
                      <span className="w-4 h-4 rounded-full bg-stone-100 text-stone-600 flex items-center justify-center text-[10px]">
                        {idx + 1}
                      </span>
                      {disease}
                      {isSkinOrScabies && (
                        <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.2 rounded font-medium border border-amber-300">
                          Waspada Sanitasi Asrama
                        </span>
                      )}
                    </span>
                    <span className="text-emerald-800 font-bold">{count} Kasus ({percentage}%)</span>
                  </div>
                  <div className="w-full bg-stone-100 h-2.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        idx === 0 ? 'bg-emerald-600' : idx === 1 ? 'bg-teal-500' : 'bg-emerald-400'
                      }`}
                      style={{ width: `${Math.max(percentage, 8)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-5 p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 text-xs text-amber-900 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <strong>Catatan Sanitasi Pondok:</strong> Skabies dan Infeksi Pernapasan (ISPA) mendominasi keluhan santri. Disarankan pihak Pengasuhan Pondok mengadakan penjemuran kasur massal dan sterilisasi sprei setiap hari Jumat.
            </div>
          </div>
        </div>

        {/* Asrama Cluster & Active Duty Staff */}
        <div className="space-y-6">
          {/* Asrama Cluster */}
          <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-stone-900 text-sm">Klaster Santri Sakit per Asrama</h3>
              </div>
            </div>
            <p className="text-xs text-stone-500 mb-3">Monitoring asrama dengan santri sedang berobat</p>

            <div className="space-y-2.5 text-xs">
              {Object.keys(asramaCounts).length === 0 ? (
                <p className="text-stone-400 italic py-2 text-center">Semua asrama saat ini berstatus sehat.</p>
              ) : (
                Object.entries(asramaCounts).map(([asrama, count], i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-stone-50 border border-stone-100">
                    <span className="font-medium text-stone-800">{asrama}</span>
                    <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold text-xs">
                      {count} santri
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Petugas Poskestren Jaga */}
          <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Stethoscope className="w-5 h-5 text-teal-700" />
                <h3 className="font-bold text-stone-900 text-sm">Tenaga Medis Poskestren</h3>
              </div>
            </div>

            <div className="space-y-2.5">
              {petugasList.slice(0, 3).map((p) => (
                <div key={p.id} className="flex items-center justify-between p-2 rounded-lg bg-emerald-50/60 border border-emerald-100 text-xs">
                  <div>
                    <div className="font-semibold text-emerald-950">{p.nama}</div>
                    <div className="text-stone-500 text-[11px]">{p.peran}</div>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full font-medium text-[11px] ${
                    p.status_jaga === 'Bertugas Hari Ini' 
                      ? 'bg-emerald-200/80 text-emerald-900 font-semibold' 
                      : 'bg-stone-200 text-stone-700'
                  }`}>
                    {p.status_jaga}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Examinations Table */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-stone-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              <h3 className="font-bold text-stone-900 text-base">Pemeriksaan Santri Terbaru</h3>
            </div>
            <p className="text-xs text-stone-500">Daftar rekam medis santri yang baru diperiksa di Poskestren</p>
          </div>
          <button
            onClick={() => onNavigateTab('rekam-medis')}
            className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline"
          >
            Lihat Semua Rekam Medis <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-stone-700">
            <thead className="bg-stone-50 text-stone-500 uppercase tracking-wider font-semibold border-b border-stone-200">
              <tr>
                <th className="py-2.5 px-3">No. RM / Waktu</th>
                <th className="py-2.5 px-3">Santri &amp; Asrama</th>
                <th className="py-2.5 px-3">Keluhan &amp; TTV</th>
                <th className="py-2.5 px-3">Diagnosa Utama</th>
                <th className="py-2.5 px-3">Status Tindak Lanjut</th>
                <th className="py-2.5 px-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {rekamMedisList.slice(0, 4).map((rm) => {
                const s = santriList.find(item => item.id === rm.santri_id);
                return (
                  <tr key={rm.id} className="hover:bg-stone-50/80 transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-bold text-stone-900">{rm.nomor_rm}</div>
                      <div className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3 text-stone-400" />
                        {rm.tanggal_periksa}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-stone-900">{rm.santri_nama}</div>
                      <div className="text-[11px] text-stone-500">{rm.santri_asrama}</div>
                    </td>
                    <td className="py-3 px-3 max-w-xs">
                      <div className="line-clamp-1 font-medium text-stone-800">{rm.keluhan_utama}</div>
                      <div className="text-[11px] text-stone-500 mt-0.5">
                        TD: {rm.tekanan_darah || '-'} | Suhu: <strong className={rm.suhu_tubuh >= 38 ? 'text-rose-600' : 'text-stone-700'}>{rm.suhu_tubuh}°C</strong>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="font-medium text-emerald-950 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        {rm.diagnosa_primer}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full font-semibold text-[11px] ${
                        rm.status_penanganan === 'Rawat Jalan' ? 'bg-teal-100 text-teal-800' :
                        rm.status_penanganan === 'Observasi Poskestren' ? 'bg-amber-100 text-amber-800' :
                        rm.status_penanganan === 'Rujukan Rumah Sakit' ? 'bg-rose-100 text-rose-800 font-bold' :
                        'bg-stone-100 text-stone-800'
                      }`}>
                        {rm.status_penanganan}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      {s && (
                        <button
                          onClick={() => onSelectSantri(s)}
                          className="px-2.5 py-1 text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded border border-emerald-300 transition-colors"
                        >
                          Buku Kesehatan
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
