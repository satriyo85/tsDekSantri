import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  Calendar, 
  Download, 
  Printer, 
  FileSpreadsheet, 
  TrendingUp, 
  Users, 
  Pill, 
  Activity, 
  AlertCircle,
  Building,
  CheckCircle,
  Filter,
  Layers,
  ChevronRight,
  ShieldCheck,
  Stethoscope
} from 'lucide-react';
import { Santri, RekamMedis, Obat, PeriodeLaporan } from '../types';
import { printHtmlContent, downloadDocumentFile } from '../utils/printHelper';

interface LaporanViewProps {
  santriList: Santri[];
  rekamMedisList: RekamMedis[];
  obatList: Obat[];
}

export const LaporanView: React.FC<LaporanViewProps> = ({
  santriList,
  rekamMedisList,
  obatList,
}) => {
  // State for report type
  const [periode, setPeriode] = useState<PeriodeLaporan>('bulanan');
  
  // Specific filters
  const [selectedDate, setSelectedDate] = useState<string>('2026-09-19');
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-09');
  const [selectedTrimester, setSelectedTrimester] = useState<'Q1' | 'Q2' | 'Q3' | 'Q4'>('Q3'); // Q3 = Jul-Sep
  const [selectedSemester, setSelectedSemester] = useState<'S1' | 'S2'>('S1'); // S1 = Jul-Des (Ganjil), S2 = Jan-Jun (Genap)
  const [filterGender, setFilterGender] = useState<'All' | 'L' | 'P'>('All');

  // Filtered records based on period
  const filteredRecords = useMemo(() => {
    return rekamMedisList.filter(rm => {
      const recordDate = rm.tanggal_periksa.slice(0, 10); // YYYY-MM-DD
      const recordMonth = rm.tanggal_periksa.slice(0, 7); // YYYY-MM

      // Gender filter lookup
      if (filterGender !== 'All') {
        const santri = santriList.find(s => s.id === rm.santri_id || s.nis === rm.santri_nis);
        if (santri && santri.jenis_kelamin !== filterGender) return false;
      }

      if (periode === 'harian') {
        return recordDate === selectedDate;
      } else if (periode === 'bulanan') {
        return recordMonth === selectedMonth;
      } else if (periode === 'trimester') {
        const monthNum = parseInt(recordDate.slice(5, 7), 10);
        if (selectedTrimester === 'Q1') return monthNum >= 1 && monthNum <= 3;
        if (selectedTrimester === 'Q2') return monthNum >= 4 && monthNum <= 6;
        if (selectedTrimester === 'Q3') return monthNum >= 7 && monthNum <= 9;
        if (selectedTrimester === 'Q4') return monthNum >= 10 && monthNum <= 12;
      } else if (periode === 'semester') {
        const monthNum = parseInt(recordDate.slice(5, 7), 10);
        // S1: Semester Ganjil (Juli - Desember)
        if (selectedSemester === 'S1') return monthNum >= 7 && monthNum <= 12;
        // S2: Semester Genap (Januari - Juni)
        if (selectedSemester === 'S2') return monthNum >= 1 && monthNum <= 6;
      }
      return true;
    });
  }, [rekamMedisList, santriList, periode, selectedDate, selectedMonth, selectedTrimester, selectedSemester, filterGender]);

  // Aggregate Top 10 Morbidity (Diagnosa Terbanyak)
  const topDiagnoses = useMemo(() => {
    const counts: Record<string, { count: number; icd: string }> = {};
    filteredRecords.forEach(rm => {
      const key = rm.diagnosa_primer;
      if (!counts[key]) {
        counts[key] = { count: 0, icd: rm.kode_icd10 || '-' };
      }
      counts[key].count += 1;
    });

    return Object.entries(counts)
      .map(([name, data]) => ({ name, count: data.count, icd: data.icd }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [filteredRecords]);

  // Status handling counts
  const statusStats = useMemo(() => {
    const counts = {
      rawatJalan: 0,
      observasi: 0,
      istirahatAsrama: 0,
      izinPulang: 0,
      rujukan: 0,
    };
    filteredRecords.forEach(rm => {
      if (rm.status_penanganan === 'Rawat Jalan') counts.rawatJalan++;
      else if (rm.status_penanganan === 'Observasi Poskestren') counts.observasi++;
      else if (rm.status_penanganan === 'Istirahat di Asrama') counts.istirahatAsrama++;
      else if (rm.status_penanganan === 'Izin Pulang ke Rumah') counts.izinPulang++;
      else if (rm.status_penanganan === 'Rujukan Faskes') counts.rujukan++;
    });
    return counts;
  }, [filteredRecords]);

  // Medicines used in this period
  const medicinesUsed = useMemo(() => {
    const map: Record<string, { nama: string; totalQty: number; satuan: string }> = {};
    filteredRecords.forEach(rm => {
      rm.resep_obat?.forEach(med => {
        if (!map[med.nama_obat]) {
          map[med.nama_obat] = { nama: med.nama_obat, totalQty: 0, satuan: med.satuan };
        }
        map[med.nama_obat].totalQty += med.jumlah;
      });
    });
    return Object.values(map).sort((a, b) => b.totalQty - a.totalQty);
  }, [filteredRecords]);

  // Asrama breakdown
  const asramaDistribution = useMemo(() => {
    const map: Record<string, number> = {};
    filteredRecords.forEach(rm => {
      const asrama = rm.santri_asrama || 'Tidak Terdata';
      map[asrama] = (map[asrama] || 0) + 1;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [filteredRecords]);

  // Period label title
  const getPeriodTitle = () => {
    switch (periode) {
      case 'harian':
        return `Laporan Harian Poskestren (${selectedDate})`;
      case 'bulanan':
        const [year, month] = selectedMonth.split('-');
        const monthNames = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        return `Laporan Bulanan Poskestren - ${monthNames[parseInt(month, 10)]} ${year}`;
      case 'trimester':
        const qNames = {
          Q1: 'Triwulan I (Januari - Maret 2026)',
          Q2: 'Triwulan II (April - Juni 2026)',
          Q3: 'Triwulan III (Juli - September 2026)',
          Q4: 'Triwulan IV (Oktober - Desember 2026)'
        };
        return `Laporan Trimester (3 Bulanan) - ${qNames[selectedTrimester]}`;
      case 'semester':
        return selectedSemester === 'S1'
          ? 'Laporan 6 Bulanan (Semester Ganjil TP. 2026/2027 - Juli s/d Desember)'
          : 'Laporan 6 Bulanan (Semester Genap TP. 2025/2026 - Januari s/d Juni)';
    }
  };

  const generateLaporanHtml = () => {
    const periodTitle = getPeriodTitle();
    const todayStr = new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

    const diagnosesRows = topDiagnoses.map((d, i) => `
      <tr>
        <td style="text-align: center; width: 40px;">${i + 1}</td>
        <td><strong>${d.name}</strong></td>
        <td style="font-family: monospace; text-align: center; width: 90px;">${d.icd}</td>
        <td style="text-align: right; font-weight: bold; width: 70px;">${d.count}</td>
        <td style="text-align: right; width: 80px;">${filteredRecords.length > 0 ? ((d.count / filteredRecords.length) * 100).toFixed(1) : '0'}%</td>
      </tr>
    `).join('');

    const medRows = medicinesUsed.slice(0, 10).map((m, i) => `
      <tr>
        <td style="text-align: center; width: 40px;">${i + 1}</td>
        <td><strong>${m.nama}</strong></td>
        <td style="text-align: right; font-weight: bold; width: 80px;">${m.totalQty}</td>
        <td style="text-align: center; width: 80px;">${m.satuan}</td>
      </tr>
    `).join('');

    const recordsRows = filteredRecords.slice(0, 30).map((r, i) => `
      <tr>
        <td style="text-align: center; width: 35px;">${i + 1}</td>
        <td style="font-family: monospace; font-size: 8.5pt;">${r.nomor_rm}</td>
        <td style="white-space: nowrap; font-size: 8.5pt;">${r.tanggal_periksa}</td>
        <td><strong>${r.santri_nama}</strong><br><span style="font-size: 8pt; color: #57534e;">NIS: ${r.santri_nis} • ${r.santri_asrama}</span></td>
        <td>${r.keluhan_utama}</td>
        <td><strong>${r.diagnosa_primer}</strong></td>
        <td>${r.status_penanganan}</td>
      </tr>
    `).join('');

    return `
      <div class="header-kop">
        <div class="kop-yayasan">YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI</div>
        <div class="kop-poskestren">POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN</div>
        <div class="kop-alamat">Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129<br>Telp/WhatsApp: (0354) 682110 • Unit Layanan Kesehatan Primer Terpadu</div>
      </div>

      <div class="doc-header">
        <div class="doc-title">${periodTitle}</div>
        <div class="doc-nomor">Dokumen Resmi Pengelolaan Kesehatan Santri Berbasis IT DEK SANTRI</div>
      </div>

      <!-- Ringkasan Statistik Pelayanan -->
      <div class="content-box">
        <div style="font-weight: bold; margin-bottom: 8px; font-size: 10pt; color: #064e3b; border-bottom: 1px solid #d6d3d1; padding-bottom: 4px;">
          RINGKASAN STATISTIK PELAYANAN MEDIS
        </div>
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; font-size: 9pt;">
          <div>• Total Pemeriksaan: <strong>${filteredRecords.length} Santri</strong></div>
          <div>• Rawat Jalan Mandiri: <strong>${statusStats.rawatJalan} Kasus</strong></div>
          <div>• Observasi Rawat Inap: <strong>${statusStats.observasi} Santri</strong></div>
          <div>• Istirahat Asrama: <strong>${statusStats.istirahatAsrama} Santri</strong></div>
          <div>• Rujukan Faskes/RS: <strong>${statusStats.rujukan} Santri</strong></div>
          <div>• Izin Pulang ke Rumah: <strong>${statusStats.izinPulang} Santri</strong></div>
        </div>
      </div>

      <!-- 10 Besar Morbiditas -->
      <div style="margin-top: 14px;">
        <div style="font-weight: bold; font-size: 10pt; margin-bottom: 4px; color: #1c1917;">
          I. 10 BESAR MORBIDITAS (DIAGNOSA PENYAKIT TERBANYAK)
        </div>
        <table>
          <thead>
            <tr>
              <th>No</th>
              <th>Diagnosa Penyakit</th>
              <th style="text-align: center;">Kode ICD-10</th>
              <th style="text-align: right;">Jumlah</th>
              <th style="text-align: right;">Persentase</th>
            </tr>
          </thead>
          <tbody>
            ${diagnosesRows || '<tr><td colspan="5" style="text-align: center; color: #78716c;">Tidak ada data morbiditas pada periode ini.</td></tr>'}
          </tbody>
        </table>
      </div>

      <!-- Pemakaian Obat & Farmasi -->
      <div style="margin-top: 14px;">
        <div style="font-weight: bold; font-size: 10pt; margin-bottom: 4px; color: #1c1917;">
          II. REKAPITULASI PEMAKAIAN OBAT &amp; LOGISTIK FARMASI
        </div>
        <table>
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Obat / Sediaan Farmasi</th>
              <th style="text-align: right;">Jumlah Pemakaian</th>
              <th style="text-align: center;">Satuan</th>
            </tr>
          </thead>
          <tbody>
            ${medRows || '<tr><td colspan="4" style="text-align: center; color: #78716c;">Tidak ada pengeluaran obat pada periode ini.</td></tr>'}
          </tbody>
        </table>
      </div>

      <!-- Rincian Data Pasien Santri -->
      <div style="margin-top: 14px;">
        <div style="font-weight: bold; font-size: 10pt; margin-bottom: 4px; color: #1c1917;">
          III. DAFTAR REKAM MEDIS PELAYANAN SANTRI (SAMPLING ${filteredRecords.length > 30 ? '30 TERATAS DARI ' + filteredRecords.length : filteredRecords.length} DATA)
        </div>
        <table>
          <thead>
            <tr>
              <th>No</th>
              <th>No. RM</th>
              <th>Tanggal</th>
              <th>Santri &amp; Asrama</th>
              <th>Keluhan</th>
              <th>Diagnosa</th>
              <th>Tindakan</th>
            </tr>
          </thead>
          <tbody>
            ${recordsRows || '<tr><td colspan="7" style="text-align: center; color: #78716c;">Tidak ada riwayat rekam medis pada periode ini.</td></tr>'}
          </tbody>
        </table>
      </div>

      <!-- Rekomendasi -->
      <div class="content-box" style="margin-top: 14px; background-color: #f0fdf4; border-color: #bbf7d0;">
        <div style="font-weight: bold; color: #14532d; margin-bottom: 4px;">Rekomendasi Tindak Lanjut untuk Pengasuhan Santri &amp; Pengurus Asrama:</div>
        <div style="font-size: 8.5pt; line-height: 1.4; color: #166534;">
          1. <strong>Pencegahan Penyakit Kulit (Skabies)</strong>: Pelaksanaan jemur kasur serentak dan sanitasi kamar asrama.<br>
          2. <strong>Penyakit Saluran Pernapasan (ISPA)</strong>: Menjaga sirkulasi udara kamar asrama dan edukasi etika batuk.<br>
          3. <strong>Pencernaan (Gastritis/Dispepsia)</strong>: Pengawasan jadwal makan santri tepat waktu.
        </div>
      </div>

      <!-- Tanda Tangan -->
      <div class="signature-wrap">
        <div class="signature-box">
          <div>Mengetahui,<br><span class="font-bold">Pengasuh Pondok Pesantren Al-Amien</span></div>
          <div class="signature-space"></div>
          <div class="font-bold underline">KH. Moh. Anwar Manshur</div>
          <div style="font-size: 8pt; color: #57534e;">Pimpinan Yayasan Ponpes Al-Amien</div>
        </div>

        <div class="signature-box">
          <div>Kediri, ${todayStr}<br><span class="font-bold">Dokter Penanggung Jawab Poskestren</span></div>
          <div class="signature-space"></div>
          <div class="font-bold underline">dr. H. Ahmad Fauzi, M.Kes</div>
          <div style="font-size: 8pt; color: #57534e;">SIP: 503/412/SIP.D/2024</div>
        </div>
      </div>
    `;
  };

  const handlePrintLaporan = () => {
    printHtmlContent({
      title: getPeriodTitle(),
      bodyHtml: generateLaporanHtml(),
    });
  };

  const handleDownloadLaporan = () => {
    const filename = `Laporan_Kesehatan_${periode}_AlAmien_${new Date().toISOString().slice(0, 10)}`;
    downloadDocumentFile(filename, getPeriodTitle(), generateLaporanHtml());
  };

  const handleExportCSV = () => {
    const headers = ['No. RM', 'Tanggal', 'NIS', 'Nama Santri', 'Asrama', 'Diagnosa', 'Kode ICD-10', 'Tindakan', 'Status Penanganan', 'Petugas'];
    const rows = filteredRecords.map(r => [
      r.nomor_rm,
      r.tanggal_periksa,
      r.santri_nis,
      `"${r.santri_nama}"`,
      `"${r.santri_asrama}"`,
      `"${r.diagnosa_primer}"`,
      r.kode_icd10 || '',
      `"${r.tindakan_medis || ''}"`,
      r.status_penanganan,
      `"${r.petugas_pemeriksa}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `laporan_kesehatan_${periode}_alamien_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-800">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-stone-900">
                Laporan Kesehatan Santri Poskestren Al-Amien
              </h2>
              <p className="text-xs text-stone-500">
                Pusat data morbiditas santri, rekapitulasi penanganan medis, dan pemakaian logistik farmasi
              </p>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            title="Download Spreadsheet Excel / CSV"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            <span>Ekspor CSV</span>
          </button>
          <button
            onClick={handleDownloadLaporan}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            title="Unduh Dokumen Laporan Format PDF / HTML"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Unduh File</span>
          </button>
          <button
            onClick={handlePrintLaporan}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs shadow-sm transition-all cursor-pointer"
            title="Cetak langsung ke printer atau Simpan sebagai PDF"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak / Simpan PDF (Print)</span>
          </button>
        </div>
      </div>

      {/* Periode Navigation Bar (Harian, Bulanan, Trimester, 6 Bulanan) */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Tab Selection */}
        <div className="flex items-center bg-stone-100 p-1.5 rounded-xl gap-1 overflow-x-auto">
          <button
            onClick={() => setPeriode('harian')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              periode === 'harian'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            1. Laporan Harian
          </button>
          <button
            onClick={() => setPeriode('bulanan')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              periode === 'bulanan'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            2. Laporan Bulanan
          </button>
          <button
            onClick={() => setPeriode('trimester')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              periode === 'trimester'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            3. Laporan Trimester (3 Bulan)
          </button>
          <button
            onClick={() => setPeriode('semester')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              periode === 'semester'
                ? 'bg-white text-emerald-900 shadow-xs font-bold'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            4. Laporan 6 Bulanan (Semester)
          </button>
        </div>

        {/* Dynamic Period Filter Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Harian: Date Picker */}
          {periode === 'harian' && (
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-stone-500 font-medium">Tanggal:</span>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs bg-stone-50 font-mono focus:outline-emerald-600"
              />
            </div>
          )}

          {/* Bulanan: Month Picker */}
          {periode === 'bulanan' && (
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-stone-500 font-medium">Bulan:</span>
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs bg-stone-50 font-mono focus:outline-emerald-600"
              />
            </div>
          )}

          {/* Trimester: Select */}
          {periode === 'trimester' && (
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-stone-500 font-medium">Triwulan:</span>
              <select
                value={selectedTrimester}
                onChange={(e) => setSelectedTrimester(e.target.value as any)}
                className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs bg-stone-50 focus:outline-emerald-600 font-medium"
              >
                <option value="Q1">Triwulan I (Jan - Mar)</option>
                <option value="Q2">Triwulan II (Apr - Jun)</option>
                <option value="Q3">Triwulan III (Jul - Sep)</option>
                <option value="Q4">Triwulan IV (Okt - Des)</option>
              </select>
            </div>
          )}

          {/* 6 Bulanan: Semester Select */}
          {periode === 'semester' && (
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-stone-500 font-medium">Semester:</span>
              <select
                value={selectedSemester}
                onChange={(e) => setSelectedSemester(e.target.value as any)}
                className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs bg-stone-50 focus:outline-emerald-600 font-medium"
              >
                <option value="S1">Semester Ganjil (Juli - Desember 2026)</option>
                <option value="S2">Semester Genap (Januari - Juni 2026)</option>
              </select>
            </div>
          )}

          {/* Gender Filter */}
          <div className="flex items-center gap-1.5 text-xs border-l pl-3 border-stone-200">
            <span className="text-stone-500 font-medium">Santri:</span>
            <select
              value={filterGender}
              onChange={(e) => setFilterGender(e.target.value as any)}
              className="px-2 py-1.5 rounded-lg border border-stone-300 text-xs bg-stone-50 focus:outline-emerald-600"
            >
              <option value="All">Semua (Banin &amp; Banat)</option>
              <option value="L">Banin (Santri Putra)</option>
              <option value="P">Banat (Santri Putri)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards for Selected Period */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-medium">Total Kunjungan</span>
            <Activity className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-stone-900 mt-1">{filteredRecords.length}</div>
          <div className="text-[11px] text-stone-400 mt-0.5">pemeriksaan santri</div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-medium">Rawat Jalan</span>
            <CheckCircle className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-bold text-teal-700 mt-1">{statusStats.rawatJalan}</div>
          <div className="text-[11px] text-stone-400 mt-0.5">langsung kembali</div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-medium">Observasi Poskestren</span>
            <AlertCircle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-700 mt-1">{statusStats.observasi}</div>
          <div className="text-[11px] text-stone-400 mt-0.5">bed rest klinik</div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-medium">Istirahat Asrama</span>
            <Building className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-indigo-700 mt-1">{statusStats.istirahatAsrama}</div>
          <div className="text-[11px] text-stone-400 mt-0.5">izin tidak sekolah</div>
        </div>

        <div className="p-4 rounded-2xl bg-white border border-stone-200 shadow-xs col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-medium">Rujukan RS</span>
            <TrendingUp className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-bold text-rose-700 mt-1">{statusStats.rujukan}</div>
          <div className="text-[11px] text-stone-400 mt-0.5">RSUD / Faskes Luar</div>
        </div>
      </div>

      {/* Main Content: Printable Official Document Preview */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs p-6 sm:p-8 space-y-6">
        {/* Official Kop Surat */}
        <div className="text-center border-b-2 border-emerald-900 pb-4">
          <div className="font-serif font-bold text-base sm:text-lg text-emerald-950 uppercase tracking-wide">
            YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI
          </div>
          <div className="font-serif font-bold text-xl sm:text-2xl text-emerald-900 tracking-wider">
            POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN
          </div>
          <div className="text-xs text-stone-600 mt-1">
            Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129
          </div>
          <div className="text-[11px] text-stone-500">
            Unit Layanan Kesehatan Primer Terpadu Santri, Asatidz, dan Warga Pesantren
          </div>
        </div>

        {/* Document Title */}
        <div className="text-center space-y-1">
          <h3 className="font-bold text-base sm:text-lg uppercase tracking-wider underline text-stone-900">
            {getPeriodTitle()}
          </h3>
          <div className="text-xs text-stone-500 font-medium">
            Klasifikasi: Rekapitulasi Morbiditas Klinis &amp; Farmasi Poskestren Al-Amien
          </div>
        </div>

        {/* Section 1: 10 Penyakit Terbanyak (Top 10 Morbiditas Santri) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between border-b border-stone-200 pb-2">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-700" />
              <span>A. Pola 10 Besar Penyakit Santri (Morbiditas ICD-10)</span>
            </h4>
            <span className="text-[11px] text-stone-500">
              Total Kasus: <strong>{filteredRecords.length}</strong>
            </span>
          </div>

          {topDiagnoses.length === 0 ? (
            <div className="p-4 text-center text-xs text-stone-400 bg-stone-50 rounded-xl">
              Tidak ada data pemeriksaan klinis untuk periode yang dipilih.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left text-stone-700">
                <thead className="bg-stone-50 text-stone-500 font-semibold border-b border-stone-200">
                  <tr>
                    <th className="py-2.5 px-3 w-12 text-center">No</th>
                    <th className="py-2.5 px-3">Nama Diagnosa Medis</th>
                    <th className="py-2.5 px-3 w-28">Kode ICD-10</th>
                    <th className="py-2.5 px-3 w-28 text-center">Jumlah Kasus</th>
                    <th className="py-2.5 px-3 w-32 text-right">Persentase</th>
                    <th className="py-2.5 px-3 w-48">Proporsi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {topDiagnoses.map((item, idx) => {
                    const percentage = filteredRecords.length > 0 
                      ? Math.round((item.count / filteredRecords.length) * 100) 
                      : 0;
                    return (
                      <tr key={idx} className="hover:bg-stone-50/70">
                        <td className="py-2.5 px-3 text-center font-bold text-stone-400">{idx + 1}</td>
                        <td className="py-2.5 px-3 font-semibold text-stone-900">{item.name}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-emerald-800">{item.icd}</td>
                        <td className="py-2.5 px-3 text-center font-bold">{item.count} santri</td>
                        <td className="py-2.5 px-3 text-right font-medium">{percentage}%</td>
                        <td className="py-2.5 px-3">
                          <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                            <div 
                              className="bg-emerald-600 h-full rounded-full" 
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Section 2: Sebaran Santri Sakit per Asrama & Klaster */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {/* Asrama Breakdown */}
          <div className="space-y-3">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2 border-b border-stone-200 pb-2">
              <Building className="w-4 h-4 text-emerald-700" />
              <span>B. Sebaran Kasus per Asrama / Kamar</span>
            </h4>
            <div className="border border-stone-200 rounded-xl overflow-hidden divide-y divide-stone-100 text-xs">
              {asramaDistribution.length === 0 ? (
                <div className="p-3 text-stone-400 text-center">Nihil kasus</div>
              ) : (
                asramaDistribution.map(([asrama, count], i) => (
                  <div key={i} className="p-2.5 flex items-center justify-between hover:bg-stone-50">
                    <span className="font-medium text-stone-800">{asrama}</span>
                    <span className="px-2 py-0.5 rounded-full bg-stone-100 text-stone-700 font-bold font-mono text-[11px]">
                      {count} kasus
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Medicines Used */}
          <div className="space-y-3">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2 border-b border-stone-200 pb-2">
              <Pill className="w-4 h-4 text-emerald-700" />
              <span>C. Penggunaan Obat Apotek Poskestren</span>
            </h4>
            <div className="border border-stone-200 rounded-xl overflow-hidden divide-y divide-stone-100 text-xs max-h-56 overflow-y-auto">
              {medicinesUsed.length === 0 ? (
                <div className="p-3 text-stone-400 text-center">Belum ada obat yang dikeluarkan</div>
              ) : (
                medicinesUsed.map((med, i) => (
                  <div key={i} className="p-2.5 flex items-center justify-between hover:bg-stone-50">
                    <span className="font-medium text-stone-800">{med.nama}</span>
                    <span className="text-emerald-800 font-bold">
                      {med.totalQty} {med.satuan}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Section 3: Detailed Patient Examination Log */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between border-b border-stone-200 pb-2">
            <h4 className="font-bold text-stone-900 text-sm flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-emerald-700" />
              <span>D. Daftar Rincian Pasien Santri yang Diperiksa</span>
            </h4>
            <span className="text-xs text-stone-500">
              Menampilkan {filteredRecords.length} rekam medis
            </span>
          </div>

          <div className="overflow-x-auto border border-stone-200 rounded-xl">
            <table className="w-full text-xs text-left text-stone-700">
              <thead className="bg-stone-50 text-stone-500 font-semibold border-b border-stone-200">
                <tr>
                  <th className="py-2.5 px-3">No. RM &amp; Waktu</th>
                  <th className="py-2.5 px-3">Santri &amp; NIS</th>
                  <th className="py-2.5 px-3">Asrama</th>
                  <th className="py-2.5 px-3">Keluhan &amp; TTV</th>
                  <th className="py-2.5 px-3">Diagnosa</th>
                  <th className="py-2.5 px-3">Status Penanganan</th>
                  <th className="py-2.5 px-3">Pemeriksa</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredRecords.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-stone-400">
                      Tidak ada catatan medis santri pada rentang periode ini.
                    </td>
                  </tr>
                ) : (
                  filteredRecords.map(rm => (
                    <tr key={rm.id} className="hover:bg-stone-50/80">
                      <td className="py-2.5 px-3">
                        <div className="font-mono font-bold text-stone-900">{rm.nomor_rm}</div>
                        <div className="text-[10px] text-stone-400">{rm.tanggal_periksa}</div>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-bold text-stone-900">{rm.santri_nama}</div>
                        <div className="text-[10px] font-mono text-stone-400">{rm.santri_nis}</div>
                      </td>
                      <td className="py-2.5 px-3 text-stone-600">{rm.santri_asrama}</td>
                      <td className="py-2.5 px-3">
                        <div>{rm.keluhan_utama}</div>
                        <div className="text-[10px] text-stone-400 font-mono">
                          TD: {rm.tekanan_darah || '-'} • S: {rm.suhu_tubuh}°C
                        </div>
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-emerald-950">{rm.diagnosa_primer}</div>
                        {rm.kode_icd10 && (
                          <span className="text-[10px] font-mono text-emerald-800">ICD: {rm.kode_icd10}</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          rm.status_penanganan === 'Rawat Jalan' ? 'bg-teal-100 text-teal-800' :
                          rm.status_penanganan === 'Observasi Poskestren' ? 'bg-amber-100 text-amber-800' :
                          rm.status_penanganan === 'Rujukan Rumah Sakit' ? 'bg-rose-100 text-rose-800 font-bold' :
                          'bg-stone-100 text-stone-800'
                        }`}>
                          {rm.status_penanganan}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-stone-600 text-[11px]">{rm.petugas_pemeriksa}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 4: Catatan & Rekomendasi Medis untuk Kepengasuhan */}
        <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-200 text-xs text-stone-800 space-y-2">
          <h5 className="font-bold text-emerald-950 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>Rekomendasi Tindak Lanjut untuk Pengasuhan Santri &amp; Madrasah:</span>
          </h5>
          <ul className="list-disc list-inside space-y-1 text-[11px] text-stone-700 leading-relaxed">
            <li>
              <strong>Pencegahan Penyakit Kulit (Skabies)</strong>: Menginstruksikan pengurus asrama untuk menjadwalkan penjemuran kasur dan pencucian sprei secara serentak dengan air panas.
            </li>
            <li>
              <strong>Penyakit Saluran Pernapasan (ISPA)</strong>: Menjaga ventilasi kamar santri tetap terbuka di siang hari dan edukasi etika batuk/pemakaian masker.
            </li>
            <li>
              <strong>Kesehatan Pencernaan</strong>: Memastikan jadwal katering makan santri tepat waktu, terutama menjelang dan sesudah puasa sunnah Senin-Kamis.
            </li>
          </ul>
        </div>

        {/* Official Signatures */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-end gap-6 text-xs text-stone-800">
          <div className="text-center space-y-14">
            <div>
              Mengetahui,<br />
              <span className="font-bold">Pengasuh Pondok Pesantren Al-Amien Kediri</span>
            </div>
            <div>
              <div className="font-bold underline text-stone-900">KH. Moh. Anwar Manshur</div>
              <div className="text-[10px] text-stone-500">Pimpinan Yayasan Ponpes Al-Amien</div>
            </div>
          </div>

          <div className="text-center space-y-14">
            <div>
              Kediri, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}<br />
              <span className="font-bold">Dokter Penanggung Jawab Poskestren</span>
            </div>
            <div>
              <div className="font-bold underline text-stone-900">dr. H. Ahmad Fauzi, M.Kes</div>
              <div className="text-[10px] text-stone-500 font-mono">SIP: 503/412/SIP.D/2024</div>
            </div>
          </div>
        </div>

        {/* Bottom Print Action Bar */}
        <div className="no-print pt-6 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3 bg-stone-50/80 -mx-6 sm:-mx-8 -mb-6 sm:-mb-8 p-4 sm:p-5 rounded-b-2xl">
          <div className="text-xs text-stone-500">
            Laporan siap dicetak langsung pada kertas A4 atau disimpan ke format PDF.
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-stone-100 text-stone-700 border border-stone-200 font-semibold rounded-xl text-xs shadow-2xs transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              <span>Ekspor CSV</span>
            </button>
            <button
              onClick={handleDownloadLaporan}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Unduh File</span>
            </button>
            <button
              onClick={handlePrintLaporan}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs shadow-sm transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / Simpan PDF (Print)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
