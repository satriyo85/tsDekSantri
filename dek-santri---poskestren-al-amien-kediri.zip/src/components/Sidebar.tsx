import React from 'react';
import { 
  Activity, 
  Users, 
  FileText, 
  Pill, 
  Award, 
  Database, 
  BarChart3, 
  PlusCircle, 
  HeartHandshake, 
  Clock, 
  ShieldAlert,
  CalendarDays,
  ChevronRight,
  X
} from 'lucide-react';
import { NavTab, PetugasPoskestren } from '../types';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  onOpenNewPeriksa: () => void;
  petugasList: PetugasPoskestren[];
  santriSakitCount: number;
  totalSantri: number;
  totalRM: number;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewPeriksa,
  petugasList,
  santriSakitCount,
  totalSantri,
  totalRM,
  isMobileOpen,
  setIsMobileOpen,
}) => {
  const petugasJaga = petugasList.find(p => p.status_jaga === 'Bertugas Hari Ini');

  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'Dashboard & Pantauan',
      icon: Activity,
      badge: null,
    },
    {
      id: 'santri' as NavTab,
      label: 'Data Santri',
      sublabel: 'Banin & Banat',
      icon: Users,
      badge: `${totalSantri} Santri`,
    },
    {
      id: 'rekam-medis' as NavTab,
      label: 'Rekam Medis (EHR)',
      sublabel: 'Pemeriksaan Klinis',
      icon: FileText,
      badge: `${totalRM} RM`,
    },
    {
      id: 'apotek' as NavTab,
      label: 'Apotek & Stok Obat',
      sublabel: 'Farmasi Pesantren',
      icon: Pill,
      badge: null,
    },
    {
      id: 'surat' as NavTab,
      label: 'Surat & Informed Consent',
      sublabel: 'Izin, Rujukan & Consent Minor',
      icon: Award,
      badge: 'Consent',
      badgeColor: 'bg-emerald-800 text-emerald-200 border border-emerald-700',
    },
    {
      id: 'laporan' as NavTab,
      label: 'Laporan Kesehatan',
      sublabel: 'Harian, Bulanan, Triwulan, 6 Bln',
      icon: BarChart3,
      badge: 'Lengkap',
      badgeColor: 'bg-amber-500/30 text-amber-300 border border-amber-500/40',
    },
    {
      id: 'laravel' as NavTab,
      label: 'Database Laravel',
      sublabel: 'Skema, Migrasi & Model',
      icon: Database,
      badge: 'MySQL',
      badgeColor: 'bg-emerald-800 text-emerald-200 border border-emerald-700',
    },
  ];

  const handleSelectNav = (tab: NavTab) => {
    setActiveTab(tab);
    setIsMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div 
          onClick={() => setIsMobileOpen(false)}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-72 bg-emerald-950 text-white flex flex-col border-r border-emerald-900/80 shadow-2xl transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-emerald-900/80 bg-emerald-950">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 p-0.5 shadow-md flex items-center justify-center shrink-0 border border-emerald-400/40">
                <HeartHandshake className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="font-extrabold text-base tracking-wide text-white font-sans">
                    DEK SANTRI
                  </h1>
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-400 text-stone-950 uppercase tracking-tight">
                    v2.0
                  </span>
                </div>
                <p className="text-[11px] text-emerald-300/80 font-medium leading-tight">
                  Poskestren Al-Amien Kediri
                </p>
              </div>
            </div>

            {/* Mobile Close Button */}
            <button
              onClick={() => setIsMobileOpen(false)}
              className="lg:hidden p-1.5 text-emerald-300 hover:text-white rounded-lg hover:bg-emerald-900"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Subtitle tag */}
          <div className="mt-3 text-[10px] text-emerald-400/90 bg-emerald-900/60 px-2.5 py-1.5 rounded-lg border border-emerald-800/60 leading-tight">
            Digitalisasi Pengelolaan Data &amp; Riwayat Kesehatan Santri Berbasis TI
          </div>
        </div>

        {/* Quick Action Button: Periksa Santri */}
        <div className="p-4 border-b border-emerald-900/50">
          <button
            onClick={() => {
              onOpenNewPeriksa();
              setIsMobileOpen(false);
            }}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-stone-950 font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer transform active:scale-98"
          >
            <PlusCircle className="w-4 h-4" />
            <span>+ Periksa Santri Baru</span>
          </button>
        </div>

        {/* Navigation List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5 no-scrollbar">
          <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-400/70 px-3 pb-1">
            Menu Utama
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelectNav(item.id)}
                className={`w-full flex items-center justify-between p-3 rounded-xl text-xs transition-all cursor-pointer text-left ${
                  isActive
                    ? 'bg-gradient-to-r from-emerald-800/90 to-emerald-800/50 text-white font-bold shadow-xs border border-emerald-700/80 pl-3.5'
                    : 'text-emerald-200/80 hover:bg-emerald-900/60 hover:text-white border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-1.5 rounded-lg ${isActive ? 'bg-emerald-600 text-white' : 'bg-emerald-900/70 text-emerald-300'}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="leading-tight">{item.label}</div>
                    {item.sublabel && (
                      <div className="text-[10px] text-emerald-400/70 font-normal">
                        {item.sublabel}
                      </div>
                    )}
                  </div>
                </div>

                {item.badge && (
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold shrink-0 ${
                    item.badgeColor || 'bg-emerald-900 text-emerald-200 border border-emerald-700/60'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Duty Doctor & Emergency Alert Area */}
        <div className="p-4 border-t border-emerald-900/80 bg-emerald-950/90 space-y-2.5 text-xs">
          {/* Petugas Jaga */}
          <div className="bg-emerald-900/50 rounded-xl p-2.5 border border-emerald-800/60 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <div>
                <div className="text-[10px] text-emerald-400 font-medium">Petugas Medis Jaga:</div>
                <div className="font-semibold text-emerald-100 text-[11px] truncate max-w-[150px]">
                  {petugasJaga?.nama || 'dr. H. Ahmad Fauzi'}
                </div>
              </div>
            </div>
            <span className="text-[9px] bg-emerald-800 px-1.5 py-0.5 rounded text-emerald-200">
              Shift Pagi
            </span>
          </div>

          {/* Santri Sakit Alert */}
          {santriSakitCount > 0 ? (
            <div className="bg-rose-950/60 border border-rose-800/60 p-2.5 rounded-xl flex items-center gap-2 text-rose-200">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
              <div className="text-[11px] leading-tight">
                <strong>{santriSakitCount} santri</strong> dalam perawatan / observasi
              </div>
            </div>
          ) : (
            <div className="text-[10px] text-emerald-400/80 text-center">
              Alhamdulillah kondisi santri sehat &amp; terkendali
            </div>
          )}

          {/* Location footnote */}
          <div className="text-[10px] text-emerald-500 text-center leading-tight">
            Ngasinan, Rejomulyo, Kota Kediri • (0354) 682110
          </div>
        </div>
      </aside>
    </>
  );
};
