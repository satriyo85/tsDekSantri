import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Filter, 
  Calendar, 
  Clock, 
  HeartPulse, 
  Pill, 
  Eye, 
  Printer, 
  Download,
  PlusCircle
} from 'lucide-react';
import { RekamMedis, Santri } from '../types';
import { printHtmlContent, downloadDocumentFile } from '../utils/printHelper';

interface RekamMedisListProps {
  rekamMedisList: RekamMedis[];
  santriList: Santri[];
  onOpenNewPeriksa: () => void;
  onSelectSantri: (santri: Santri) => void;
}

export const RekamMedisList: React.FC<RekamMedisListProps> = ({
  rekamMedisList,
  santriList,
  onOpenNewPeriksa,
  onSelectSantri,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [selectedRM, setSelectedRM] = useState<RekamMedis | null>(null);

  const filteredRM = rekamMedisList.filter((rm) => {
    const q = searchQuery.toLowerCase();
    const matchSearch =
      rm.nomor_rm.toLowerCase().includes(q) ||
      rm.santri_nama.toLowerCase().includes(q) ||
      rm.santri_nis.toLowerCase().includes(q) ||
      rm.diagnosa_primer.toLowerCase().includes(q) ||
      rm.santri_asrama.toLowerCase().includes(q);

    const matchStatus = filterStatus === 'All' || rm.status_penanganan === filterStatus;

    return matchSearch && matchStatus;
  });

  const generateLembarRMHtml = (rm: RekamMedis) => {
    const medsList = rm.resep_obat && rm.resep_obat.length > 0
      ? rm.resep_obat.map(m => `<li><strong>${m.nama_obat}</strong> (${m.jumlah} ${m.satuan}) - <em>${m.aturan_pakai}</em></li>`).join('')
      : '<li><em>Tidak diberikan obat</em></li>';

    return `
      <div class="header-kop">
        <div class="kop-yayasan">YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI</div>
        <div class="kop-poskestren">POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN</div>
        <div class="kop-alamat">Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129<br>Telp/WhatsApp: (0354) 682110 • Sistem Rekam Medis Elektronik DEK SANTRI</div>
      </div>

      <div class="doc-header">
        <div class="doc-title">LEMBAR PEMERIKSAAN REKAM MEDIS RAWAT JALAN</div>
        <div class="doc-nomor">Nomor RM: ${rm.nomor_rm}</div>
      </div>

      <div class="content-box">
        <div class="grid-row"><span class="grid-label">Nama Lengkap Pasien</span><span class="grid-value">: <strong>${rm.santri_nama}</strong></span></div>
        <div class="grid-row"><span class="grid-label">Nomor Induk Santri (NIS)</span><span class="grid-value">: ${rm.santri_nis}</span></div>
        <div class="grid-row"><span class="grid-label">Komplek Asrama</span><span class="grid-value">: ${rm.santri_asrama}</span></div>
        <div class="grid-row"><span class="grid-label">Waktu Pemeriksaan</span><span class="grid-value">: ${rm.tanggal_periksa}</span></div>
        <div class="grid-row"><span class="grid-label">Status Penanganan</span><span class="grid-value">: <strong>${rm.status_penanganan}</strong></span></div>
      </div>

      <div style="margin-top: 10px;">
        <div style="font-weight: bold; margin-bottom: 4px;">Tanda-Tanda Vital (TTV) &amp; Antropometri:</div>
        <table>
          <thead>
            <tr>
              <th>Tekanan Darah</th>
              <th>Suhu Tubuh</th>
              <th>Denyut Nadi</th>
              <th>Laju Pernapasan</th>
              <th>Berat Badan</th>
              <th>Tinggi Badan</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>${rm.tekanan_darah || '-'}</td>
              <td>${rm.suhu_tubuh ? rm.suhu_tubuh + ' °C' : '-'}</td>
              <td>${rm.nadi ? rm.nadi + ' bpm' : '-'}</td>
              <td>${rm.laju_napas ? rm.laju_napas + ' x/menit' : '-'}</td>
              <td>${rm.berat_badan ? rm.berat_badan + ' kg' : '-'}</td>
              <td>${rm.tinggi_badan ? rm.tinggi_badan + ' cm' : '-'}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="content-box" style="margin-top: 10px;">
        <div class="grid-row"><span class="grid-label">Keluhan / Anamnesa</span><span class="grid-value">: ${rm.keluhan_utama}</span></div>
        <div class="grid-row"><span class="grid-label">Diagnosa Medis</span><span class="grid-value">: <strong>${rm.diagnosa_primer}</strong> ${rm.kode_icd10 ? `(Kode ICD-10: ${rm.kode_icd10})` : ''}</span></div>
        ${rm.tindakan_medis ? `<div class="grid-row"><span class="grid-label">Tindakan Klinis</span><span class="grid-value">: ${rm.tindakan_medis}</span></div>` : ''}
      </div>

      <div style="margin-top: 10px; padding: 10px 14px; border: 1px solid #d6d3d1; background: #fafaf9; border-radius: 6px;">
        <div style="font-weight: bold; margin-bottom: 5px;">Resep &amp; Logistik Farmasi yang Diberikan:</div>
        <ul style="margin: 0; padding-left: 20px;">
          ${medsList}
        </ul>
      </div>

      <div class="signature-wrap">
        <div style="font-size: 8.5pt; color: #57534e;">
          *Catatan:<br>
          Lembar rekam medis ini disimpan sebagai arsip rekam kesehatan resmi santri di Poskestren Al-Amien.
        </div>
        <div class="signature-box">
          <div>Kediri, ${rm.tanggal_periksa.slice(0, 10)}<br><span class="font-bold">Tenaga Medis Pemeriksa</span></div>
          <div class="signature-space"></div>
          <div class="font-bold underline">${rm.petugas_pemeriksa}</div>
          <div style="font-size: 8.5pt; color: #57534e;">Poskestren Ponpes Al-Amien Kediri</div>
        </div>
      </div>
    `;
  };

  const handlePrintRM = (rm: RekamMedis) => {
    printHtmlContent({
      title: `Rekam Medis - ${rm.santri_nama} (${rm.nomor_rm})`,
      bodyHtml: generateLembarRMHtml(rm),
    });
  };

  const handleDownloadRM = (rm: RekamMedis) => {
    const safeRm = rm.nomor_rm.replace(/[^a-zA-Z0-9]/g, '_');
    downloadDocumentFile(
      `Rekam_Medis_${rm.santri_nis}_${safeRm}`,
      `Rekam Medis - ${rm.santri_nama}`,
      generateLembarRMHtml(rm)
    );
  };

  const generateRekapTableHtml = () => {
    const rows = filteredRM.map((r, i) => `
      <tr>
        <td style="text-align: center;">${i + 1}</td>
        <td style="font-family: monospace;">${r.nomor_rm}</td>
        <td>${r.tanggal_periksa}</td>
        <td><strong>${r.santri_nama}</strong> (${r.santri_nis})</td>
        <td>${r.santri_asrama}</td>
        <td>${r.keluhan_utama}</td>
        <td><strong>${r.diagnosa_primer}</strong></td>
        <td>${r.status_penanganan}</td>
        <td>${r.petugas_pemeriksa}</td>
      </tr>
    `).join('');

    return `
      <div class="header-kop">
        <div class="kop-yayasan">YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI</div>
        <div class="kop-poskestren">POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN</div>
        <div class="kop-alamat">Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129</div>
      </div>
      <div class="doc-header">
        <div class="doc-title">BUKU REGISTRASI &amp; REKAPITULASI REKAM MEDIS SANTRI</div>
        <div class="doc-nomor">Total: ${filteredRM.length} Catatan Pemeriksaan</div>
      </div>
      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>No. RM</th>
            <th>Tanggal</th>
            <th>Santri</th>
            <th>Asrama</th>
            <th>Keluhan</th>
            <th>Diagnosa</th>
            <th>Status</th>
            <th>Pemeriksa</th>
          </tr>
        </thead>
        <tbody>
          ${rows || '<tr><td colspan="9" style="text-align: center;">Tidak ada data rekam medis.</td></tr>'}
        </tbody>
      </table>
    `;
  };

  const handlePrintRekapRM = () => {
    printHtmlContent({
      title: 'Rekapitulasi Rekam Medis Santri Al-Amien',
      bodyHtml: generateRekapTableHtml(),
      orientation: 'landscape',
    });
  };

  const exportCSV = () => {
    const headers = ['Nomor RM', 'Tanggal', 'NIS', 'Nama Santri', 'Asrama', 'Keluhan', 'Diagnosa', 'ICD-10', 'Tensi', 'Suhu', 'Status Penanganan'];
    const rows = filteredRM.map(r => [
      r.nomor_rm,
      r.tanggal_periksa,
      r.santri_nis,
      `"${r.santri_nama}"`,
      `"${r.santri_asrama}"`,
      `"${r.keluhan_utama.replace(/"/g, '""')}"`,
      `"${r.diagnosa_primer}"`,
      r.kode_icd10 || '',
      r.tekanan_darah || '',
      r.suhu_tubuh,
      r.status_penanganan
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `rekam_medis_santri_al_amien_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-700" />
            <h2 className="text-lg sm:text-xl font-bold text-stone-900">
              Buku Registrasi Rekam Medis (EHR) Poskestren
            </h2>
          </div>
          <p className="text-xs text-stone-500 mt-0.5">
            Arsip seluruh pemeriksaan klinis santri, tanda vital, diagnosa, dan riwayat pemberian obat
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={exportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            title="Download Spreadsheet Excel / CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>
          <button
            onClick={handlePrintRekapRM}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-200 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            title="Cetak Rekapitulasi Data Rekam Medis"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-700" />
            <span>Cetak Rekap RM</span>
          </button>
          <button
            id="btn-rm-periksa-baru"
            onClick={onOpenNewPeriksa}
            className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-sm transition-all cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Pemeriksaan Baru</span>
          </button>
        </div>
      </div>

      {/* Filter bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="w-full sm:w-80 relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari No. RM, Santri, Diagnosa..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 bg-stone-50/50"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="py-2 px-3 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 bg-stone-50/50"
          >
            <option value="All">Semua Status Penanganan</option>
            <option value="Rawat Jalan">Rawat Jalan</option>
            <option value="Observasi Poskestren">Observasi Poskestren</option>
            <option value="Istirahat di Asrama">Istirahat di Asrama</option>
            <option value="Izin Pulang ke Rumah">Izin Pulang ke Rumah</option>
            <option value="Rujukan Rumah Sakit">Rujukan Rumah Sakit/Faskes</option>
          </select>

          <span className="text-xs text-stone-500 whitespace-nowrap">
            Total: <strong>{filteredRM.length}</strong> RM
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-stone-700">
            <thead className="bg-stone-50 text-stone-500 uppercase tracking-wider font-semibold border-b border-stone-200">
              <tr>
                <th className="py-3 px-4">No. Rekam Medis</th>
                <th className="py-3 px-4">Santri &amp; Asrama</th>
                <th className="py-3 px-4">Keluhan &amp; TTV</th>
                <th className="py-3 px-4">Diagnosa Medis (ICD-10)</th>
                <th className="py-3 px-4">Obat Diberikan</th>
                <th className="py-3 px-4">Tindak Lanjut</th>
                <th className="py-3 px-4 text-right">Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredRM.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-stone-400">
                    Tidak ada data rekam medis yang sesuai.
                  </td>
                </tr>
              ) : (
                filteredRM.map((rm) => (
                  <tr key={rm.id} className="hover:bg-stone-50/80 transition-colors">
                    {/* RM & Date */}
                    <td className="py-3 px-4">
                      <div className="font-mono font-bold text-stone-900">{rm.nomor_rm}</div>
                      <div className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3 text-stone-400" />
                        {rm.tanggal_periksa}
                      </div>
                      <div className="text-[10px] text-stone-400 mt-0.5">{rm.petugas_pemeriksa}</div>
                    </td>

                    {/* Santri */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-stone-900">{rm.santri_nama}</div>
                      <div className="text-[11px] text-stone-500 font-mono">NIS: {rm.santri_nis}</div>
                      <div className="text-[11px] text-stone-400">{rm.santri_asrama}</div>
                    </td>

                    {/* Complaint & Vitals */}
                    <td className="py-3 px-4 max-w-xs">
                      <div className="line-clamp-2 text-stone-800">{rm.keluhan_utama}</div>
                      <div className="text-[11px] text-stone-500 mt-1 flex flex-wrap gap-1.5 font-medium">
                        <span className="bg-stone-100 px-1.5 py-0.5 rounded">TD: {rm.tekanan_darah || '-'}</span>
                        <span className={`px-1.5 py-0.5 rounded ${rm.suhu_tubuh >= 38 ? 'bg-rose-100 text-rose-800 font-bold' : 'bg-stone-100'}`}>
                          S: {rm.suhu_tubuh}°C
                        </span>
                        <span className="bg-stone-100 px-1.5 py-0.5 rounded">N: {rm.nadi || '-'}</span>
                      </div>
                    </td>

                    {/* Diagnosis */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-emerald-950">{rm.diagnosa_primer}</div>
                      {rm.kode_icd10 && (
                        <span className="inline-block mt-1 font-mono text-[10px] bg-emerald-100 text-emerald-900 px-1.5 py-0.2 rounded font-semibold">
                          ICD: {rm.kode_icd10}
                        </span>
                      )}
                    </td>

                    {/* Prescriptions */}
                    <td className="py-3 px-4">
                      {rm.resep_obat && rm.resep_obat.length > 0 ? (
                        <div className="space-y-1">
                          {rm.resep_obat.map((med, idx) => (
                            <div key={idx} className="text-[11px] text-stone-700 line-clamp-1">
                              • <strong>{med.nama_obat}</strong> ({med.jumlah} {med.satuan})
                            </div>
                          ))}
                        </div>
                      ) : (
                        <span className="text-stone-400 italic text-[11px]">- Tanpa Obat -</span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4">
                      <span className={`px-2.5 py-1 rounded-full font-semibold text-[11px] inline-block ${
                        rm.status_penanganan === 'Rawat Jalan' ? 'bg-teal-100 text-teal-800' :
                        rm.status_penanganan === 'Observasi Poskestren' ? 'bg-amber-100 text-amber-800' :
                        rm.status_penanganan === 'Rujukan Rumah Sakit' ? 'bg-rose-100 text-rose-800 font-bold' :
                        'bg-stone-100 text-stone-800'
                      }`}>
                        {rm.status_penanganan}
                      </span>
                    </td>

                    {/* Action */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handlePrintRM(rm)}
                          className="p-1.5 text-stone-600 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg border border-stone-200 transition-colors cursor-pointer"
                          title="Cetak Langsung / Simpan PDF Lembar RM"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setSelectedRM(rm)}
                          className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-lg border border-emerald-300 transition-colors cursor-pointer"
                          title="Lihat Detail Pemeriksaan"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedRM && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto border border-stone-200 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <span>Lembar Catatan Rekam Medis: {selectedRM.nomor_rm}</span>
                </h3>
                <p className="text-[11px] text-stone-500">Poskestren Al Amien Kediri • {selectedRM.tanggal_periksa}</p>
              </div>
              <button
                onClick={() => setSelectedRM(null)}
                className="w-8 h-8 flex items-center justify-center rounded-xl bg-stone-100 text-stone-600 hover:bg-stone-200 font-bold"
              >
                ✕
              </button>
            </div>

            {/* Santri Info */}
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 grid grid-cols-2 sm:grid-cols-3 gap-2">
              <div>
                <span className="text-stone-400">Nama Santri:</span>
                <div className="font-bold text-stone-900">{selectedRM.santri_nama}</div>
              </div>
              <div>
                <span className="text-stone-400">Nomor Induk (NIS):</span>
                <div className="font-mono font-medium text-stone-800">{selectedRM.santri_nis}</div>
              </div>
              <div>
                <span className="text-stone-400">Asrama / Kamar:</span>
                <div className="font-medium text-stone-800">{selectedRM.santri_asrama}</div>
              </div>
            </div>

            {/* Vitals */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 bg-emerald-50/50 p-3 rounded-xl border border-emerald-200 text-center">
              <div>
                <span className="text-stone-500 text-[10px]">Tekanan Darah</span>
                <div className="font-bold text-stone-800">{selectedRM.tekanan_darah || '-'}</div>
              </div>
              <div>
                <span className="text-stone-500 text-[10px]">Suhu Tubuh</span>
                <div className="font-bold text-stone-800">{selectedRM.suhu_tubuh} °C</div>
              </div>
              <div>
                <span className="text-stone-500 text-[10px]">Nadi</span>
                <div className="font-bold text-stone-800">{selectedRM.nadi || '-'} x/m</div>
              </div>
              <div>
                <span className="text-stone-500 text-[10px]">Laju Napas</span>
                <div className="font-bold text-stone-800">{selectedRM.laju_napas || '-'} x/m</div>
              </div>
              <div>
                <span className="text-stone-500 text-[10px]">Berat Badan</span>
                <div className="font-bold text-stone-800">{selectedRM.berat_badan || '-'} kg</div>
              </div>
              <div>
                <span className="text-stone-500 text-[10px]">Tinggi Badan</span>
                <div className="font-bold text-stone-800">{selectedRM.tinggi_badan || '-'} cm</div>
              </div>
            </div>

            {/* Clinical Content */}
            <div className="space-y-2">
              <div>
                <strong className="text-stone-700">Keluhan / Anamnesa:</strong>
                <p className="p-2.5 bg-stone-50 rounded-lg text-stone-800 mt-1">{selectedRM.keluhan_utama}</p>
              </div>

              <div>
                <strong className="text-stone-700">Diagnosa Medis:</strong>
                <div className="p-2.5 bg-emerald-50 rounded-lg text-emerald-950 font-semibold mt-1">
                  {selectedRM.diagnosa_primer} {selectedRM.kode_icd10 ? `(${selectedRM.kode_icd10})` : ''}
                </div>
              </div>

              {selectedRM.tindakan_medis && (
                <div>
                  <strong className="text-stone-700">Tindakan Klinis:</strong>
                  <p className="p-2.5 bg-stone-50 rounded-lg text-stone-800 mt-1">{selectedRM.tindakan_medis}</p>
                </div>
              )}

              {/* Prescribed medicines */}
              {selectedRM.resep_obat && selectedRM.resep_obat.length > 0 && (
                <div>
                  <strong className="text-stone-700">Resep Obat yang Diberikan:</strong>
                  <div className="mt-1 border border-stone-200 rounded-lg divide-y divide-stone-100 overflow-hidden">
                    {selectedRM.resep_obat.map((item, i) => (
                      <div key={i} className="p-2.5 flex items-center justify-between">
                        <div>
                          <span className="font-bold text-stone-900">{item.nama_obat}</span>
                          <span className="ml-2 text-stone-500 font-mono">({item.jumlah} {item.satuan})</span>
                        </div>
                        <span className="italic text-stone-600 bg-stone-100 px-2 py-0.5 rounded">{item.aturan_pakai}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-4 border-t border-stone-200">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handlePrintRM(selectedRM)}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                  title="Cetak langsung ke printer atau Simpan sebagai PDF"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak / Simpan PDF (Print)</span>
                </button>
                <button
                  onClick={() => handleDownloadRM(selectedRM)}
                  className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                  title="Unduh Berkas Rekam Medis"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh File</span>
                </button>
              </div>
              <button
                onClick={() => setSelectedRM(null)}
                className="px-5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
