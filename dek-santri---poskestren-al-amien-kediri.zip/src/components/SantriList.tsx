import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Filter, 
  UserPlus, 
  ShieldAlert, 
  HeartPulse, 
  Eye, 
  Edit, 
  Trash2, 
  Phone, 
  MapPin, 
  Droplet,
  CheckCircle2,
  Bed,
  AlertCircle,
  Printer,
  Download
} from 'lucide-react';
import { Santri, Gender, StatusSantri } from '../types';
import { asramaList } from '../data/mockData';
import { printHtmlContent, downloadDocumentFile } from '../utils/printHelper';

interface SantriListProps {
  santriList: Santri[];
  onSelectSantri: (santri: Santri) => void;
  onPeriksaSantri: (santri: Santri) => void;
  onSaveSantri: (santri: Santri) => void;
  onDeleteSantri: (id: string) => void;
}

export const SantriList: React.FC<SantriListProps> = ({
  santriList,
  onSelectSantri,
  onPeriksaSantri,
  onSaveSantri,
  onDeleteSantri,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterGender, setFilterGender] = useState<'All' | Gender>('All');
  const [filterAsrama, setFilterAsrama] = useState('Semua Asrama');
  const [filterStatus, setFilterStatus] = useState<'All' | StatusSantri>('All');
  
  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSantri, setEditingSantri] = useState<Santri | null>(null);

  // Form fields
  const [formData, setFormData] = useState<Partial<Santri>>({
    nis: '',
    nama_lengkap: '',
    jenis_kelamin: 'L',
    jenjang_pendidikan: 'MA Al Amien',
    kelas: '',
    asrama_komplek: 'Asrama Sunan Giri (Putra)',
    kamar: '',
    tempat_lahir: '',
    tanggal_lahir: '',
    golongan_darah: 'O',
    nama_wali: '',
    telepon_wali: '',
    alamat_asal: '',
    riwayat_alergi: '',
    riwayat_penyakit_kronis: '',
    status_kesehatan: 'Aktif',
  });

  const handleOpenAdd = () => {
    setEditingSantri(null);
    setFormData({
      nis: `2026.01.${Math.floor(1000 + Math.random() * 9000)}`,
      nama_lengkap: '',
      jenis_kelamin: 'L',
      jenjang_pendidikan: 'MA Al Amien',
      kelas: '',
      asrama_komplek: 'Asrama Sunan Giri (Putra)',
      kamar: '',
      tempat_lahir: 'Kediri',
      tanggal_lahir: '2009-01-01',
      golongan_darah: 'O',
      nama_wali: '',
      telepon_wali: '',
      alamat_asal: '',
      riwayat_alergi: 'Tidak Ada',
      riwayat_penyakit_kronis: 'Tidak Ada',
      status_kesehatan: 'Aktif',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (s: Santri) => {
    setEditingSantri(s);
    setFormData({ ...s });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama_lengkap || !formData.nis) return;

    const savedItem: Santri = {
      id: editingSantri ? editingSantri.id : `snt-${Date.now()}`,
      nis: formData.nis || '',
      nama_lengkap: formData.nama_lengkap || '',
      jenis_kelamin: (formData.jenis_kelamin as Gender) || 'L',
      jenjang_pendidikan: formData.jenjang_pendidikan as any || 'MA Al Amien',
      kelas: formData.kelas || 'X IPA',
      asrama_komplek: formData.asrama_komplek || 'Asrama Sunan Giri (Putra)',
      kamar: formData.kamar || 'Kamar A-01',
      tempat_lahir: formData.tempat_lahir || 'Kediri',
      tanggal_lahir: formData.tanggal_lahir || '2008-01-01',
      golongan_darah: formData.golongan_darah as any || '-',
      nama_wali: formData.nama_wali || '-',
      telepon_wali: formData.telepon_wali || '-',
      alamat_asal: formData.alamat_asal || '-',
      riwayat_alergi: formData.riwayat_alergi || 'Tidak Ada',
      riwayat_penyakit_kronis: formData.riwayat_penyakit_kronis || 'Tidak Ada',
      status_kesehatan: formData.status_kesehatan as StatusSantri || 'Aktif',
      created_at: editingSantri ? editingSantri.created_at : new Date().toISOString().replace('T', ' ').slice(0, 16),
      updated_at: new Date().toISOString().replace('T', ' ').slice(0, 16),
    };

    onSaveSantri(savedItem);
    setIsModalOpen(false);
  };

  // Filter logic
  const filteredSantri = santriList.filter((s) => {
    const q = searchQuery.toLowerCase();
    const matchSearch =
      s.nama_lengkap.toLowerCase().includes(q) ||
      s.nis.toLowerCase().includes(q) ||
      s.kamar.toLowerCase().includes(q) ||
      s.kelas.toLowerCase().includes(q) ||
      s.asrama_komplek.toLowerCase().includes(q);

    const matchGender = filterGender === 'All' || s.jenis_kelamin === filterGender;
    const matchAsrama = filterAsrama === 'Semua Asrama' || s.asrama_komplek === filterAsrama;
    const matchStatus = filterStatus === 'All' || s.status_kesehatan === filterStatus;

    return matchSearch && matchGender && matchAsrama && matchStatus;
  });

  const generateSantriListHtml = () => {
    const rows = filteredSantri.map((s, i) => `
      <tr>
        <td style="text-align: center;">${i + 1}</td>
        <td style="font-family: monospace;">${s.nis}</td>
        <td><strong>${s.nama_lengkap}</strong></td>
        <td style="text-align: center;">${s.jenis_kelamin === 'L' ? 'L' : 'P'}</td>
        <td>${s.jenjang_pendidikan} (${s.kelas})</td>
        <td>${s.asrama_komplek} - ${s.kamar}</td>
        <td style="text-align: center;"><strong>${s.golongan_darah || '-'}</strong></td>
        <td>${s.riwayat_alergi && s.riwayat_alergi !== 'Tidak Ada' ? `<span style="color: #b91c1c; font-weight: bold;">${s.riwayat_alergi}</span>` : 'Nihil'}</td>
        <td><strong>${s.status_kesehatan}</strong></td>
        <td style="font-size: 8pt;">${s.nama_wali} (${s.telepon_wali})</td>
      </tr>
    `).join('');

    return `
      <div class="header-kop">
        <div class="kop-yayasan">YAYASAN PONDOK PESANTREN AL-AMIEN KEDIRI</div>
        <div class="kop-poskestren">POS KESEHATAN PESANTREN (POSKESTREN) AL-AMIEN</div>
        <div class="kop-alamat">Jl. KH. Hasyim Asy'ari / Ngasinan, Rejomulyo, Kec. Kota Kediri, Jawa Timur 64129</div>
      </div>
      <div class="doc-header">
        <div class="doc-title">DAFTAR INDUK PROFIL KESEHATAN SANTRI</div>
        <div class="doc-nomor">Filter: ${filterAsrama} • Jenis Kelamin: ${filterGender === 'All' ? 'Semua' : filterGender === 'L' ? 'Banin (Putra)' : 'Banat (Putri)'} • Total: ${filteredSantri.length} Santri</div>
      </div>
      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>NIS</th>
            <th>Nama Lengkap</th>
            <th>JK</th>
            <th>Pendidikan</th>
            <th>Asrama &amp; Kamar</th>
            <th>Gol</th>
            <th>Alergi</th>
            <th>Status</th>
            <th>Wali &amp; No. HP</th>
          </tr>
        </thead>
        <tbody>
          ${rows || '<tr><td colspan="10" style="text-align: center;">Tidak ada data santri yang sesuai filter.</td></tr>'}
        </tbody>
      </table>
      <div class="signature-wrap">
        <div class="signature-box">
          <div>Mengetahui,<br><span class="font-bold">Ketua Bagian Keamanan &amp; Kesehatan</span></div>
          <div class="signature-space"></div>
          <div class="font-bold underline">Ustadz Pengurus Pesantren</div>
          <div style="font-size: 8.5pt; color: #57534e;">Pondok Pesantren Al-Amien Kediri</div>
        </div>
        <div class="signature-box">
          <div>Kediri, ${new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}<br><span class="font-bold">Petugas Administrasi Poskestren</span></div>
          <div class="signature-space"></div>
          <div class="font-bold underline">Petugas Poskestren Al-Amien</div>
          <div style="font-size: 8.5pt; color: #57534e;">Unit Layanan Kesehatan Santri</div>
        </div>
      </div>
    `;
  };

  const handlePrintSantriList = () => {
    printHtmlContent({
      title: 'Daftar Induk Profil Kesehatan Santri Al-Amien',
      bodyHtml: generateSantriListHtml(),
      orientation: 'landscape',
    });
  };

  const handleDownloadSantriList = () => {
    downloadDocumentFile(
      `Daftar_Santri_AlAmien_${new Date().toISOString().slice(0, 10)}`,
      'Daftar Santri Al-Amien',
      generateSantriListHtml()
    );
  };

  const exportSantriCSV = () => {
    const headers = ['NIS', 'Nama Lengkap', 'Jenis Kelamin', 'Jenjang', 'Kelas', 'Asrama', 'Kamar', 'Gol Darah', 'Alergi', 'Penyakit Kronis', 'Status Kesehatan', 'Nama Wali', 'No HP Wali'];
    const rows = filteredSantri.map(s => [
      s.nis,
      `"${s.nama_lengkap}"`,
      s.jenis_kelamin,
      `"${s.jenjang_pendidikan}"`,
      `"${s.kelas}"`,
      `"${s.asrama_komplek}"`,
      `"${s.kamar}"`,
      s.golongan_darah || '',
      `"${s.riwayat_alergi || ''}"`,
      `"${s.riwayat_penyakit_kronis || ''}"`,
      s.status_kesehatan,
      `"${s.nama_wali}"`,
      `"${s.telepon_wali}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `data_santri_al_amien_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-700" />
            <h2 className="text-lg sm:text-xl font-bold text-stone-900">
              Master Data Santri Ponpes Al Amien Kediri
            </h2>
          </div>
          <p className="text-xs text-stone-500 mt-0.5">
            Database profil kesehatan, riwayat alergi, asrama, dan kontak darurat wali santri
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={exportSantriCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            title="Download CSV Master Data Santri"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor CSV</span>
          </button>
          <button
            onClick={handlePrintSantriList}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-200 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            title="Cetak Daftar Santri atau Simpan PDF"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-700" />
            <span>Cetak / Simpan PDF</span>
          </button>
          <button
            id="btn-tambah-santri"
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-semibold rounded-xl text-xs shadow-sm transition-all cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Tambah Santri Baru</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari NIS, Nama, Kamar..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 focus:border-emerald-600 bg-stone-50/50"
            />
          </div>

          {/* Gender Filter */}
          <div>
            <select
              value={filterGender}
              onChange={(e) => setFilterGender(e.target.value as any)}
              className="w-full py-2 px-3 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 focus:border-emerald-600 bg-stone-50/50"
            >
              <option value="All">Semua Kategori (Banin &amp; Banat)</option>
              <option value="L">Banin (Putra)</option>
              <option value="P">Banat (Putri)</option>
            </select>
          </div>

          {/* Asrama Filter */}
          <div>
            <select
              value={filterAsrama}
              onChange={(e) => setFilterAsrama(e.target.value)}
              className="w-full py-2 px-3 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 focus:border-emerald-600 bg-stone-50/50"
            >
              {asramaList.map((a, i) => (
                <option key={i} value={a}>{a}</option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="w-full py-2 px-3 text-xs rounded-xl border border-stone-300 focus:outline-emerald-600 focus:border-emerald-600 bg-stone-50/50"
            >
              <option value="All">Semua Status Kesehatan</option>
              <option value="Aktif">Sehat / Aktif Kegiatan</option>
              <option value="Observasi_Poskestren">Observasi Poskestren</option>
              <option value="Izin_Asrama">Istirahat di Asrama</option>
              <option value="Rujukan_RS">Rujukan RS/Faskes</option>
              <option value="Izin_Pulang">Izin Pulang / Home Care</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-stone-500 pt-1">
          <span>Menampilkan <strong>{filteredSantri.length}</strong> dari {santriList.length} santri</span>
          {(searchQuery || filterGender !== 'All' || filterAsrama !== 'Semua Asrama' || filterStatus !== 'All') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setFilterGender('All');
                setFilterAsrama('Semua Asrama');
                setFilterStatus('All');
              }}
              className="text-emerald-700 font-semibold hover:underline"
            >
              Reset Filter
            </button>
          )}
        </div>
      </div>

      {/* Santri Table */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-stone-700">
            <thead className="bg-stone-50 text-stone-500 uppercase tracking-wider font-semibold border-b border-stone-200">
              <tr>
                <th className="py-3 px-4">Santri / NIS</th>
                <th className="py-3 px-4">Jenjang &amp; Kamar</th>
                <th className="py-3 px-4">Gol. Darah &amp; Alergi</th>
                <th className="py-3 px-4">Kontak Wali</th>
                <th className="py-3 px-4">Status Kesehatan</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredSantri.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-stone-400">
                    Tidak ditemukan data santri yang sesuai kriteria pencarian.
                  </td>
                </tr>
              ) : (
                filteredSantri.map((s) => {
                  const hasAllergy = s.riwayat_alergi && s.riwayat_alergi !== 'Tidak Ada';
                  const isSakit = s.status_kesehatan !== 'Aktif';

                  return (
                    <tr key={s.id} className="hover:bg-stone-50/80 transition-colors">
                      {/* Name & NIS */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                            s.jenis_kelamin === 'L' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                          }`}>
                            {s.jenis_kelamin === 'L' ? 'Bn' : 'Bt'}
                          </div>
                          <div>
                            <div className="font-bold text-stone-900 flex items-center gap-1.5">
                              {s.nama_lengkap}
                              {s.jenis_kelamin === 'L' ? (
                                <span className="text-[10px] bg-emerald-50 text-emerald-700 px-1.5 py-0.2 rounded font-semibold border border-emerald-200">Banin</span>
                              ) : (
                                <span className="text-[10px] bg-rose-50 text-rose-700 px-1.5 py-0.2 rounded font-semibold border border-rose-200">Banat</span>
                              )}
                            </div>
                            <div className="text-[11px] text-stone-500 mt-0.5">
                              NIS: <span className="font-mono font-medium">{s.nis}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Jenjang & Asrama */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-stone-800">{s.jenjang_pendidikan} ({s.kelas})</div>
                        <div className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-stone-400" />
                          <span>{s.asrama_komplek} • {s.kamar}</span>
                        </div>
                      </td>

                      {/* Blood Type & Allergies */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-stone-100 text-stone-800 font-bold text-[11px]">
                            <Droplet className="w-3 h-3 text-rose-600" />
                            {s.golongan_darah}
                          </span>
                        </div>
                        {hasAllergy ? (
                          <div className="mt-1 flex items-center gap-1 text-[11px] text-rose-700 font-semibold bg-rose-50 px-2 py-0.5 rounded border border-rose-200 max-w-xs line-clamp-1">
                            <ShieldAlert className="w-3 h-3 shrink-0 text-rose-600" />
                            <span>{s.riwayat_alergi}</span>
                          </div>
                        ) : (
                          <div className="text-[11px] text-stone-400 mt-1">Alergi: -</div>
                        )}
                      </td>

                      {/* Wali Info */}
                      <td className="py-3 px-4">
                        <div className="font-medium text-stone-800">{s.nama_wali}</div>
                        <div className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3 text-emerald-600" />
                          <span>{s.telepon_wali}</span>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                          s.status_kesehatan === 'Aktif'
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : s.status_kesehatan === 'Observasi_Poskestren'
                            ? 'bg-amber-50 text-amber-800 border border-amber-200'
                            : s.status_kesehatan === 'Rujukan_RS'
                            ? 'bg-rose-50 text-rose-800 border border-rose-200'
                            : 'bg-stone-100 text-stone-800'
                        }`}>
                          {s.status_kesehatan === 'Aktif' && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                          {s.status_kesehatan === 'Observasi_Poskestren' && <Bed className="w-3 h-3 text-amber-600" />}
                          {s.status_kesehatan === 'Rujukan_RS' && <AlertCircle className="w-3 h-3 text-rose-600" />}
                          <span>{s.status_kesehatan.replace('_', ' ')}</span>
                        </span>
                      </td>

                      {/* Action buttons */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            title="Periksa Santri di Poskestren"
                            onClick={() => onPeriksaSantri(s)}
                            className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors border border-emerald-300"
                          >
                            <HeartPulse className="w-4 h-4" />
                          </button>
                          <button
                            title="Lihat Buku / Kartu Riwayat Kesehatan"
                            onClick={() => onSelectSantri(s)}
                            className="p-1.5 text-teal-700 hover:bg-teal-50 rounded-lg transition-colors border border-stone-200"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            title="Edit Data Santri"
                            onClick={() => handleOpenEdit(s)}
                            className="p-1.5 text-stone-600 hover:bg-stone-100 rounded-lg transition-colors border border-stone-200"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button
                            title="Hapus Data Santri"
                            onClick={() => {
                              if (confirm(`Yakin ingin menghapus santri ${s.nama_lengkap}?`)) {
                                onDeleteSantri(s.id);
                              }
                            }}
                            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors border border-stone-200"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit Santri */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto border border-stone-200 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-emerald-700" />
                <h3 className="font-bold text-stone-900 text-lg">
                  {editingSantri ? 'Edit Data Santri' : 'Pendaftaran Santri Baru'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 text-sm font-bold px-2 py-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Nomor Induk Santri (NIS) *</label>
                  <input
                    type="text"
                    required
                    value={formData.nis || ''}
                    onChange={(e) => setFormData({ ...formData, nis: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600 font-mono"
                    placeholder="Contoh: 2026.01.0099"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Nama Lengkap Santri *</label>
                  <input
                    type="text"
                    required
                    value={formData.nama_lengkap || ''}
                    onChange={(e) => setFormData({ ...formData, nama_lengkap: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                    placeholder="Nama sesuai akta kelahiran"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Kategori Santri</label>
                  <select
                    value={formData.jenis_kelamin || 'L'}
                    onChange={(e) => setFormData({ ...formData, jenis_kelamin: e.target.value as Gender })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                  >
                    <option value="L">Banin (Putra)</option>
                    <option value="P">Banat (Putri)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Jenjang Pendidikan</label>
                  <select
                    value={formData.jenjang_pendidikan || 'MA Al Amien'}
                    onChange={(e) => setFormData({ ...formData, jenjang_pendidikan: e.target.value as any })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                  >
                    <option value="MTs Al Amien">MTs Al Amien</option>
                    <option value="MA Al Amien">MA Al Amien</option>
                    <option value="KMI / Kepengasuhan">KMI / Kepengasuhan</option>
                    <option value="Tahfidz">Tahfidzul Qur'an</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Kelas / Halaqah</label>
                  <input
                    type="text"
                    value={formData.kelas || ''}
                    onChange={(e) => setFormData({ ...formData, kelas: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                    placeholder="Contoh: VII B / X IPA 2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Asrama / Komplek Santri</label>
                  <select
                    value={formData.asrama_komplek || 'Asrama Sunan Giri (Putra)'}
                    onChange={(e) => setFormData({ ...formData, asrama_komplek: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                  >
                    {asramaList.filter(a => a !== 'Semua Asrama').map((a, i) => (
                      <option key={i} value={a}>{a}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Kamar Santri</label>
                  <input
                    type="text"
                    value={formData.kamar || ''}
                    onChange={(e) => setFormData({ ...formData, kamar: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                    placeholder="Contoh: Kamar B-03 / Khodijah 02"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Tempat Lahir</label>
                  <input
                    type="text"
                    value={formData.tempat_lahir || ''}
                    onChange={(e) => setFormData({ ...formData, tempat_lahir: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Tanggal Lahir</label>
                  <input
                    type="date"
                    value={formData.tanggal_lahir || ''}
                    onChange={(e) => setFormData({ ...formData, tanggal_lahir: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Golongan Darah</label>
                  <select
                    value={formData.golongan_darah || '-'}
                    onChange={(e) => setFormData({ ...formData, golongan_darah: e.target.value as any })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                  >
                    <option value="-">Belum Tahu (-)</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="AB">AB</option>
                    <option value="O">O</option>
                  </select>
                </div>
              </div>

              <div className="p-3 bg-rose-50/60 rounded-xl border border-rose-200 space-y-2">
                <div className="font-bold text-rose-900 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-rose-600" />
                  <span>Informasi Keselamatan Pasien &amp; Riwayat Alergi</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-rose-800 mb-1">Riwayat Alergi (Obat / Makanan)</label>
                    <input
                      type="text"
                      value={formData.riwayat_alergi || ''}
                      onChange={(e) => setFormData({ ...formData, riwayat_alergi: e.target.value })}
                      className="w-full p-2 rounded-lg border border-rose-300 focus:outline-rose-600 bg-white"
                      placeholder="Contoh: Alergi Amoksisilin, Sulfa, Udang (atau 'Tidak Ada')"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-rose-800 mb-1">Riwayat Penyakit Kronis</label>
                    <input
                      type="text"
                      value={formData.riwayat_penyakit_kronis || ''}
                      onChange={(e) => setFormData({ ...formData, riwayat_penyakit_kronis: e.target.value })}
                      className="w-full p-2 rounded-lg border border-rose-300 focus:outline-rose-600 bg-white"
                      placeholder="Contoh: Asma, Thalasemia, Jantung (atau 'Tidak Ada')"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Nama Wali / Orang Tua</label>
                  <input
                    type="text"
                    value={formData.nama_wali || ''}
                    onChange={(e) => setFormData({ ...formData, nama_wali: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                    placeholder="Nama ayah / ibu / wali"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Nomor HP / WhatsApp Wali</label>
                  <input
                    type="text"
                    value={formData.telepon_wali || ''}
                    onChange={(e) => setFormData({ ...formData, telepon_wali: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                    placeholder="08123456789"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">Alamat Asal Santri</label>
                <textarea
                  rows={2}
                  value={formData.alamat_asal || ''}
                  onChange={(e) => setFormData({ ...formData, alamat_asal: e.target.value })}
                  className="w-full p-2.5 rounded-xl border border-stone-300 focus:outline-emerald-600"
                  placeholder="Kecamatan, Kota/Kabupaten, Provinsi"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold rounded-xl shadow-sm"
                >
                  {editingSantri ? 'Simpan Perubahan' : 'Daftarkan Santri'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
